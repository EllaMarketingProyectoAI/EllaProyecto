"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { useRouter } from "next/navigation"
import { useUserStore } from "@/lib/store/user-store"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, Download, Check, Wand2 } from "lucide-react"
import { VideoAIService, type VideoGenerationPrompt } from "@/lib/services/video-ai-service"

export default function AIVideoPage() {
  const { isAuthenticated, user } = useUserStore()
  const router = useRouter()
  const { toast } = useToast()

  const [step, setStep] = useState<"form" | "processing" | "complete">("form")
  const [progress, setProgress] = useState(0)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [generatedVideo, setGeneratedVideo] = useState<any>(null)

  const [formData, setFormData] = useState({
    title: "",
    prompt: "",
    duration: "60s",
    style: "modern",
    aspectRatio: "9:16",
  })

  // Redirigir si no está autenticado
  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/auth")
    }
  }, [isAuthenticated, router])

  const handleInputChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleGenerateVideo = async () => {
    if (!formData.prompt.trim() || !formData.title.trim()) {
      toast({
        variant: "destructive",
        title: "Campos requeridos",
        description: "Por favor, completa el título y el prompt para generar el video.",
      })
      return
    }

    if (!user?.id) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Debes iniciar sesión para generar un video.",
      })
      return
    }

    setIsSubmitting(true)
    setStep("processing")
    setProgress(0)

    // Simulamos el progreso
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 90) {
          clearInterval(interval)
          return 90
        }
        return prev + 2
      })
    }, 200)

    try {
      // Creamos el objeto de prompt
      const promptObj: VideoGenerationPrompt = {
        prompt: formData.prompt,
        duration: formData.duration.replace("s", " seconds").replace("min", " minutes"),
        style: formData.style,
        aspectRatio: formData.aspectRatio as "16:9" | "9:16" | "1:1",
        additionalContext: `Title: ${formData.title}`,
      }

      // Llamamos al servicio
      const result = await VideoAIService.generateVideo(promptObj)

      // Completamos el progreso
      clearInterval(interval)
      setProgress(100)

      // Guardamos el resultado
      setGeneratedVideo({
        ...result,
        title: formData.title,
      })

      // Esperamos un momento para mostrar el 100%
      setTimeout(() => {
        setStep("complete")
      }, 1000)

      toast({
        title: "¡Video generado con éxito!",
        description: "Tu video ha sido generado con IA.",
      })
    } catch (error) {
      console.error("Error al generar video:", error)
      clearInterval(interval)

      toast({
        variant: "destructive",
        title: "Error",
        description: "Ocurrió un error al generar el video. Por favor, intenta de nuevo.",
      })

      setStep("form")
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDownload = () => {
    if (!generatedVideo) return

    // Crear un elemento <a> temporal
    const link = document.createElement("a")
    link.href = generatedVideo.url
    link.target = "_blank"
    link.download = `ai-video-${generatedVideo.id}.mp4`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    toast({
      title: "Descarga iniciada",
      description: "Tu video se está descargando.",
    })
  }

  return (
    <div className="container py-10">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold mb-2 text-center">Generación de Video con IA</h1>
        <p className="text-muted-foreground mb-8 text-center">
          Describe el video que deseas y nuestra IA lo generará para ti
        </p>

        <Card>
          <CardHeader>
            <CardTitle>
              {step === "form" && "Describe tu video"}
              {step === "processing" && "Generando video con IA"}
              {step === "complete" && "¡Video generado con éxito!"}
            </CardTitle>
            <CardDescription>
              {step === "form" && "Proporciona los detalles para generar tu video con IA"}
              {step === "processing" && "Estamos procesando tu solicitud, por favor espera..."}
              {step === "complete" && "Tu video ha sido generado y está listo para descargar"}
            </CardDescription>
          </CardHeader>

          <CardContent className="space-y-6">
            {step === "form" && (
              <>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">Título del video</Label>
                    <Input
                      id="title"
                      value={formData.title}
                      onChange={(e) => handleInputChange("title", e.target.value)}
                      placeholder="Ingresa un título para tu video"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="prompt">Descripción detallada</Label>
                    <Textarea
                      id="prompt"
                      value={formData.prompt}
                      onChange={(e) => handleInputChange("prompt", e.target.value)}
                      placeholder="Describe con detalle el video que deseas generar..."
                      className="min-h-[150px]"
                    />
                    <p className="text-sm text-muted-foreground">
                      Sé específico sobre lo que quieres ver en el video. Incluye detalles sobre escenas, personajes,
                      acciones, colores, estilo visual, etc.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="duration">Duración</Label>
                      <Select value={formData.duration} onValueChange={(value) => handleInputChange("duration", value)}>
                        <SelectTrigger id="duration">
                          <SelectValue placeholder="Selecciona duración" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="15s">15 segundos</SelectItem>
                          <SelectItem value="30s">30 segundos</SelectItem>
                          <SelectItem value="60s">1 minuto</SelectItem>
                          <SelectItem value="3min">3 minutos</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="style">Estilo</Label>
                      <Select value={formData.style} onValueChange={(value) => handleInputChange("style", value)}>
                        <SelectTrigger id="style">
                          <SelectValue placeholder="Selecciona estilo" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="modern">Moderno</SelectItem>
                          <SelectItem value="cinematic">Cinematográfico</SelectItem>
                          <SelectItem value="vintage">Vintage</SelectItem>
                          <SelectItem value="minimalist">Minimalista</SelectItem>
                          <SelectItem value="documentary">Documental</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="aspectRatio">Relación de aspecto</Label>
                      <Select
                        value={formData.aspectRatio}
                        onValueChange={(value) => handleInputChange("aspectRatio", value)}
                      >
                        <SelectTrigger id="aspectRatio">
                          <SelectValue placeholder="Selecciona relación" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="9:16">Vertical (9:16) - TikTok, Reels</SelectItem>
                          <SelectItem value="16:9">Horizontal (16:9) - YouTube</SelectItem>
                          <SelectItem value="1:1">Cuadrado (1:1) - Instagram</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              </>
            )}

            {step === "processing" && (
              <div className="py-8 space-y-6">
                <div className="text-center space-y-4">
                  <div className="inline-block h-12 w-12 animate-spin rounded-full border-4 border-solid border-blue-600 border-r-transparent"></div>
                  <h3 className="text-xl font-medium">Generando video con IA</h3>
                  <p className="text-muted-foreground">
                    Estamos procesando tu solicitud. Esto puede tomar unos minutos...
                  </p>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Progreso</span>
                    <span>{progress}%</span>
                  </div>
                  <Progress value={progress} className="h-2" />
                </div>
              </div>
            )}

            {step === "complete" && (
              <div className="py-8 space-y-6">
                <div className="text-center space-y-4">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 text-green-600">
                    <Check className="h-8 w-8" />
                  </div>
                  <h3 className="text-xl font-medium">¡Video generado con éxito!</h3>
                  <p className="text-muted-foreground max-w-md mx-auto">
                    Tu video ha sido generado con IA y está listo para ser descargado.
                  </p>
                </div>

                <div className="aspect-video rounded-lg overflow-hidden max-w-md mx-auto">
                  <img
                    src={generatedVideo?.thumbnailUrl || "/placeholder.svg?height=360&width=640"}
                    alt="Video generado"
                    className="w-full h-full object-cover"
                  />
                </div>

                <div className="space-y-2 max-w-md mx-auto">
                  <h4 className="font-medium">{generatedVideo?.title}</h4>
                  <p className="text-sm text-muted-foreground">{generatedVideo?.prompt}</p>
                </div>
              </div>
            )}
          </CardContent>

          <CardFooter className="flex justify-between">
            {step === "form" && (
              <>
                <Button variant="outline" onClick={() => router.push("/video-selection")}>
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Volver
                </Button>
                <Button
                  onClick={handleGenerateVideo}
                  disabled={isSubmitting || !formData.prompt.trim() || !formData.title.trim()}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Wand2 className="mr-2 h-4 w-4" />
                  Generar con IA
                </Button>
              </>
            )}

            {step === "processing" && (
              <div className="w-full flex justify-center">
                <p className="text-sm text-muted-foreground">Por favor espera mientras generamos tu video...</p>
              </div>
            )}

            {step === "complete" && (
              <div className="w-full flex justify-center gap-4">
                <Button variant="outline" onClick={() => router.push("/dashboard")}>
                  Ver en biblioteca
                </Button>
                <Button onClick={handleDownload} className="bg-blue-600 hover:bg-blue-700">
                  <Download className="mr-2 h-4 w-4" />
                  Descargar video
                </Button>
              </div>
            )}
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
