import { NextResponse } from "next/server"
import { VideoAIService } from "@/lib/services/video-ai-service"

export async function GET(request: Request, { params }: { params: { id: string } }): Promise<NextResponse> {
  try {
    const { id } = params

    if (!id) {
      return NextResponse.json({ error: "Se requiere un ID de video" }, { status: 400 })
    }

    // Verificamos el estado del video
    const result = await VideoAIService.checkVideoStatus(id)

    return NextResponse.json({ success: true, video: result })
  } catch (error) {
    console.error("Error al verificar estado del video:", error)
    return NextResponse.json({ success: false, error: "Error al verificar el estado del video" }, { status: 500 })
  }
}
