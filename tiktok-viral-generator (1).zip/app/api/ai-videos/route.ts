import { NextResponse } from "next/server"
import { VideoAIService, type VideoGenerationPrompt } from "@/lib/services/video-ai-service"

export async function POST(request: Request): Promise<NextResponse> {
  try {
    const body = await request.json()
    const { prompt } = body as { prompt: VideoGenerationPrompt }

    if (!prompt || !prompt.prompt) {
      return NextResponse.json({ error: "Se requiere un prompt para generar el video" }, { status: 400 })
    }

    // Llamamos al servicio de generación de video
    const result = await VideoAIService.generateVideo(prompt)

    return NextResponse.json({ success: true, video: result })
  } catch (error) {
    console.error("Error al generar video con IA:", error)
    return NextResponse.json(
      { success: false, error: "Error al procesar la solicitud de generación de video" },
      { status: 500 },
    )
  }
}
