import { NextResponse } from "next/server"

// Esta ruta ahora simulará la funcionalidad sin necesidad de variables de entorno
export async function GET(request: Request, { params }: { params: { platform: string } }) {
  const { platform } = params
  const searchParams = new URL(request.url).searchParams
  const code = searchParams.get("code")
  const state = searchParams.get("state")

  if (!code || !state) {
    return NextResponse.redirect(new URL("/auth?error=missing_params", request.url))
  }

  try {
    // Simulamos una autenticación exitosa
    console.log(`Simulando autenticación exitosa para ${platform}`)

    // Devolvemos una respuesta HTML que cierra la ventana y envía un mensaje
    return new NextResponse(
      `
      <html>
        <head>
          <title>Autenticación exitosa</title>
        </head>
        <body>
          <script>
            window.opener.postMessage({ type: 'oauth_success', platform: '${platform}' }, '*');
            window.close();
          </script>
          <p>Autenticación exitosa. Puedes cerrar esta ventana.</p>
        </body>
      </html>
    `,
      {
        headers: {
          "Content-Type": "text/html",
        },
      },
    )
  } catch (error) {
    console.error(`Error en callback de OAuth para ${platform}:`, error)
    return NextResponse.redirect(new URL(`/auth?error=server_error&platform=${platform}`, request.url))
  }
}
