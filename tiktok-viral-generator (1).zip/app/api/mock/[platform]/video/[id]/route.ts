import { NextResponse } from "next/server"

export async function GET(request: Request, { params }: { params: { platform: string; id: string } }) {
  const { platform, id } = params

  // Datos de ejemplo para simular detalles de un video
  const mockVideo = {
    id,
    platform,
    url: `https://${platform}.com/video/${id}`,
    thumbnail: "/placeholder.svg?height=720&width=1280",
    title: `Video viral de ${platform} #${id}`,
    views: 2500000,
    likes: 150000,
    date: "2023-03-15",
    author: {
      name: `Creator${id}`,
      avatar: "/placeholder.svg?height=50&width=50",
      id: `creator${id}`,
    },
    description: `Este es un video viral de ${platform} con más de 2.5 millones de vistas. Perfecto para analizar y crear contenido similar.`,
    duration: "00:45",
    comments: 12500,
    shares: 45000,
  }

  return NextResponse.json({ success: true, video: mockVideo })
}
