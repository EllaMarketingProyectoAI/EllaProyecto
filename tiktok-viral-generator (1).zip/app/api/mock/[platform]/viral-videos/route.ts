import { NextResponse } from "next/server"

export async function GET(request: Request, { params }: { params: { platform: string } }) {
  const { platform } = params

  // Datos de ejemplo para simular videos virales
  const mockVideos = [
    {
      id: "1",
      platform,
      url: `https://${platform}.com/video/1`,
      thumbnail: "/placeholder.svg?height=180&width=320",
      title: `Video viral de ${platform} #1`,
      views: 2500000,
      likes: 150000,
      date: "2023-03-15",
      author: {
        name: "Creator1",
        avatar: "/placeholder.svg?height=50&width=50",
        id: "creator1",
      },
    },
    {
      id: "2",
      platform,
      url: `https://${platform}.com/video/2`,
      thumbnail: "/placeholder.svg?height=180&width=320",
      title: `Video viral de ${platform} #2`,
      views: 1800000,
      likes: 120000,
      date: "2023-03-10",
      author: {
        name: "Creator2",
        avatar: "/placeholder.svg?height=50&width=50",
        id: "creator2",
      },
    },
    {
      id: "3",
      platform,
      url: `https://${platform}.com/video/3`,
      thumbnail: "/placeholder.svg?height=180&width=320",
      title: `Video viral de ${platform} #3`,
      views: 3200000,
      likes: 210000,
      date: "2023-03-05",
      author: {
        name: "Creator3",
        avatar: "/placeholder.svg?height=50&width=50",
        id: "creator3",
      },
    },
  ]

  return NextResponse.json({ success: true, videos: mockVideos })
}
