import { NextResponse } from "next/server"

export async function POST(request: Request): Promise<NextResponse> {
  try {
    // Log the incoming request for debugging
    console.log("Recibida solicitud de depuración n8n")

    // Parse the request body
    const body = await request.json()

    // Log the full request body
    console.log("Cuerpo completo de la solicitud:", JSON.stringify(body, null, 2))

    // Extract and log the structure
    const keys = Object.keys(body)
    console.log("Estructura de primer nivel:", keys)

    // Check for inputContext
    if (body.inputContext) {
      console.log("Estructura de inputContext:", Object.keys(body.inputContext))
    }

    // Return the structure analysis
    return NextResponse.json({
      success: true,
      message: "Análisis de estructura completado",
      structure: {
        topLevel: keys,
        inputContext: body.inputContext ? Object.keys(body.inputContext) : null,
        hasTitle: body.title !== undefined || (body.inputContext && body.inputContext.title !== undefined),
        hasTopic: body.topic !== undefined || (body.inputContext && body.inputContext.topic !== undefined),
        hasHook: body.hook !== undefined || (body.inputContext && body.inputContext.hook !== undefined),
      },
      fullBody: body,
    })
  } catch (error: any) {
    console.error("Error en depuración n8n:", error)
    return NextResponse.json(
      {
        success: false,
        error: error.message || "Error interno",
      },
      { status: 500 },
    )
  }
}
