import { NextResponse } from "next/server"

export async function GET(request: Request) {
  try {
    // Get the n8n workflow URL and API key from environment variables
    const n8nUrl = process.env.NEXT_PUBLIC_N8N_WORKFLOW_URL || process.env.N8N_WORKFLOW_URL
    const apiKey = process.env.NEXT_PUBLIC_N8N_API_KEY || process.env.N8N_API_KEY

    const diagnosticInfo = {
      n8nUrlConfigured: !!n8nUrl,
      n8nUrl: n8nUrl ? maskUrl(n8nUrl) : null,
      apiKeyConfigured: !!apiKey,
      apiKeyMasked: apiKey ? maskApiKey(apiKey) : null,
      serverTime: new Date().toISOString(),
      nodeVersion: process.version,
      environment: process.env.NODE_ENV,
    }

    // Test connection to n8n if URL is configured
    if (n8nUrl) {
      try {
        // Send a simple ping request to n8n
        const pingPayload = {
          operation: "ping",
          timestamp: new Date().toISOString(),
        }

        const pingResponse = await fetch(n8nUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...(apiKey ? { "x-api-key": apiKey } : {}),
          },
          body: JSON.stringify(pingPayload),
        })

        diagnosticInfo.pingStatus = pingResponse.status
        diagnosticInfo.pingOk = pingResponse.ok

        try {
          const responseText = await pingResponse.text()
          diagnosticInfo.pingResponse = responseText.substring(0, 500) // Limit response size
        } catch (responseError) {
          diagnosticInfo.pingResponseError = "Could not read response text"
        }
      } catch (pingError: any) {
        diagnosticInfo.pingError = pingError.message
        diagnosticInfo.pingOk = false
      }
    }

    return NextResponse.json(diagnosticInfo)
  } catch (error: any) {
    return NextResponse.json(
      {
        success: false,
        error: error.message || "Unknown error",
      },
      { status: 500 },
    )
  }
}

// Mask URL for security
function maskUrl(url: string): string {
  try {
    const urlObj = new URL(url)
    return `${urlObj.protocol}//${urlObj.hostname}/***`
  } catch (error) {
    return "Invalid URL format"
  }
}

// Mask API key for security
function maskApiKey(apiKey: string): string {
  if (apiKey.length <= 8) {
    return "********"
  }
  return apiKey.substring(0, 4) + "****" + apiKey.substring(apiKey.length - 4)
}
