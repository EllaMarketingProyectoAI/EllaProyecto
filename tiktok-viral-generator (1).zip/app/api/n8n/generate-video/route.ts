import { NextResponse } from "next/server"
import { createServerSupabaseClient } from "@/lib/supabase/server"
import { createGeneralVideo } from "@/lib/services/video-service"
import { VideoAIService } from "@/lib/services/video-ai-service"

// API key validation middleware
const validateApiKey = (request: Request) => {
  const apiKey = request.headers.get("x-api-key")
  // Get the API key from environment variables or use a default for development
  const validApiKey = process.env.N8N_API_KEY || "n8n-viral-video-maker-key"

  if (!apiKey || apiKey !== validApiKey) {
    return false
  }

  return true
}

export async function POST(request: Request): Promise<NextResponse> {
  try {
    // Validate API key
    if (!validateApiKey(request)) {
      return NextResponse.json({ success: false, error: "Unauthorized: Invalid API key" }, { status: 401 })
    }

    // Parse the request body
    const body = await request.json()
    const { userId, videoType, options } = body

    if (!userId || !videoType || !options) {
      return NextResponse.json(
        { success: false, error: "Missing required parameters: userId, videoType, options" },
        { status: 400 },
      )
    }

    // Validate user exists
    const supabase = createServerSupabaseClient()
    const { data: user, error: userError } = await supabase.from("users").select("id").eq("id", userId).single()

    if (userError || !user) {
      return NextResponse.json({ success: false, error: "User not found" }, { status: 404 })
    }

    let result

    // Process based on video type
    switch (videoType) {
      case "general":
        // Ensure required fields for general video
        if (!options.title || !options.topic || !options.hook || !options.format) {
          return NextResponse.json(
            { success: false, error: "Missing required options for general video" },
            { status: 400 },
          )
        }

        // Create general video
        result = await createGeneralVideo(userId, options.title, {
          title: options.title,
          topic: options.topic,
          hook: options.hook,
          format: options.format,
          sources: options.sources || "",
          restricted_words: options.restricted_words || null,
          duration: options.duration || "60s",
          banned_topics: options.banned_topics || null,
          keywords: options.keywords || null,
          ai_voice_over: options.ai_voice_over || "no",
          subtitles: options.subtitles || "no",
          b_roll: options.b_roll || "none",
          typography: options.typography || null,
          music_source: options.music_source || null,
          b_roll_source: options.b_roll_source || [],
          sound_effects_source: options.sound_effects_source || null,
        })
        break

      case "ai":
        // Ensure required fields for AI video
        if (!options.prompt || !options.title) {
          return NextResponse.json({ success: false, error: "Missing required options for AI video" }, { status: 400 })
        }

        // Generate AI video
        const promptObj = {
          prompt: options.prompt,
          duration: options.duration || "60s",
          style: options.style || "modern",
          aspectRatio: options.aspectRatio || "9:16",
          additionalContext: `Title: ${options.title}`,
        }

        const aiResult = await VideoAIService.generateVideo(promptObj)
        result = {
          success: true,
          videoId: aiResult.id,
          generatedVideo: {
            ...aiResult,
            title: options.title,
          },
        }
        break

      default:
        return NextResponse.json(
          { success: false, error: "Invalid videoType. Supported types: general, ai" },
          { status: 400 },
        )
    }

    if (!result.success) {
      return NextResponse.json({ success: false, error: result.error || "Failed to create video" }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      videoId: result.videoId,
      video: result.generatedVideo,
    })
  } catch (error: any) {
    console.error("Error in n8n video generation:", error)
    return NextResponse.json({ success: false, error: error.message || "Internal server error" }, { status: 500 })
  }
}
