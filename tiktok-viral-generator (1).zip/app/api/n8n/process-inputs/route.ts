import { NextResponse } from "next/server"
import { createServerSupabaseClient } from "@/lib/supabase/server"
import { N8nService } from "@/lib/services/n8n-service"
import { PromptGenerationService } from "@/lib/services/prompt-generation-service"
import { v4 as uuidv4 } from "uuid"

// API key validation middleware
const validateApiKey = (request: Request) => {
  const apiKey = request.headers.get("x-api-key")
  // Get the API key from environment variables or use a default for development
  const validApiKey = process.env.N8N_API_KEY || "n8n-viral-video-maker-key"

  if (!apiKey || apiKey !== validApiKey) {
    return false
  }

  return true
}

// Modificar la función POST para redirigir al workflow real de n8n cuando sea necesario

export async function POST(request: Request): Promise<NextResponse> {
  try {
    console.log("Recibida solicitud en /api/n8n/process-inputs")

    // Validate API key
    if (!validateApiKey(request)) {
      console.error("API key inválida")
      return NextResponse.json({ success: false, error: "Unauthorized: Invalid API key" }, { status: 401 })
    }

    // Parse the request body
    const body = await request.json()
    console.log("Body recibido:", JSON.stringify(body))

    const { userId, videoId, inputContext, operation } = body

    if (!userId || !operation) {
      console.error("Faltan parámetros requeridos")
      return NextResponse.json(
        { success: false, error: "Missing required parameters: userId, operation" },
        { status: 400 },
      )
    }

    // Validate user exists
    const supabase = createServerSupabaseClient()
    const { data: user, error: userError } = await supabase.from("users").select("id").eq("id", userId).single()

    if (userError) {
      console.error("Error al buscar usuario:", userError)
      return NextResponse.json(
        { success: false, error: "Error al buscar usuario: " + userError.message },
        { status: 500 },
      )
    }

    if (!user) {
      console.error("Usuario no encontrado:", userId)
      return NextResponse.json({ success: false, error: "User not found" }, { status: 404 })
    }

    // Process based on operation type
    switch (operation) {
      case "generate_prompt": {
        console.log("Operación: generate_prompt")

        if (!videoId || !inputContext) {
          console.error("Faltan parámetros requeridos para la generación de prompt")
          return NextResponse.json(
            { success: false, error: "Missing required parameters for prompt generation: videoId, inputContext" },
            { status: 400 },
          )
        }

        // Validate video exists
        const { data: video, error: videoError } = await supabase
          .from("videos")
          .select("id, type")
          .eq("id", videoId)
          .single()

        if (videoError) {
          console.error("Error al buscar video:", videoError)
          return NextResponse.json(
            { success: false, error: "Error al buscar video: " + videoError.message },
            { status: 500 },
          )
        }

        if (!video) {
          console.error("Video no encontrado:", videoId)
          return NextResponse.json({ success: false, error: "Video not found" }, { status: 404 })
        }

        console.log("Video encontrado:", video)

        // Registrar la solicitud de webhook para seguimiento
        const requestId = N8nService.registerWebhookRequest({
          userId,
          videoType: video.type as any,
          options: inputContext,
        })

        // Actualizar el estado a "processing"
        N8nService.updateWebhookStatus(requestId, "processing")

        // Verificar si debemos usar n8n real o la simulación local
        const n8nUrl = process.env.N8N_WORKFLOW_URL
        const apiKey = process.env.N8N_API_KEY

        if (n8nUrl && apiKey) {
          try {
            // Dentro de la función POST, en el case "generate_prompt":
            // Modificar la preparación de datos para n8n

            // Preparar los datos para enviar a n8n
            const n8nPayload = {
              // Datos principales a nivel raíz para facilitar acceso
              ...inputContext,
              // Mantener también la estructura original para compatibilidad
              userId,
              videoId,
              videoType: video.type,
              inputContext,
              requestId,
            }

            console.log("Enviando solicitud al workflow real de n8n con payload:", JSON.stringify(n8nPayload))

            // Llamar al workflow real de n8n
            const n8nResponse = await fetch(n8nUrl, {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                "x-api-key": apiKey,
              },
              body: JSON.stringify(n8nPayload),
              cache: "no-store",
            })

            if (!n8nResponse.ok) {
              const errorText = await n8nResponse.text()
              console.error(`Error en respuesta de n8n (${n8nResponse.status}):`, errorText)
              N8nService.updateWebhookStatus(requestId, "failed", null, `Error de n8n: ${n8nResponse.status}`)
              return NextResponse.json(
                { success: false, error: `Error al llamar a n8n: ${n8nResponse.status}` },
                { status: 500 },
              )
            }

            const n8nResult = await n8nResponse.json()

            if (!n8nResult.success) {
              N8nService.updateWebhookStatus(requestId, "failed", null, n8nResult.error || "Error desconocido en n8n")
              return NextResponse.json({ success: false, error: n8nResult.error }, { status: 500 })
            }

            // Guardar el resultado en la base de datos
            const workflowResultId = uuidv4()
            const { error: resultError } = await supabase.from("n8n_workflow_results").insert({
              id: workflowResultId,
              video_id: videoId,
              workflow_id: n8nResult.workflowId || "n8n-prompt-workflow",
              execution_id: n8nResult.executionId || requestId,
              status: "completed",
              result_data: {
                prompt: n8nResult.promptText || n8nResult.prompt,
                metadata: n8nResult.metadata || {},
              },
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString(),
            })

            if (resultError) {
              console.error("Error al guardar el resultado del workflow:", resultError)
              N8nService.updateWebhookStatus(requestId, "failed", null, resultError.message)
              return NextResponse.json({ success: false, error: resultError.message }, { status: 500 })
            }

            // Actualizar el estado a "completed"
            N8nService.updateWebhookStatus(requestId, "completed", {
              promptText: n8nResult.promptText || n8nResult.prompt,
              metadata: n8nResult.metadata || {},
            })

            return NextResponse.json({
              success: true,
              promptText: n8nResult.promptText || n8nResult.prompt,
              metadata: n8nResult.metadata || {},
              workflowId: n8nResult.workflowId || "n8n-prompt-workflow",
              executionId: n8nResult.executionId || requestId,
            })
          } catch (error: any) {
            console.error("Error al comunicarse con n8n:", error)
            // Si falla la comunicación con n8n, usamos la generación local como fallback
            console.log("Usando generación local como fallback debido a error de comunicación con n8n")
          }
        }

        // Si no hay configuración de n8n o falló la comunicación, usamos la generación local
        try {
          console.log("Generando prompt localmente para video tipo:", video.type)

          // Generar el prompt basado en el tipo de video y el contexto de entrada
          const promptResult = PromptGenerationService.generatePrompt(video.type as any, inputContext, {
            videoTitle: inputContext.title,
          })

          console.log("Prompt generado localmente:", promptResult.prompt.substring(0, 100) + "...")

          // Guardar el resultado en la base de datos
          const workflowResultId = uuidv4()
          const { error: resultError } = await supabase.from("n8n_workflow_results").insert({
            id: workflowResultId,
            video_id: videoId,
            workflow_id: "local-prompt-generation",
            execution_id: requestId,
            status: "completed",
            result_data: {
              prompt: promptResult.prompt,
              metadata: promptResult.metadata,
            },
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          })

          if (resultError) {
            console.error("Error al guardar el resultado del workflow:", resultError)
            N8nService.updateWebhookStatus(requestId, "failed", null, resultError.message)
            return NextResponse.json({ success: false, error: resultError.message }, { status: 500 })
          }

          // Actualizar el estado a "completed"
          N8nService.updateWebhookStatus(requestId, "completed", {
            promptText: promptResult.prompt,
            metadata: promptResult.metadata,
          })

          return NextResponse.json({
            success: true,
            promptText: promptResult.prompt,
            metadata: promptResult.metadata,
            workflowId: "local-prompt-generation",
            executionId: requestId,
          })
        } catch (error: any) {
          console.error("Error al generar el prompt localmente:", error)
          N8nService.updateWebhookStatus(requestId, "failed", null, error.message)
          return NextResponse.json({ success: false, error: error.message }, { status: 500 })
        }
      }

      // Otros tipos de operaciones pueden ser añadidos aquí
      default:
        console.error("Operación inválida:", operation)
        return NextResponse.json(
          { success: false, error: "Invalid operation. Supported operations: generate_prompt" },
          { status: 400 },
        )
    }
  } catch (error: any) {
    console.error("Error in n8n process inputs:", error)
    return NextResponse.json({ success: false, error: error.message || "Internal server error" }, { status: 500 })
  }
}
