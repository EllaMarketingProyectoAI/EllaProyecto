import { NextResponse } from "next/server"
import { N8nService } from "@/lib/services/n8n-service"

// API key validation middleware
const validateApiKey = (request: Request) => {
  const apiKey = request.headers.get("x-api-key")
  // Get the API key from environment variables or use a default for development
  const validApiKey = process.env.N8N_API_KEY || "n8n-viral-video-maker-key"

  if (!apiKey || apiKey !== validApiKey) {
    return false
  }

  return true
}

export async function GET(request: Request, { params }: { params: { requestId: string } }): Promise<NextResponse> {
  try {
    // Validate API key
    if (!validateApiKey(request)) {
      return NextResponse.json({ success: false, error: "Unauthorized: Invalid API key" }, { status: 401 })
    }

    const { requestId } = params

    if (!requestId) {
      return NextResponse.json({ success: false, error: "Missing requestId parameter" }, { status: 400 })
    }

    // Get request status
    const requestStatus = N8nService.getWebhookStatus(requestId)

    if (!requestStatus) {
      return NextResponse.json({ success: false, error: "Request not found" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      requestId,
      status: requestStatus.status,
      result: requestStatus.result,
      error: requestStatus.error,
      createdAt: requestStatus.createdAt,
    })
  } catch (error: any) {
    console.error("Error checking request status:", error)
    return NextResponse.json({ success: false, error: error.message || "Internal server error" }, { status: 500 })
  }
}
