import { NextResponse } from "next/server"

export async function GET() {
  try {
    const n8nUrl = process.env.NEXT_PUBLIC_N8N_WORKFLOW_URL || process.env.N8N_WORKFLOW_URL
    const apiKey = process.env.NEXT_PUBLIC_N8N_API_KEY || process.env.N8N_API_KEY

    const status = {
      configured: !!(n8nUrl && apiKey),
      url: n8nUrl ? "Configured" : "Not configured",
      apiKey: apiKey ? "Configured" : "Not configured",
      timestamp: new Date().toISOString(),
      n8nUrl: n8nUrl || null, // Añadimos la URL real para mostrarla en la interfaz
    }

    return NextResponse.json(status)
  } catch (error: any) {
    return NextResponse.json(
      {
        success: false,
        error: error.message || "Unknown error",
      },
      { status: 500 },
    )
  }
}
