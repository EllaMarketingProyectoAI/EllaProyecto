import { NextResponse } from "next/server"
import { PromptService } from "@/lib/services/prompt-service"
import { v4 as uuidv4 } from "uuid"

export async function GET(request: Request): Promise<NextResponse> {
  try {
    // Create a test request
    const testRequest = {
      videoId: uuidv4(),
      userId: "test-user",
      inputContext: {
        title: "Test Video",
        topic: "Testing n8n Integration",
        hook: "question",
        format: "tutorial",
        restricted_words: "bad,words",
        banned_topics: "politics,religion",
        keywords: "test,n8n,integration",
        ai_voice_over: "yes",
        subtitles: "yes",
        typography: "modern",
        music_source: "upbeat",
        b_roll_source: ["stock", "ai"],
        sound_effects_source: "minimal",
        duration: "60s",
        sources: "Test sources",
      },
    }

    // Test the n8n integration
    const result = await PromptService.generatePromptWithN8n(testRequest)

    return NextResponse.json({
      success: true,
      message: "Test completed",
      result,
      request: testRequest,
      n8nUrl: process.env.N8N_WORKFLOW_URL || "Not configured",
      apiKeyConfigured: !!process.env.N8N_API_KEY,
    })
  } catch (error: any) {
    console.error("Error in n8n test:", error)
    return NextResponse.json(
      {
        success: false,
        error: error.message || "Unknown error",
        stack: error.stack,
      },
      { status: 500 },
    )
  }
}
