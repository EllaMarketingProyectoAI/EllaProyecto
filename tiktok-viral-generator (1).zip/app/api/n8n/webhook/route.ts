import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    // Get the request body
    const body = await request.json()
    console.log("Received webhook request:", JSON.stringify(body))

    // Get the n8n workflow URL and API key from environment variables
    const n8nUrl = process.env.NEXT_PUBLIC_N8N_WORKFLOW_URL || process.env.N8N_WORKFLOW_URL
    const apiKey = process.env.NEXT_PUBLIC_N8N_API_KEY || process.env.N8N_API_KEY

    if (!n8nUrl) {
      console.error("N8N_WORKFLOW_URL not configured")
      // Fallback to local prompt generation
      return NextResponse.json({
        success: true,
        promptText: generateFallbackPrompt(body),
        workflowId: "fallback-workflow",
        executionId: body.requestId || "fallback-execution",
      })
    }

    if (!apiKey) {
      console.error("N8N_API_KEY not configured")
      // Fallback to local prompt generation
      return NextResponse.json({
        success: true,
        promptText: generateFallbackPrompt(body),
        workflowId: "fallback-workflow",
        executionId: body.requestId || "fallback-execution",
      })
    }

    console.log("Forwarding request to n8n:", n8nUrl)

    // Simplify the payload for n8n to reduce complexity
    const simplifiedPayload = {
      title: body.title || "",
      topic: body.topic || "",
      hook: body.hook || "",
      format: body.format || "",
      duration: body.duration || "60s",
      keywords: body.keywords || "",
      // Metadatos adicionales
      videoId: body.videoId || "",
      userId: body.userId || "",
      requestId: body.requestId || "",
      timestamp: body.timestamp || new Date().toISOString(),
    }

    console.log("Simplified payload for n8n:", JSON.stringify(simplifiedPayload))

    // Forward the request to n8n
    try {
      const n8nResponse = await fetch(n8nUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": apiKey,
        },
        body: JSON.stringify(simplifiedPayload),
      })

      const responseText = await n8nResponse.text()
      console.log(`Response from n8n (${n8nResponse.status}):`, responseText)

      if (!n8nResponse.ok) {
        console.error(`Error from n8n (${n8nResponse.status}):`, responseText)

        // Fallback to local prompt generation
        return NextResponse.json({
          success: true,
          promptText: generateFallbackPrompt(body),
          workflowId: "fallback-workflow",
          executionId: body.requestId || "fallback-execution",
        })
      }

      // Parse the response from n8n
      let responseData
      try {
        responseData = JSON.parse(responseText)

        // Verificar si la respuesta tiene el formato esperado
        if (!responseData.promptText && !responseData.prompt) {
          console.warn("n8n response does not contain promptText or prompt field:", responseData)

          // Si la respuesta no tiene el formato esperado, intentamos extraer el prompt
          if (typeof responseData === "string") {
            // Si la respuesta es un string, asumimos que es el prompt
            responseData = {
              success: true,
              promptText: responseData,
            }
          } else if (responseData.data && responseData.data.promptText) {
            // Si la respuesta tiene un campo data.promptText, lo usamos
            responseData = {
              success: true,
              promptText: responseData.data.promptText,
            }
          } else if (responseData.data && responseData.data.prompt) {
            // Si la respuesta tiene un campo data.prompt, lo usamos
            responseData = {
              success: true,
              promptText: responseData.data.prompt,
            }
          } else if (responseData.result) {
            // Si la respuesta tiene un campo result, lo usamos
            responseData = {
              success: true,
              promptText:
                typeof responseData.result === "string" ? responseData.result : JSON.stringify(responseData.result),
            }
          } else {
            // Si no podemos extraer el prompt, generamos uno localmente
            responseData = {
              success: true,
              promptText: generateFallbackPrompt(body),
              workflowId: "fallback-workflow",
              executionId: body.requestId || "fallback-execution",
            }
          }
        }

        // Asegurarnos de que la respuesta tenga el campo success
        if (responseData.success === undefined) {
          responseData.success = true
        }
      } catch (error) {
        console.error("Error parsing n8n response:", error)

        // Si no podemos parsear la respuesta como JSON, verificamos si es un texto que podría ser el prompt
        if (responseText && responseText.length > 0 && !responseText.startsWith("{") && !responseText.startsWith("[")) {
          // Si la respuesta es un texto plano, asumimos que es el prompt
          return NextResponse.json({
            success: true,
            promptText: responseText,
            workflowId: "n8n-workflow",
            executionId: body.requestId || "n8n-execution",
          })
        }

        // Si no podemos extraer el prompt, generamos uno localmente
        return NextResponse.json({
          success: true,
          promptText: generateFallbackPrompt(body),
          workflowId: "fallback-workflow",
          executionId: body.requestId || "fallback-execution",
        })
      }

      // Return the response from n8n
      return NextResponse.json(responseData)
    } catch (fetchError: any) {
      console.error("Error fetching from n8n:", fetchError)

      // Fallback to local prompt generation
      return NextResponse.json({
        success: true,
        promptText: generateFallbackPrompt(body),
        workflowId: "fallback-workflow",
        executionId: body.requestId || "fallback-execution",
      })
    }
  } catch (error: any) {
    console.error("Error in webhook route:", error)

    // Fallback to a generic prompt
    return NextResponse.json({
      success: true,
      promptText:
        "Este prompt fue generado como fallback debido a un error en el servidor. Por favor, intenta nuevamente más tarde.",
      workflowId: "error-fallback",
      executionId: "error-" + Date.now(),
    })
  }
}

// Generate a fallback prompt if n8n fails
function generateFallbackPrompt(data: any): string {
  const title = data.title || "Video sin título"
  const topic = data.topic || "Tema no especificado"
  const format = data.format || "Formato no especificado"
  const hook = data.hook || "Hook no especificado"
  const duration = data.duration || "60s"
  const keywords = data.keywords || ""

  return `Crea un video viral sobre "${title}" que trate sobre ${topic}. 
Utiliza un formato de ${format} y comienza con un ${hook} para captar la atención del espectador.
Incluye elementos visuales atractivos, música de fondo energética y transiciones suaves.
Asegúrate de que el mensaje principal sea claro y que el video tenga un llamado a la acción al final.
Mantén un ritmo dinámico y asegúrate de que la duración sea óptima (${duration}) para mantener la atención del espectador.
${keywords ? `Incluye las siguientes palabras clave: ${keywords}` : ""}

Este prompt fue generado por el servidor como fallback debido a que no se pudo obtener una respuesta válida de n8n.`
}
