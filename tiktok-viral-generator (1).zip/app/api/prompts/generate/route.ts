import { NextResponse } from "next/server"
import { createServerSupabaseClient } from "@/lib/supabase/server"
import { PromptGenerationService } from "@/lib/services/prompt-generation-service"
import { v4 as uuidv4 } from "uuid"

export async function POST(request: Request) {
  try {
    // Obtener el cliente de Supabase
    const supabase = createServerSupabaseClient()

    // Verificar la autenticación del usuario
    const {
      data: { session },
    } = await supabase.auth.getSession()

    if (!session) {
      return NextResponse.json({ success: false, error: "No autorizado" }, { status: 401 })
    }

    // Obtener los datos del cuerpo de la solicitud
    const body = await request.json()
    const { videoId, videoType, options } = body

    if (!videoId || !videoType || !options) {
      return NextResponse.json({ success: false, error: "Se requieren videoId, videoType y options" }, { status: 400 })
    }

    // Verificar que el video existe y pertenece al usuario
    const { data: video, error: videoError } = await supabase
      .from("videos")
      .select("*")
      .eq("id", videoId)
      .eq("user_id", session.user.id)
      .single()

    if (videoError || !video) {
      return NextResponse.json(
        { success: false, error: "Video no encontrado o no tienes permisos para acceder a él" },
        { status: 404 },
      )
    }

    // Generar el prompt
    try {
      const promptResult = PromptGenerationService.generatePrompt(videoType as any, options, {
        videoTitle: video.title,
      })

      // Guardar el prompt en la base de datos
      const promptId = uuidv4()
      const { error: promptError } = await supabase.from("video_prompts").insert({
        id: promptId,
        video_id: videoId,
        user_id: session.user.id,
        prompt_text: promptResult.prompt,
        input_context: options,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })

      if (promptError) {
        console.error("Error al guardar el prompt:", promptError)
        return NextResponse.json({ success: false, error: promptError.message }, { status: 500 })
      }

      return NextResponse.json({
        success: true,
        promptId,
        prompt: promptResult.prompt,
        metadata: promptResult.metadata,
      })
    } catch (error: any) {
      console.error("Error al generar el prompt:", error)
      return NextResponse.json({ success: false, error: error.message }, { status: 500 })
    }
  } catch (error: any) {
    console.error("Error en la API de generación de prompts:", error)
    return NextResponse.json({ success: false, error: error.message || "Error interno del servidor" }, { status: 500 })
  }
}
