import { NextResponse } from "next/server"

export async function GET(
  request: Request,
  { params }: { params: { platform: "tiktok" | "instagram" | "facebook"; id: string } },
) {
  const { platform, id } = params

  try {
    // Simulamos la obtención de detalles de un video
    console.log(`Simulando obtención de detalles de video ${id} de ${platform}`)

    // Creamos un video de ejemplo
    const mockVideo = {
      id,
      platform,
      url: `https://${platform}.com/video/${id}`,
      thumbnail: "/placeholder.svg?height=720&width=1280",
      title: `Video viral de ${platform} #${id}`,
      views: 2500000,
      likes: 150000,
      date: "2023-03-15",
      author: {
        name: `Creator${id}`,
        avatar: "/placeholder.svg?height=50&width=50",
        id: `creator${id}`,
      },
      description: `Este es un video viral de ${platform} con más de 2.5 millones de vistas. Perfecto para analizar y crear contenido similar.`,
      duration: "00:45",
      comments: 12500,
      shares: 45000,
    }

    return NextResponse.json({ success: true, video: mockVideo })
  } catch (error) {
    console.error(`Error al obtener detalles de video de ${platform}:`, error)
    return NextResponse.json(
      { success: false, error: `Error al obtener detalles de video de ${platform}` },
      { status: 500 },
    )
  }
}
