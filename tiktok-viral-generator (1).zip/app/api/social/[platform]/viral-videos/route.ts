import { NextResponse } from "next/server"

// Datos de ejemplo para simular videos virales
const mockVideos = {
  tiktok: [
    {
      id: "1",
      platform: "tiktok",
      url: "https://tiktok.com/video/1",
      thumbnail: "/placeholder.svg?height=180&width=320",
      title: "Baile viral de TikTok #1",
      views: 2500000,
      likes: 150000,
      date: "2023-03-15",
      author: {
        name: "DancerPro",
        avatar: "/placeholder.svg?height=50&width=50",
        id: "dancer1",
      },
    },
    {
      id: "2",
      platform: "tiktok",
      url: "https://tiktok.com/video/2",
      thumbnail: "/placeholder.svg?height=180&width=320",
      title: "Challenge de comida picante",
      views: 1800000,
      likes: 120000,
      date: "2023-03-10",
      author: {
        name: "FoodieChallenge",
        avatar: "/placeholder.svg?height=50&width=50",
        id: "foodie2",
      },
    },
  ],
  instagram: [
    {
      id: "1",
      platform: "instagram",
      url: "https://instagram.com/p/1",
      thumbnail: "/placeholder.svg?height=180&width=320",
      title: "Receta de pasta viral",
      views: 4500000,
      likes: 350000,
      date: "2023-03-18",
      author: {
        name: "ChefGourmet",
        avatar: "/placeholder.svg?height=50&width=50",
        id: "chef1",
      },
    },
    {
      id: "2",
      platform: "instagram",
      url: "https://instagram.com/p/2",
      thumbnail: "/placeholder.svg?height=180&width=320",
      title: "Tutorial de maquillaje tendencia",
      views: 2800000,
      likes: 190000,
      date: "2023-03-12",
      author: {
        name: "BeautyQueen",
        avatar: "/placeholder.svg?height=50&width=50",
        id: "beauty2",
      },
    },
  ],
  facebook: [
    {
      id: "1",
      platform: "facebook",
      url: "https://facebook.com/watch/1",
      thumbnail: "/placeholder.svg?height=180&width=320",
      title: "Experimento científico asombroso",
      views: 7500000,
      likes: 550000,
      date: "2023-03-20",
      author: {
        name: "ScienceGeek",
        avatar: "/placeholder.svg?height=50&width=50",
        id: "science1",
      },
    },
    {
      id: "2",
      platform: "facebook",
      url: "https://facebook.com/watch/2",
      thumbnail: "/placeholder.svg?height=180&width=320",
      title: "Rescate de animales conmovedor",
      views: 9800000,
      likes: 820000,
      date: "2023-03-14",
      author: {
        name: "AnimalRescue",
        avatar: "/placeholder.svg?height=50&width=50",
        id: "animal2",
      },
    },
  ],
}

export async function GET(request: Request, { params }: { params: { platform: "tiktok" | "instagram" | "facebook" } }) {
  const { platform } = params
  const { searchParams } = new URL(request.url)
  const minViews = Number.parseInt(searchParams.get("minViews") || "1000000")

  try {
    // Simulamos la obtención de videos virales
    console.log(`Simulando obtención de videos virales de ${platform}`)

    // Obtenemos los videos de ejemplo para la plataforma
    const videos = mockVideos[platform] || []

    // Filtramos por vistas mínimas
    const filteredVideos = videos.filter((video) => video.views >= minViews)

    return NextResponse.json({ success: true, videos: filteredVideos })
  } catch (error) {
    console.error(`Error al obtener videos virales de ${platform}:`, error)
    return NextResponse.json(
      { success: false, error: `Error al obtener videos virales de ${platform}` },
      { status: 500 },
    )
  }
}
