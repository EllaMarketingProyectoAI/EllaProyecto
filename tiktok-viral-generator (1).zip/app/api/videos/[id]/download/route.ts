import { type NextRequest, NextResponse } from "next/server"
import { getVideoWithOptions } from "@/lib/services/video-service"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const videoId = params.id

    if (!videoId) {
      return NextResponse.json({ error: "ID de video no proporcionado" }, { status: 400 })
    }

    // Obtener información del video
    const result = await getVideoWithOptions(videoId)

    if (!result.success) {
      return NextResponse.json({ error: result.error || "Error al obtener el video" }, { status: 404 })
    }

    // Generar un archivo de texto simulado
    const videoInfo = result.video
    const videoOptions = result.options

    // Crear un contenido de texto que simule el video
    const textContent = `
ARCHIVO DE VIDEO SIMULADO
=======================

ID: ${videoInfo.id}
Título: ${videoInfo.title}
Tipo: ${videoInfo.type}
Usuario: ${videoInfo.user_id}
Duración: ${videoInfo.duration || "00:00"}
Resolución: ${videoInfo.resolution || "1080p"}
Formato: ${videoInfo.format || "MP4"}
Creado: ${new Date(videoInfo.created_at).toLocaleString()}

OPCIONES DEL VIDEO
=================
${JSON.stringify(videoOptions, null, 2)}

NOTA: Este es un archivo de texto simulado que representa un video generado.
En una implementación real, este sería un archivo de video real en formato MP4.
`

    // Configurar la respuesta como un archivo de texto para descargar
    const headers = new Headers()
    headers.set("Content-Type", "text/plain")
    headers.set("Content-Disposition", `attachment; filename="${videoInfo.file_name || "video.txt"}"`)

    return new NextResponse(textContent, {
      status: 200,
      headers,
    })
  } catch (error) {
    console.error("Error al descargar el video:", error)
    return NextResponse.json({ error: "Error al procesar la descarga del video" }, { status: 500 })
  }
}
