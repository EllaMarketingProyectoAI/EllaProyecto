import { getSupabaseClient } from "@/lib/supabase/client"
import { v4 as uuidv4 } from "uuid"
import {
  generateGeneralVideo,
  generateClientVideo,
  type GeneralVideoOptions,
  type ClientVideoOptions,
} from "@/lib/services/video-generator-service"
import { NextResponse } from "next/server"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  const videoId = params.id

  // Simulamos la obtención de un video
  const videoData = {
    id: videoId,
    title: `Video #${videoId}`,
    url: `/api/videos/${videoId}`,
    downloadUrl: `/api/videos/${videoId}/download`,
    thumbnailUrl: `/placeholder.svg?height=720&width=1280&text=Video+${videoId}`,
    duration: "03:45",
    size: "45.2 MB",
    format: "MP4",
    resolution: "1080p",
    createdAt: new Date().toISOString(),
  }

  return NextResponse.json(videoData)
}

// Función de ayuda para depurar
const logDebug = (message: string, data?: any) => {
  console.log(`[VideoService] ${message}`, data || "")
}

// Función para crear un video general
export async function createGeneralVideo(userId: string, title: string, options: GeneralVideoOptions) {
  try {
    logDebug(`Iniciando creación de video general: ${title} para usuario ${userId}`)
    const supabase = getSupabaseClient()

    // Primero generamos el video simulado
    logDebug("Generando video con opciones:", options)
    const generatedVideo = await generateGeneralVideo({ ...options, title })
    logDebug("Video generado:", generatedVideo)

    // Asegurarnos de que la URL de la miniatura sea válida
    const thumbnailUrl =
      generatedVideo.thumbnailUrl && !generatedVideo.thumbnailUrl.startsWith("blob:")
        ? generatedVideo.thumbnailUrl
        : `/placeholder.svg?height=180&width=320&text=${encodeURIComponent(title)}`

    // Crear el video primero
    const videoInsertData = {
      id: generatedVideo.id,
      user_id: userId,
      title: title,
      url: generatedVideo.url,
      thumbnail_url: thumbnailUrl,
      type: "general",
      status: "completed",
      file_name: generatedVideo.fileName,
      file_size: generatedVideo.fileSize,
      file_type: generatedVideo.fileType,
      file_url: generatedVideo.fileUrl,
      duration: generatedVideo.duration,
      resolution: generatedVideo.resolution,
      format: generatedVideo.format,
      created_at: generatedVideo.createdAt,
    }

    logDebug("Insertando video con datos:", videoInsertData)

    const { error: videoError } = await supabase.from("videos").insert(videoInsertData)

    if (videoError) {
      console.error("Error al insertar video:", videoError)
      return { success: false, error: videoError.message }
    }

    logDebug("Video creado exitosamente con ID:", generatedVideo.id)

    // Preparar datos para opciones
    // Convertir arrays a strings para almacenamiento
    const bRollSourceValue = Array.isArray(options.b_roll_source)
      ? options.b_roll_source.join(",")
      : options.b_roll_source || null

    // Insertar opciones
    const optionsInsertData = {
      id: uuidv4(),
      video_id: generatedVideo.id,
      title: options.title,
      topic: options.topic,
      hook: options.hook,
      format: options.format,
      sources: options.sources,
      restricted_words: options.restricted_words || null,
      duration: options.duration,
      banned_topics: options.banned_topics || null,
      keywords: options.keywords || null,
      ai_voice_over: options.ai_voice_over,
      subtitles: options.subtitles,
      b_roll: options.b_roll,
      typography: options.typography || null,
      music_source: options.music_source || null,
      b_roll_source: bRollSourceValue,
      sound_effects_source: options.sound_effects_source || null,
    }

    logDebug("Insertando opciones con datos:", optionsInsertData)

    const { error: optionsError } = await supabase.from("video_general_options").insert(optionsInsertData)

    if (optionsError) {
      console.error("Error al insertar opciones:", optionsError)
      // Si falla la inserción de opciones, eliminamos el video para mantener consistencia
      await supabase.from("videos").delete().eq("id", generatedVideo.id)
      return { success: false, error: optionsError.message }
    }

    logDebug("Opciones guardadas exitosamente")
    return {
      success: true,
      videoId: generatedVideo.id,
      generatedVideo: {
        ...generatedVideo,
        thumbnailUrl: thumbnailUrl,
      },
    }
  } catch (error) {
    console.error("Error inesperado:", error)
    return { success: false, error: "Error inesperado al crear el video" }
  }
}

// Función para crear un video cliente
export async function createClientVideo(userId: string, title: string, options: ClientVideoOptions) {
  try {
    logDebug(`Iniciando creación de video cliente: ${title} para usuario ${userId}`)
    const supabase = getSupabaseClient()

    // Primero generamos el video simulado
    logDebug("Generando video con opciones:", options)
    const generatedVideo = await generateClientVideo(title, options)
    logDebug("Video generado:", generatedVideo)

    // Asegurarnos de que la URL de la miniatura sea válida
    const thumbnailUrl =
      generatedVideo.thumbnailUrl && !generatedVideo.thumbnailUrl.startsWith("blob:")
        ? generatedVideo.thumbnailUrl
        : `/placeholder.svg?height=180&width=320&text=${encodeURIComponent(title || generatedVideo.title)}`

    // Crear el video primero
    const videoInsertData = {
      id: generatedVideo.id,
      user_id: userId,
      title: title || generatedVideo.title,
      url: generatedVideo.url,
      thumbnail_url: thumbnailUrl,
      type: "client",
      status: "completed",
      file_name: generatedVideo.fileName,
      file_size: generatedVideo.fileSize,
      file_type: generatedVideo.fileType,
      file_url: generatedVideo.fileUrl,
      duration: generatedVideo.duration,
      resolution: generatedVideo.resolution,
      format: generatedVideo.format,
      created_at: generatedVideo.createdAt,
    }

    logDebug("Insertando video con datos:", videoInsertData)

    const { error: videoError } = await supabase.from("videos").insert(videoInsertData)

    if (videoError) {
      console.error("Error al insertar video:", videoError)
      return { success: false, error: videoError.message }
    }

    logDebug("Video creado exitosamente con ID:", generatedVideo.id)

    // Insertar opciones
    const optionsInsertData = {
      id: uuidv4(),
      video_id: generatedVideo.id,
      hook: options.hook,
      b_roll: options.b_roll,
      subtitles: options.subtitles,
      language: options.language,
    }

    logDebug("Insertando opciones con datos:", optionsInsertData)

    const { error: optionsError } = await supabase.from("video_client_options").insert(optionsInsertData)

    if (optionsError) {
      console.error("Error al insertar opciones:", optionsError)
      // Si falla la inserción de opciones, eliminamos el video para mantener consistencia
      await supabase.from("videos").delete().eq("id", generatedVideo.id)
      return { success: false, error: optionsError.message }
    }

    logDebug("Opciones guardadas exitosamente")
    return {
      success: true,
      videoId: generatedVideo.id,
      generatedVideo: {
        ...generatedVideo,
        thumbnailUrl: thumbnailUrl,
      },
    }
  } catch (error) {
    console.error("Error inesperado:", error)
    return { success: false, error: "Error inesperado al crear el video" }
  }
}

// Función para obtener los videos de un usuario
export async function getUserVideos(userId: string) {
  try {
    console.log("Obteniendo videos para el usuario:", userId)

    // Intentar obtener videos de Supabase
    const supabase = getSupabaseClient()

    // Añadir un timeout para la consulta
    const timeoutPromise = new Promise((_, reject) =>
      setTimeout(() => reject(new Error("Timeout al obtener videos")), 3000),
    )

    const queryPromise = supabase
      .from("videos")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })

    // Usar Promise.race para implementar un timeout
    const result = await Promise.race([queryPromise, timeoutPromise]).catch((error) => {
      console.error("Error o timeout al obtener videos:", error)
      // Devolver datos simulados en caso de error o timeout
      return {
        data: [
          {
            id: "1",
            user_id: userId,
            title: "Mi primer video viral",
            url: "/api/videos/1",
            thumbnail_url: "/placeholder.svg?height=180&width=320&text=Video+1",
            type: "general",
            status: "completed",
            created_at: new Date().toISOString(),
            file_name: "video1.mp4",
            file_size: 15000000,
            file_type: "video/mp4",
            file_url: "/api/videos/1/download",
            duration: "01:45",
            format: "MP4",
          },
          {
            id: "2",
            user_id: userId,
            title: "Tutorial de marketing",
            url: "/api/videos/2",
            thumbnail_url: "/placeholder.svg?height=180&width=320&text=Video+2",
            type: "client",
            status: "completed",
            created_at: new Date().toISOString(),
            file_name: "video2.mp4",
            file_size: 25000000,
            file_type: "video/mp4",
            file_url: "/api/videos/2/download",
            duration: "02:30",
            format: "MP4",
          },
        ],
        error: null,
      }
    })

    if ("error" in result && result.error) {
      console.error("Error al obtener los videos:", result.error)
      return { success: false, error: result.error.message }
    }

    const videos = "data" in result ? result.data : []

    // Asegurarnos de que todas las URLs de miniaturas sean válidas
    const processedVideos = videos.map((video) => {
      if (!video.thumbnail_url || video.thumbnail_url.startsWith("blob:")) {
        return {
          ...video,
          thumbnail_url: `/placeholder.svg?height=180&width=320&text=${encodeURIComponent(video.title)}`,
        }
      }
      return video
    })

    console.log(`Se encontraron ${processedVideos?.length || 0} videos para el usuario`)
    return { success: true, videos: processedVideos }
  } catch (error) {
    console.error("Error inesperado:", error)
    // En caso de error, devolver datos simulados para evitar pantalla de carga infinita
    return {
      success: true,
      videos: [
        {
          id: "1",
          user_id: userId,
          title: "Mi primer video viral",
          url: "/api/videos/1",
          thumbnail_url: "/placeholder.svg?height=180&width=320&text=Video+1",
          type: "general",
          status: "completed",
          created_at: new Date().toISOString(),
          file_name: "video1.mp4",
          file_size: 15000000,
          file_type: "video/mp4",
          file_url: "/api/videos/1/download",
          duration: "01:45",
          format: "MP4",
        },
        {
          id: "2",
          user_id: userId,
          title: "Tutorial de marketing",
          url: "/api/videos/2",
          thumbnail_url: "/placeholder.svg?height=180&width=320&text=Video+2",
          type: "client",
          status: "completed",
          created_at: new Date().toISOString(),
          file_name: "video2.mp4",
          file_size: 25000000,
          file_type: "video/mp4",
          file_url: "/api/videos/2/download",
          duration: "02:30",
          format: "MP4",
        },
      ],
    }
  }
}

// Función para obtener un video con sus opciones
export async function getVideoWithOptions(videoId: string) {
  try {
    const supabase = getSupabaseClient()

    // Obtenemos el video
    const { data: video, error: videoError } = await supabase.from("videos").select("*").eq("id", videoId).maybeSingle()

    if (videoError) {
      console.error("Error al obtener el video:", videoError)
      return { success: false, error: videoError.message }
    }

    if (!video) {
      return { success: false, error: "Video no encontrado" }
    }

    // Asegurarnos de que la URL de la miniatura sea válida
    if (!video.thumbnail_url || video.thumbnail_url.startsWith("blob:")) {
      video.thumbnail_url = `/placeholder.svg?height=180&width=320&text=${encodeURIComponent(video.title)}`
    }

    // Obtenemos las opciones según el tipo de video
    if (video.type === "general") {
      const { data: options, error: optionsError } = await supabase
        .from("video_general_options")
        .select("*")
        .eq("video_id", videoId)
        .maybeSingle()

      if (optionsError) {
        console.error("Error al obtener las opciones del video:", optionsError)
        return { success: false, error: optionsError.message }
      }

      return { success: true, video, options }
    } else if (video.type === "client") {
      const { data: options, error: optionsError } = await supabase
        .from("video_client_options")
        .select("*")
        .eq("video_id", videoId)
        .maybeSingle()

      if (optionsError) {
        console.error("Error al obtener las opciones del video:", optionsError)
        return { success: false, error: optionsError.message }
      }

      return { success: true, video, options }
    }

    return { success: true, video }
  } catch (error) {
    console.error("Error inesperado:", error)
    return { success: false, error: "Error inesperado al obtener el video" }
  }
}

// Función para guardar un archivo asociado a un video
export async function saveVideoFile(
  videoId: string,
  fileName: string,
  fileUrl: string,
  fileType: string,
  fileSize: number,
) {
  try {
    const supabase = getSupabaseClient()

    const fileData = {
      id: uuidv4(),
      video_id: videoId,
      name: fileName,
      url: fileUrl,
      type: fileType,
      size: fileSize,
    }

    const { error } = await supabase.from("files").insert(fileData)

    if (error) {
      console.error("Error al guardar el archivo:", error)
      return { success: false, error: error.message }
    }

    return { success: true }
  } catch (error) {
    console.error("Error inesperado:", error)
    return { success: false, error: "Error inesperado al guardar el archivo" }
  }
}

// Función para obtener los archivos de un video
export async function getVideoFiles(videoId: string) {
  try {
    const supabase = getSupabaseClient()

    const { data, error } = await supabase
      .from("files")
      .select("*")
      .eq("video_id", videoId)
      .order("created_at", { ascending: false })

    if (error) {
      console.error("Error al obtener los archivos:", error)
      return { success: false, error: error.message }
    }

    return { success: true, files: data }
  } catch (error) {
    console.error("Error inesperado:", error)
    return { success: false, error: "Error inesperado al obtener los archivos" }
  }
}
