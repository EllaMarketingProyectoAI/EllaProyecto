"use client"

import { AuthForm } from "@/components/auth-form"
import { useRouter } from "next/navigation"
import { useUserStore } from "@/lib/store/user-store"
import { useEffect } from "react"

export default function AuthPage() {
  const router = useRouter()
  const { isAuthenticated } = useUserStore()

  useEffect(() => {
    if (isAuthenticated) {
      router.push("/")
    }
  }, [isAuthenticated, router])

  const handleAuthSuccess = () => {
    router.push("/")
  }

  return (
    <div className="container max-w-md py-10">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-2">Bienvenido</h1>
        <p className="text-muted-foreground">
          Inicia sesión o crea una cuenta para acceder a todas las funcionalidades.
        </p>
      </div>
      <AuthForm onSuccess={handleAuthSuccess} />
    </div>
  )
}
