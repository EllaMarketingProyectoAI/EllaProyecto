"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useUserStore } from "@/lib/store/user-store"
import { VideoLibrary } from "@/components/video-library"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function DashboardClientPage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)
  const [userId, setUserId] = useState<string | undefined>(undefined)

  useEffect(() => {
    // Asegurarse de que el store esté hidratado
    const timer = setTimeout(() => {
      setIsLoading(false)

      // Obtener el ID del usuario actual
      const currentUser = useUserStore.getState().user
      console.log("Usuario actual:", currentUser)

      if (currentUser?.id) {
        setUserId(currentUser.id)
        console.log("ID de usuario establecido:", currentUser.id)
      } else {
        console.log("No se encontró un usuario autenticado")
        router.push("/auth")
      }
    }, 1000) // Aumentamos el tiempo para asegurar que el store esté hidratado

    return () => clearTimeout(timer)
  }, [router])

  // Mostrar estado de carga
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="h-12 w-12 rounded-full border-4 border-blue-600 border-t-transparent animate-spin mx-auto mb-4"></div>
          <p className="text-lg font-medium">Cargando...</p>
        </div>
      </div>
    )
  }

  // Si no hay ID de usuario, mostrar mensaje de inicio de sesión
  if (!userId) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4">
        <h1 className="text-2xl font-bold mb-4">Por favor inicia sesión para ver tu biblioteca de videos.</h1>
        <Link href="/auth">
          <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
            Iniciar sesión
          </Button>
        </Link>
      </div>
    )
  }

  // Si hay ID de usuario, mostrar la biblioteca de videos
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900">
      <VideoLibrary userId={userId} />
    </div>
  )
}
