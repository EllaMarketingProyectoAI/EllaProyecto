import { redirect } from "next/navigation"

export default function DashboardPage() {
  // Esta es una página de servidor que simplemente redirige a la página de cliente
  // Esto evita problemas de prerender con componentes de cliente
  redirect("/dashboard-client")
}
