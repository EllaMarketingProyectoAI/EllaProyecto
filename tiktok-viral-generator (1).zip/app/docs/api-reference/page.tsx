import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function ApiReferencePage() {
  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-2">Referencia de la API</h1>
      <p className="text-muted-foreground mb-8">
        Documentación completa de nuestra API para integración con n8n y otras herramientas
      </p>

      <Tabs defaultValue="generate-video">
        <TabsList className="mb-6">
          <TabsTrigger value="generate-video">Generate Video</TabsTrigger>
          <TabsTrigger value="webhook">Webhook</TabsTrigger>
          <TabsTrigger value="status">Status</TabsTrigger>
          <TabsTrigger value="process-inputs">Process Inputs</TabsTrigger>
        </TabsList>

        <TabsContent value="generate-video">
          <Card>
            <CardHeader>
              <CardTitle>POST /api/n8n/generate-video</CardTitle>
              <CardDescription>Genera un video viral basado en los parámetros proporcionados</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-2">Headers</h3>
                  <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-md">
                    <pre className="text-sm">
                      {`x-api-key: tu-api-key
Content-Type: application/json`}
                    </pre>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Request Body</h3>
                  <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-md">
                    <pre className="text-sm overflow-x-auto">
                      {`{
  "userId": "id-del-usuario",
  "videoType": "general" | "ai",
  "options": {
    // Para videoType: "general"
    "title": "Título del video",
    "topic": "Tema del video",
    "hook": "question" | "statistic" | "statement" | "story" | "challenge" | "demonstration",
    "format": "tutorial" | "vlog" | "interview" | "reaction" | "storytelling" | "review" | "educational" | "comedy",
    "sources": "Fuentes del video",
    "restricted_words": "Palabras restringidas",
    "duration": "15s" | "30s" | "60s" | "3min" | "5min" | "10min",
    "banned_topics": "Temas prohibidos",
    "keywords": "Palabras clave",
    "ai_voice_over": "yes" | "no",
    "subtitles": "yes" | "no",
    "b_roll": "stock" | "ai" | "both" | "none",
    "typography": "sans-serif" | "serif" | "monospace" | "cursive" | "fantasy",
    "music_source": "electronica" | "pop" | "rock" | "hip-hop" | "jazz" | "clasica" | "ambiental" | "epica" | "acustica" | "ninguna",
    "b_roll_source": ["stock-videos", "stock-photos", "ai-generated"],
    "sound_effects_source": "transiciones" | "notificaciones" | "ambiente" | "naturaleza" | "tecnologia" | "humor" | "deportes" | "musica" | "voces" | "ninguno"

    // Para videoType: "ai"
    "title": "  | "humor" | "deportes" | "musica" | "voces" | "ninguno"

    // Para videoType: "ai"
    "title": "Título del video",
    "prompt": "Descripción detallada del video que deseas generar",
    "duration": "15s" | "30s" | "60s" | "3min",
    "style": "modern" | "cinematic" | "vintage" | "minimalist" | "documentary",
    "aspectRatio": "9:16" | "16:9" | "1:1"
  }
}`}
                    </pre>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Response</h3>
                  <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-md">
                    <pre className="text-sm overflow-x-auto">
                      {`{
  "success": true,
  "videoId": "id-del-video-generado",
  "video": {
    "id": "id-del-video-generado",
    "title": "Título del video",
    "url": "/api/videos/id-del-video-generado",
    "thumbnailUrl": "/placeholder.svg?height=720&width=1280&text=Video",
    "fileName": "nombre-del-archivo.mp4",
    "fileSize": 15000000,
    "fileType": "video/mp4",
    "duration": "01:00",
    "resolution": "1080p",
    "format": "MP4",
    "createdAt": "2023-05-15T10:30:00Z"
  }
}`}
                    </pre>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="webhook">
          <Card>
            <CardHeader>
              <CardTitle>POST /api/n8n/webhook</CardTitle>
              <CardDescription>Registra un webhook para procesamiento asíncrono</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-2">Headers</h3>
                  <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-md">
                    <pre className="text-sm">
                      {`x-api-key: tu-api-key
Content-Type: application/json`}
                    </pre>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Request Body</h3>
                  <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-md">
                    <pre className="text-sm overflow-x-auto">
                      {`{
  "userId": "id-del-usuario",
  "videoType": "general" | "ai",
  "options": {
    // Mismas opciones que en generate-video
  },
  "callbackUrl": "https://tu-instancia-n8n.com/webhook/callback" // Opcional
}`}
                    </pre>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Response</h3>
                  <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-md">
                    <pre className="text-sm overflow-x-auto">
                      {`{
  "success": true,
  "message": "Webhook registered successfully",
  "requestId": "id-de-la-solicitud"
}`}
                    </pre>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Callback Payload</h3>
                  <p className="mb-2">
                    Si proporcionas un callbackUrl, recibirás una notificación con el siguiente formato cuando el
                    proceso termine:
                  </p>
                  <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-md">
                    <pre className="text-sm overflow-x-auto">
                      {`{
  "requestId": "id-de-la-solicitud",
  "status": "completed" | "failed",
  "result": {
    "videoId": "id-del-video-generado",
    "video": {
      // Detalles del video
    }
  },
  "error": "Mensaje de error si status es failed"
}`}
                    </pre>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="status">
          <Card>
            <CardHeader>
              <CardTitle>GET /api/n8n/status/[requestId]</CardTitle>
              <CardDescription>Consulta el estado de una solicitud de webhook</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-2">Headers</h3>
                  <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-md">
                    <pre className="text-sm">{`x-api-key: tu-api-key`}</pre>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Path Parameters</h3>
                  <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-md">
                    <pre className="text-sm overflow-x-auto">{`requestId: ID de la solicitud de webhook`}</pre>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Response</h3>
                  <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-md">
                    <pre className="text-sm overflow-x-auto">
                      {`{
  "success": true,
  "requestId": "id-de-la-solicitud",
  "status": "pending" | "processing" | "completed" | "failed",
  "result": {
    // Resultado si status es completed
  },
  "error": "Mensaje de error si status es failed",
  "createdAt": "2023-05-15T10:30:00Z"
}`}
                    </pre>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="process-inputs">
          <Card>
            <CardHeader>
              <CardTitle>POST /api/n8n/process-inputs</CardTitle>
              <CardDescription>Procesa los inputs del usuario y genera un prompt refinado</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-2">Headers</h3>
                  <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-md">
                    <pre className="text-sm">
                      {`x-api-key: tu-api-key
Content-Type: application/json`}
                    </pre>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Request Body</h3>
                  <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-md">
                    <pre className="text-sm overflow-x-auto">
                      {`{
  "videoType": "client" | "general" | "ai",
  "inputs": {
    // Para videoType: "client"
    "title": "Título del video",
    "hook": "question" | "statistic" | "statement" | "story" | "challenge" | "demonstration",
    "bRoll": "stock" | "ai" | "both" | "none",
    "subtitles": "yes" | "no",
    "language": "es" | "en" | "fr" | "de" | "it" | "pt",

    // Para videoType: "general"
    "title": "Título del video",
    "topic": "Tema principal",
    "hook": "question" | "statistic" | "statement" | "story" | "challenge" | "demonstration",
    "format": "tutorial" | "vlog" | "interview" | "reaction" | "storytelling" | "review" | "educational" | "comedy",
    "sources": "Fuentes del video",
    "restrictedWords": "Palabras a evitar",
    "duration": "15s" | "30s" | "60s" | "3min" | "5min" | "10min",
    "bannedTopics": "Temas prohibidos",
    "keywords": "Palabras clave",
    "aiVoiceOver": "yes" | "no",
    "subtitles": "yes" | "no",
    "bRoll": "stock" | "ai" | "both" | "none",
    "typography": "sans-serif" | "serif" | "monospace" | "cursive" | "fantasy",
    "musicSource": "electronica" | "pop" | "rock" | "hip-hop" | "jazz" | "clasica" | "ambiental" | "epica" | "acustica" | "ninguna",
    "bRollSource": ["stock-videos", "stock-photos", "ai-generated"],
    "soundEffectsSource": "transiciones" | "notificaciones" | "ambiente" | "naturaleza" | "tecnologia" | "humor" | "deportes" | "musica" | "voces" | "ninguno",

    // Para videoType: "ai"
    "title": "Título del video",
    "prompt": "Descripción detallada del video",
    "duration": "15s" | "30s" | "60s" | "3min",
    "style": "modern" | "cinematic" | "vintage" | "minimalist" | "documentary",
    "aspectRatio": "9:16" | "16:9" | "1:1"
  }
}`}
                    </pre>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Response</h3>
                  <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-md">
                    <pre className="text-sm overflow-x-auto">
                      {`{
  "success": true,
  "videoType": "client" | "general" | "ai",
  "refinedPrompt": "Prompt refinado generado a partir de los inputs",
  "originalInputs": {
    // Los inputs originales enviados en la petición
  }
}`}
                    </pre>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
