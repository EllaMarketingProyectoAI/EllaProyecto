import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { Code } from "lucide-react"

export default function N8nIntegrationPage() {
  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-2">Integración con n8n</h1>
      <p className="text-muted-foreground mb-8">
        Aprende cómo integrar n8n con nuestra plataforma para automatizar la creación de videos virales
      </p>

      <div className="grid gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Introducción</CardTitle>
            <CardDescription>
              n8n es una herramienta de automatización de flujos de trabajo que te permite conectar diferentes servicios
              y automatizar tareas.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="mb-4">Con nuestra integración de n8n, puedes:</p>
            <ul className="list-disc pl-6 space-y-2 mb-4">
              <li>Generar videos virales automáticamente con diferentes prompts</li>
              <li>Programar la creación de videos en momentos específicos</li>
              <li>Conectar con otras herramientas como Google Sheets, Airtable o bases de datos</li>
              <li>Crear flujos de trabajo complejos para la generación de contenido</li>
            </ul>
            <p>
              Para comenzar, necesitarás una cuenta en{" "}
              <a
                href="https://n8n.io/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline"
              >
                n8n.io
              </a>{" "}
              y configurar un flujo de trabajo que se conecte a nuestra API.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Configuración de la API</CardTitle>
            <CardDescription>Configura la conexión entre n8n y nuestra plataforma</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-medium mb-2">1. Obtén tu API Key</h3>
                <p className="mb-2">
                  Para conectar n8n con nuestra plataforma, necesitarás una API Key. Puedes obtenerla en la sección de
                  configuración de tu cuenta.
                </p>
                <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-md">
                  <p className="font-mono text-sm">API Key: n8n-viral-video-maker-key</p>
                  <p className="text-xs text-muted-foreground mt-2">
                    Nota: Esta es una API Key de ejemplo. En producción, deberías generar una API Key única y segura.
                  </p>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium mb-2">2. Configura el nodo HTTP Request en n8n</h3>
                <p className="mb-2">
                  En tu flujo de trabajo de n8n, añade un nodo "HTTP Request" y configúralo con los siguientes
                  parámetros:
                </p>
                <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-md">
                  <ul className="space-y-2">
                    <li>
                      <strong>Método:</strong> POST
                    </li>
                    <li>
                      <strong>URL:</strong> https://tu-dominio.com/api/n8n/generate-video
                    </li>
                    <li>
                      <strong>Headers:</strong> x-api-key: tu-api-key
                    </li>
                    <li>
                      <strong>Body:</strong> JSON
                    </li>
                  </ul>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium mb-2">3. Estructura del cuerpo de la petición</h3>
                <p className="mb-2">El cuerpo de la petición debe tener la siguiente estructura:</p>
                <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-md">
                  <pre className="text-sm overflow-x-auto">
                    {`{
  "userId": "id-del-usuario",
  "videoType": "general",
  "options": {
    "title": "Título del video",
    "topic": "Tema del video",
    "hook": "question",
    "format": "tutorial",
    "sources": "Fuentes del video",
    "duration": "60s",
    "ai_voice_over": "yes",
    "subtitles": "yes",
    "b_roll": "stock"
    // Otras opciones según el tipo de video
  }
}`}
                  </pre>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium mb-2">4. Procesamiento asíncrono con webhooks</h3>
                <p className="mb-2">Para procesos que pueden tomar tiempo, puedes usar nuestro endpoint de webhook:</p>
                <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-md">
                  <ul className="space-y-2">
                    <li>
                      <strong>URL:</strong> https://tu-dominio.com/api/n8n/webhook
                    </li>
                    <li>
                      <strong>Método:</strong> POST
                    </li>
                    <li>
                      <strong>Headers:</strong> x-api-key: tu-api-key
                    </li>
                    <li>
                      <strong>Body:</strong> Igual que el anterior, pero puedes añadir un callbackUrl para recibir una
                      notificación cuando el proceso termine
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Ejemplos de flujos de trabajo</CardTitle>
            <CardDescription>Ejemplos de flujos de trabajo que puedes crear con n8n</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-2">Ejemplo 1: Generación de video general</h3>
                <p className="mb-2">Este flujo de trabajo genera un video general con un tema específico:</p>
                <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-md">
                  <pre className="text-sm overflow-x-auto">
                    {`{
  "userId": "id-del-usuario",
  "videoType": "general",
  "options": {
    "title": "Cómo hacer un video viral en TikTok",
    "topic": "Marketing en redes sociales",
    "hook": "question",
    "format": "tutorial",
    "sources": "Investigación propia",
    "duration": "60s",
    "ai_voice_over": "yes",
    "subtitles": "yes",
    "b_roll": "stock"
  }
}`}
                  </pre>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium mb-2">Ejemplo 2: Generación de video con IA</h3>
                <p className="mb-2">Este flujo de trabajo genera un video utilizando IA:</p>
                <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-md">
                  <pre className="text-sm overflow-x-auto">
                    {`{
  "userId": "id-del-usuario",
  "videoType": "ai",
  "options": {
    "title": "Tendencias de moda para el verano",
    "prompt": "Un video mostrando las últimas tendencias de moda para el verano, con modelos caminando en una pasarela al aire libre con ropa colorida y ligera.",
    "duration": "30s",
    "style": "modern",
    "aspectRatio": "9:16"
  }
}`}
                  </pre>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium mb-2">Ejemplo 3: Generación programada con Google Sheets</h3>
                <p className="mb-2">
                  Este flujo de trabajo lee datos de Google Sheets y genera videos automáticamente:
                </p>
                <ol className="list-decimal pl-6 space-y-2">
                  <li>Configura un nodo de Google Sheets para leer datos de una hoja</li>
                  <li>Usa un nodo "Iterator" para procesar cada fila</li>
                  <li>Configura un nodo HTTP Request para enviar los datos a nuestra API</li>
                  <li>Opcionalmente, añade un nodo para guardar los resultados en otra hoja</li>
                </ol>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recursos adicionales</CardTitle>
            <CardDescription>Enlaces y recursos para aprender más sobre n8n y nuestra API</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2">
              <Link href="/docs/api-reference" className="block">
                <Button variant="outline" className="w-full justify-start">
                  <Code className="mr-2 h-4 w-4" />
                  Referencia de la API
                </Button>
              </Link>
              <a href="https://docs.n8n.io/" target="_blank" rel="noopener noreferrer" className="block">
                <Button variant="outline" className="w-full justify-start">
                  <Code className="mr-2 h-4 w-4" />
                  Documentación de n8n
                </Button>
              </a>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
