import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Generación de Prompts con n8n | Documentación",
  description: "Aprende a generar prompts refinados para videos virales usando n8n",
}

export default function N8nPromptGenerationPage() {
  return (
    <div className="container mx-auto py-10">
      <h1 className="text-4xl font-bold mb-6">Generación de Prompts con n8n</h1>

      <div className="prose max-w-none">
        <h2>Introducción</h2>
        <p>
          Esta guía explica cómo utilizar n8n para capturar todos los inputs de los diferentes tipos de videos (cliente,
          general, IA) y generar prompts refinados para la creación de videos virales.
        </p>

        <h2>Endpoint para Procesamiento de Inputs</h2>
        <p>Hemos creado un endpoint específico para procesar los inputs y generar prompts refinados:</p>
        <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto">
          <code>POST /api/n8n/process-inputs</code>
        </pre>

        <h3>Autenticación</h3>
        <p>
          Para autenticarte, debes incluir tu API key en el encabezado <code>x-api-key</code>.
        </p>

        <h3>Cuerpo de la Solicitud</h3>
        <p>El cuerpo de la solicitud debe incluir:</p>
        <ul>
          <li>
            <code>videoId</code>: El ID del video
          </li>
          <li>
            <code>videoType</code>: El tipo de video ('general', 'client', o 'ai')
          </li>
        </ul>

        <p>Para videos de tipo 'ai', también debes incluir:</p>
        <ul>
          <li>
            <code>title</code>: El título del video
          </li>
          <li>
            <code>description</code>: La descripción detallada
          </li>
          <li>
            <code>duration</code>: La duración del video
          </li>
          <li>
            <code>style</code>: El estilo del video
          </li>
          <li>
            <code>aspectRatio</code>: La relación de aspecto
          </li>
        </ul>

        <h3>Respuesta</h3>
        <p>La respuesta incluirá:</p>
        <ul>
          <li>
            <code>prompt</code>: El prompt refinado generado
          </li>
          <li>
            <code>metadata</code>: Metadatos adicionales sobre el video
          </li>
        </ul>

        <h2>Configuración de n8n</h2>
        <p>Para configurar n8n para usar este endpoint, sigue estos pasos:</p>

        <h3>1. Crear un nuevo flujo de trabajo</h3>
        <p>Crea un nuevo flujo de trabajo en n8n.</p>

        <h3>2. Añadir un nodo HTTP Request</h3>
        <p>Añade un nodo HTTP Request con la siguiente configuración:</p>
        <ul>
          <li>Método: POST</li>
          <li>URL: https://tu-dominio.com/api/n8n/process-inputs</li>
          <li>Autenticación: Header Auth</li>
          <li>Nombre del encabezado: x-api-key</li>
          <li>Valor del encabezado: Tu API key</li>
        </ul>

        <h3>3. Configurar el cuerpo de la solicitud</h3>
        <p>Configura el cuerpo de la solicitud según el tipo de video:</p>

        <h4>Para videos generales:</h4>
        <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto">
          <code>{`{
  "videoId": "{{$node["Input"].json["videoId"]}}",
  "videoType": "general"
}`}</code>
        </pre>

        <h4>Para videos de cliente:</h4>
        <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto">
          <code>{`{
  "videoId": "{{$node["Input"].json["videoId"]}}",
  "videoType": "client"
}`}</code>
        </pre>

        <h4>Para videos de IA:</h4>
        <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto">
          <code>{`{
  "videoId": "{{$node["Input"].json["videoId"]}}",
  "videoType": "ai",
  "title": "{{$node["Input"].json["title"]}}",
  "description": "{{$node["Input"].json["description"]}}",
  "duration": "{{$node["Input"].json["duration"]}}",
  "style": "{{$node["Input"].json["style"]}}",
  "aspectRatio": "{{$node["Input"].json["aspectRatio"]}}"
}`}</code>
        </pre>

        <h3>4. Procesar la respuesta</h3>
        <p>
          Ahora puedes usar el prompt refinado en el resto de tu flujo de trabajo. Por ejemplo, puedes enviarlo a un
          modelo de IA para generar el contenido del video.
        </p>

        <h2>Ejemplos de Uso</h2>

        <h3>Ejemplo 1: Generar un prompt para un video general</h3>
        <p>Este ejemplo muestra cómo generar un prompt para un video general:</p>
        <ol>
          <li>El usuario crea un nuevo video general en la plataforma</li>
          <li>n8n captura el ID del video</li>
          <li>n8n envía una solicitud al endpoint de procesamiento de inputs</li>
          <li>El endpoint genera un prompt refinado basado en las opciones del video</li>
          <li>n8n utiliza el prompt para generar el contenido del video</li>
        </ol>

        <h3>Ejemplo 2: Generar un prompt para un video de cliente</h3>
        <p>Este ejemplo muestra cómo generar un prompt para un video de cliente:</p>
        <ol>
          <li>El usuario sube un video y configura las opciones de cliente</li>
          <li>n8n captura el ID del video</li>
          <li>n8n envía una solicitud al endpoint de procesamiento de inputs</li>
          <li>El endpoint genera un prompt refinado basado en las opciones del cliente</li>
          <li>n8n utiliza el prompt para procesar el video del cliente</li>
        </ol>

        <h2>Conclusión</h2>
        <p>
          Con esta implementación, puedes utilizar n8n para capturar todos los inputs de tus formularios de creación de
          videos y generar prompts refinados para la creación de videos virales.
        </p>
      </div>
    </div>
  )
}
