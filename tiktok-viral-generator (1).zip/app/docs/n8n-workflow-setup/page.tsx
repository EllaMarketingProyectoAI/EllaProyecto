import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Configuración de Workflows en n8n | Viral Video Maker",
  description: "Guía para configurar workflows en n8n para la generación de prompts",
}

export default function N8nWorkflowSetupPage() {
  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-6">Configuración de Workflows en n8n</h1>

      <div className="prose max-w-none">
        <h2>Configuración del Workflow para Generación de Prompts</h2>

        <p>Esta guía te ayudará a configurar un workflow en n8n para la generación de prompts para videos virales.</p>

        <h3>Requisitos previos</h3>
        <ul>
          <li>Una instancia de n8n en funcionamiento (cloud o self-hosted)</li>
          <li>Acceso a la interfaz de n8n</li>
          <li>Conocimientos básicos de n8n</li>
        </ul>

        <h3>Paso 1: Crear un nuevo workflow</h3>
        <ol>
          <li>Inicia sesión en tu instancia de n8n</li>
          <li>Haz clic en "Workflows" en el menú lateral</li>
          <li>Haz clic en "Create new workflow"</li>
          <li>Dale un nombre descriptivo como "Viral Video Prompt Generator"</li>
        </ol>

        <h3>Paso 2: Configurar el nodo Webhook</h3>
        <ol>
          <li>Añade un nodo "Webhook" al workflow</li>
          <li>Configura el webhook para recibir solicitudes POST</li>
          <li>Activa la opción "Respond to webhook"</li>
          <li>Guarda el workflow para obtener la URL del webhook</li>
        </ol>

        <h3>Paso 3: Añadir nodo de autenticación</h3>
        <ol>
          <li>Añade un nodo "Function" después del webhook</li>
          <li>Configura el código para validar la clave API:</li>
          <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto">
            {`// Código para validar la clave API
const apiKey = $input.body.apiKey || $input.headers['x-api-key'];
const validApiKey = '{{$env.N8N_API_KEY}}'; // Configura esta variable en n8n

if (!apiKey || apiKey !== validApiKey) {
  return {
    json: {
      success: false,
      error: 'Invalid API key'
    }
  };
}

// Continuar con el procesamiento
return $input;`}
          </pre>
        </ol>

        <h3>Paso 4: Añadir lógica de generación de prompts</h3>
        <ol>
          <li>Añade un nodo "Switch" para manejar diferentes tipos de videos</li>
          <li>Configura casos para cada tipo de video (general, client, ai)</li>
          <li>Para cada tipo, añade un nodo "Function" con la lógica específica</li>
          <li>Ejemplo de función para videos generales:</li>
          <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto">
            {`// Generación de prompt para videos generales
const { videoId, inputContext } = $input.body;

// Extraer información relevante
const title = inputContext.title || 'Video sin título';
const topic = inputContext.topic || 'Tema no especificado';
const format = inputContext.format || 'Formato no especificado';
const hook = inputContext.hook || 'Hook no especificado';

// Generar el prompt
const prompt = \`Crea un video viral sobre "\${title}" que trate sobre \${topic}. 
Utiliza un formato de \${format} y comienza con un \${hook} para captar la atención del espectador.
Incluye elementos visuales atractivos, música de fondo energética y transiciones suaves.
Asegúrate de que el mensaje principal sea claro y que el video tenga un llamado a la acción al final.
Mantén un ritmo dinámico y asegúrate de que la duración sea óptima para mantener la atención del espectador.\`;

// Devolver el resultado
return {
  json: {
    success: true,
    promptText: prompt,
    workflowId: $workflow.id,
    executionId: $execution.id,
    metadata: {
      videoType: 'general',
      generatedAt: new Date().toISOString(),
      inputSummary: {
        title,
        topic,
        format,
        hook
      }
    }
  }
};`}
          </pre>
        </ol>

        <h3>Paso 5: Configurar la respuesta del webhook</h3>
        <ol>
          <li>Conecta todos los nodos de función al nodo "Respond to Webhook"</li>
          <li>Configura el nodo para devolver el resultado en formato JSON</li>
        </ol>

        <h3>Paso 6: Activar el workflow</h3>
        <ol>
          <li>Haz clic en "Activate" en la parte superior del editor</li>
          <li>Copia la URL del webhook</li>
        </ol>

        <h3>Paso 7: Configurar las variables de entorno en tu aplicación</h3>
        <ol>
          <li>
            Añade la URL del webhook a la variable de entorno <code>N8N_WORKFLOW_URL</code>
          </li>
          <li>
            Configura la misma clave API en la variable de entorno <code>N8N_API_KEY</code>
          </li>
        </ol>

        <h2>Estructura de la solicitud</h2>
        <p>Tu aplicación debe enviar una solicitud POST al webhook con la siguiente estructura:</p>
        <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto">
          {`{
  "userId": "id-del-usuario",
  "videoId": "id-del-video",
  "videoType": "general|client|ai",
  "inputContext": {
    "title": "Título del video",
    "topic": "Tema del video",
    "format": "Formato del video",
    "hook": "Hook del video",
    // Otros campos específicos del tipo de video
  },
  "requestId": "id-de-seguimiento-opcional"
}`}
        </pre>

        <h2>Estructura de la respuesta</h2>
        <p>El workflow debe devolver una respuesta con la siguiente estructura:</p>
        <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto">
          {`{
  "success": true,
  "promptText": "Texto del prompt generado",
  "workflowId": "id-del-workflow",
  "executionId": "id-de-la-ejecución",
  "metadata": {
    "videoType": "tipo-de-video",
    "generatedAt": "fecha-hora",
    "inputSummary": {
      // Resumen de los inputs utilizados
    }
  }
}`}
        </pre>

        <h2>Ejemplos avanzados</h2>
        <p>Para mejorar la calidad de los prompts generados, puedes:</p>
        <ul>
          <li>Integrar un nodo de OpenAI para generar prompts más creativos</li>
          <li>Añadir nodos HTTP Request para obtener información adicional</li>
          <li>Implementar lógica condicional basada en el tipo de video</li>
          <li>Utilizar plantillas predefinidas y personalizarlas con los datos de entrada</li>
        </ul>

        <h2>Solución de problemas</h2>
        <ul>
          <li>
            <strong>Error de autenticación:</strong> Verifica que la clave API sea correcta
          </li>
          <li>
            <strong>Timeout:</strong> Asegúrate de que el workflow no tarde demasiado en ejecutarse
          </li>
          <li>
            <strong>Errores de formato:</strong> Verifica la estructura de la solicitud y la respuesta
          </li>
        </ul>
      </div>
    </div>
  )
}
