import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Documentación de Generación de Prompts | Viral Video Maker",
  description: "Aprende cómo funciona la generación de prompts con n8n en Viral Video Maker",
}

export default function PromptGenerationDocsPage() {
  return (
    <div className="container py-10">
      <div className="max-w-4xl mx-auto space-y-8">
        <div>
          <h1 className="text-4xl font-bold mb-4">Documentación de Generación de Prompts</h1>
          <p className="text-xl text-muted-foreground">
            Aprende cómo funciona la integración de n8n para generar prompts basados en las entradas del usuario.
          </p>
        </div>

        <div className="space-y-6">
          <section className="space-y-4">
            <h2 className="text-2xl font-bold">Introducción</h2>
            <p>
              La generación de prompts es una característica que permite crear automáticamente guiones y descripciones
              detalladas para tus videos virales basados en las opciones que configuras durante el proceso de creación.
              Estos prompts pueden ser utilizados para:
            </p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Generar contenido con modelos de lenguaje como GPT-4</li>
              <li>Crear guiones detallados para tus videos</li>
              <li>Obtener ideas y sugerencias para mejorar tu contenido</li>
              <li>Mantener un registro de las instrucciones utilizadas para cada video</li>
            </ul>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold">Cómo funciona</h2>
            <p>
              Cuando creas un nuevo video en la plataforma, el sistema automáticamente genera un prompt basado en las
              opciones que has configurado. Este proceso ocurre en segundo plano y no requiere ninguna acción adicional
              por tu parte.
            </p>

            <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-lg">
              <h3 className="text-lg font-semibold mb-2">Flujo de trabajo</h3>
              <ol className="list-decimal pl-6 space-y-2">
                <li>Configuras las opciones para tu video (título, tema, formato, etc.)</li>
                <li>Envías el formulario para crear el video</li>
                <li>El sistema guarda el video y sus opciones en la base de datos</li>
                <li>Se envían las opciones al servicio de generación de prompts a través de la integración con n8n</li>
                <li>El servicio genera un prompt detallado basado en tus opciones</li>
                <li>El prompt generado se almacena en la base de datos y se asocia con tu video</li>
                <li>Puedes ver y utilizar el prompt en la página de detalles del video</li>
              </ol>
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold">Tipos de prompts</h2>
            <p>El sistema puede generar diferentes tipos de prompts dependiendo del tipo de video que estés creando:</p>

            <div className="grid gap-4 md:grid-cols-3">
              <div className="border rounded-lg p-4">
                <h3 className="text-lg font-semibold mb-2">Videos Generales</h3>
                <p className="text-sm">
                  Para videos virales generales, el prompt incluye información sobre el título, tema, hook, formato,
                  duración, fuentes, elementos visuales y restricciones.
                </p>
              </div>

              <div className="border rounded-lg p-4">
                <h3 className="text-lg font-semibold mb-2">Videos de Cliente</h3>
                <p className="text-sm">
                  Para videos subidos por el cliente, el prompt se centra en cómo mejorar el video existente con hooks,
                  b-roll, subtítulos y consideraciones de idioma.
                </p>
              </div>

              <div className="border rounded-lg p-4">
                <h3 className="text-lg font-semibold mb-2">Videos de IA</h3>
                <p className="text-sm">
                  Para videos generados por IA, el prompt incluye instrucciones detalladas sobre el contenido, estilo
                  visual, duración y relación de aspecto.
                </p>
              </div>
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold">Estructura del prompt</h2>
            <p>Todos los prompts generados siguen una estructura similar que incluye las siguientes secciones:</p>

            <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-lg space-y-3">
              <div>
                <h3 className="text-lg font-semibold">Información básica</h3>
                <p className="text-sm">Título, tema, hook y formato del video.</p>
              </div>

              <div>
                <h3 className="text-lg font-semibold">Especificaciones técnicas</h3>
                <p className="text-sm">Duración, relación de aspecto, estilo visual, etc.</p>
              </div>

              <div>
                <h3 className="text-lg font-semibold">Elementos del video</h3>
                <p className="text-sm">Voz en off, subtítulos, b-roll, tipografía, etc.</p>
              </div>

              <div>
                <h3 className="text-lg font-semibold">Restricciones</h3>
                <p className="text-sm">Palabras restringidas, temas prohibidos, etc.</p>
              </div>

              <div>
                <h3 className="text-lg font-semibold">Estructura del guión</h3>
                <p className="text-sm">
                  Instrucciones para estructurar el guión en introducción, desarrollo y conclusión.
                </p>
              </div>
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold">Visualización de prompts</h2>
            <p>
              Puedes ver los prompts generados para tus videos en la página de detalles del video, en la pestaña
              "Prompts". Desde allí, puedes:
            </p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Ver el texto completo del prompt</li>
              <li>Copiar el prompt al portapapeles</li>
              <li>Ver el contexto de entrada utilizado para generar el prompt</li>
              <li>Ver información sobre el flujo de trabajo de n8n utilizado</li>
            </ul>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold">Integración con n8n</h2>
            <p>
              La generación de prompts utiliza n8n como motor de automatización para procesar las entradas del usuario y
              generar los prompts. Esta integración permite:
            </p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Procesar las entradas del usuario de manera asíncrona</li>
              <li>Personalizar la lógica de generación de prompts sin modificar el código de la aplicación</li>
              <li>Integrar con otros servicios y APIs para enriquecer los prompts</li>
              <li>Monitorear y registrar el proceso de generación de prompts</li>
            </ul>

            <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-900/30 p-4 rounded-lg">
              <h3 className="text-lg font-semibold mb-2 flex items-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="w-5 h-5 mr-2 text-yellow-600 dark:text-yellow-400"
                >
                  <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
                  <line x1="12" y1="9" x2="12" y2="13"></line>
                  <line x1="12" y1="17" x2="12.01" y2="17"></line>
                </svg>
                Nota importante
              </h3>
              <p className="text-sm">
                Para utilizar la integración con n8n, asegúrate de que la variable de entorno{" "}
                <code className="bg-slate-200 dark:bg-slate-800 px-1 py-0.5 rounded">NEXT_PUBLIC_APP_URL</code> esté
                configurada correctamente en tu proyecto de Vercel.
              </p>
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold">Ejemplos de prompts</h2>
            <p>A continuación se muestran algunos ejemplos de prompts generados para diferentes tipos de videos:</p>

            <div className="space-y-4">
              <div className="border rounded-lg overflow-hidden">
                <div className="bg-slate-50 dark:bg-slate-900 p-3">
                  <h3 className="font-medium">Ejemplo de prompt para video general</h3>
                </div>
                <div className="p-4">
                  <div className="bg-slate-100 dark:bg-slate-800 p-3 rounded-md whitespace-pre-wrap font-mono text-sm">
                    {`Crea un guión para un video viral de TikTok sobre "Consejos de productividad". El título del video es: "5 hábitos que cambiaron mi vida". El hook principal debe ser: "Estos 5 hábitos aumentaron mi productividad un 200%". La duración del video debe ser aproximadamente 60 segundos. Utiliza la siguiente información como fuente: "Estudios recientes sobre productividad y gestión del tiempo". Incluye una voz en off generada por IA. El video debe incluir subtítulos. Para el B-roll, utiliza: "Personas trabajando, relojes, calendarios, dispositivos electrónicos". El estilo de tipografía debe ser: "Moderno y minimalista". Evita usar las siguientes palabras: "procrastinar, pereza, difícil". No menciones los siguientes temas: "Medicamentos, suplementos". Incluye las siguientes keywords o hashtags: "#productividad #hábitos #vidaeficiente".
    
Estructura el guión en las siguientes secciones:

1. INTRODUCCIÓN / HOOK: Un gancho poderoso para captar la atención inmediatamente.
2. DESARROLLO: El contenido principal organizado de manera clara y atractiva.
3. CONCLUSIÓN: Un cierre impactante con llamada a la acción.

Para cada sección, especifica:
- Texto exacto para la voz en off o diálogo
- Descripción de las imágenes o B-roll que se mostrarán
- Efectos visuales, textos en pantalla o gráficos necesarios
- Música o efectos de sonido recomendados

El guión debe ser detallado, específico y optimizado para maximizar la retención de la audiencia y el engagement.`}
                  </div>
                </div>
              </div>

              <div className="border rounded-lg overflow-hidden">
                <div className="bg-slate-50 dark:bg-slate-900 p-3">
                  <h3 className="font-medium">Ejemplo de prompt para video de cliente</h3>
                </div>
                <div className="p-4">
                  <div className="bg-slate-100 dark:bg-slate-800 p-3 rounded-md whitespace-pre-wrap font-mono text-sm">
                    {`Crea un guión para mejorar un video existente titulado "Mi viaje a Japón". El hook principal debe ser: "Descubre los secretos ocultos de Tokio que ningún turista conoce". El video debe incluir subtítulos. Para el B-roll, utiliza: "Calles de Tokio, templos, comida japonesa, transporte público". El idioma del video debe ser: "Español".
    
Estructura el guión en las siguientes secciones:

1. INTRODUCCIÓN / HOOK: Un gancho poderoso para captar la atención inmediatamente.
2. DESARROLLO: El contenido principal organizado de manera clara y atractiva.
3. CONCLUSIÓN: Un cierre impactante con llamada a la acción.

Para cada sección, especifica:
- Texto exacto para la voz en off o diálogo
- Descripción de las imágenes o B-roll que se mostrarán
- Efectos visuales, textos en pantalla o gráficos necesarios
- Música o efectos de sonido recomendados

El guión debe ser detallado, específico y optimizado para maximizar la retención de la audiencia y el engagement.`}
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  )
}
