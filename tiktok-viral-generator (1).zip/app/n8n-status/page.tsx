import { N8nStatusChecker } from "@/components/n8n-status-checker"

export default function N8nStatusPage() {
  return (
    <div className="container py-10">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold mb-2">n8n Integration Status</h1>
        <p className="text-muted-foreground mb-8">Check if the n8n integration is properly configured and working.</p>

        <N8nStatusChecker />

        <div className="mt-8 p-4 bg-blue-50 rounded-lg">
          <h2 className="text-lg font-medium mb-2">Troubleshooting Tips</h2>
          <ul className="list-disc pl-5 space-y-2">
            <li>
              Make sure the <code>NEXT_PUBLIC_N8N_WORKFLOW_URL</code> environment variable is set correctly
            </li>
            <li>
              Make sure the <code>NEXT_PUBLIC_N8N_API_KEY</code> environment variable is set correctly
            </li>
            <li>Check that your n8n workflow is active and accessible</li>
            <li>Verify that the webhook in n8n is configured to accept the data format we're sending</li>
            <li>If you're in a preview environment, make sure the n8n URL is publicly accessible</li>
          </ul>
        </div>
      </div>
    </div>
  )
}
