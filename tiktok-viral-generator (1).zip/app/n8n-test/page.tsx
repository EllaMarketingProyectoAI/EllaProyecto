"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Loader2, AlertCircle, CheckCircle2 } from "lucide-react"

export default function N8nTestPage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)

  const testN8nIntegration = async () => {
    setLoading(true)
    setError(null)
    setResult(null)

    try {
      const response = await fetch("/api/n8n/test")
      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Error testing n8n integration")
      }

      setResult(data)
    } catch (err: any) {
      console.error("Error testing n8n integration:", err)
      setError(err.message || "An unexpected error occurred")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-6">n8n Integration Test</h1>
      <p className="text-muted-foreground mb-8">
        Use this page to test the connection to your n8n workflow and diagnose any issues.
      </p>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Test n8n Connection</CardTitle>
            <CardDescription>
              This will send a test request to your n8n workflow and display the results.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium mb-1">n8n Workflow URL</p>
                  <p className="text-sm text-muted-foreground break-all">
                    {process.env.NEXT_PUBLIC_N8N_WORKFLOW_URL || "Not configured"}
                  </p>
                </div>
                <div>
                  <p className="text-sm font-medium mb-1">API Key</p>
                  <p className="text-sm text-muted-foreground">
                    {process.env.NEXT_PUBLIC_N8N_API_KEY ? "Configured" : "Not configured"}
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button onClick={testN8nIntegration} disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Testing...
                </>
              ) : (
                "Test Connection"
              )}
            </Button>
          </CardFooter>
        </Card>

        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {result && (
          <Card>
            <CardHeader>
              <CardTitle>Test Results</CardTitle>
              <CardDescription>
                {result.success ? (
                  <span className="flex items-center text-green-600">
                    <CheckCircle2 className="mr-2 h-4 w-4" />
                    Test completed successfully
                  </span>
                ) : (
                  <span className="flex items-center text-red-600">
                    <AlertCircle className="mr-2 h-4 w-4" />
                    Test failed
                  </span>
                )}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium mb-1">n8n Configuration</h3>
                  <p className="text-sm text-muted-foreground">
                    URL: {result.n8nUrl}
                    <br />
                    API Key: {result.apiKeyConfigured ? "Configured" : "Not configured"}
                  </p>
                </div>

                <div>
                  <h3 className="text-sm font-medium mb-1">Test Request</h3>
                  <pre className="text-xs bg-slate-100 p-4 rounded-md overflow-auto max-h-40">
                    {JSON.stringify(result.request, null, 2)}
                  </pre>
                </div>

                <div>
                  <h3 className="text-sm font-medium mb-1">Test Response</h3>
                  <pre className="text-xs bg-slate-100 p-4 rounded-md overflow-auto max-h-60">
                    {JSON.stringify(result.result, null, 2)}
                  </pre>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
