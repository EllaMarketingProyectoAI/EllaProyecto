import { N8nWebhookTester } from "@/components/n8n-webhook-tester"
import { N8nStatusChecker } from "@/components/n8n-status-checker"

export default function N8nWebhookTestPage() {
  return (
    <div className="container py-10">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold mb-2">Prueba del Webhook de n8n</h1>
        <p className="text-muted-foreground mb-8">
          Verifica que la nueva URL del webhook esté configurada y funcionando correctamente.
        </p>

        <div className="grid gap-8 md:grid-cols-2">
          <div>
            <N8nStatusChecker />
          </div>
          <div>
            <N8nWebhookTester />
          </div>
        </div>

        <div className="mt-8 p-4 bg-blue-50 rounded-lg">
          <h2 className="text-lg font-medium mb-2">Instrucciones</h2>
          <ol className="list-decimal pl-5 space-y-2">
            <li>
              Verifica que la URL del webhook mostrada sea:{" "}
              <code className="bg-gray-100 px-1 py-0.5 rounded">
                https://proyectoaiella.app.n8n.cloud/webhook/Generar-prompt
              </code>
            </li>
            <li>Si la URL es correcta, haz clic en "Probar Webhook" para verificar la conexión</li>
            <li>Si la prueba es exitosa, verás un mensaje de confirmación y el prompt generado</li>
            <li>
              Si hay un error, asegúrate de que la URL sea accesible y que el flujo de trabajo en n8n esté correctamente
              configurado
            </li>
          </ol>
        </div>
      </div>
    </div>
  )
}
