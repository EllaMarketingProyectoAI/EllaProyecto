"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { VideoProcessingSteps } from "@/components/video-processing-steps"
import Link from "next/link"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Library, Video } from "lucide-react"
import { useUserStore } from "@/lib/store/user-store"
import { UserNav } from "@/components/user-nav"

// Función para manejar errores de carga de imágenes
const handleImageError = (e: React.SyntheticEvent<HTMLImageElement, Event>) => {
  e.currentTarget.src = "/placeholder.svg?height=50&width=50"
}

export default function Home() {
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const { isAuthenticated } = useUserStore()

  return (
    <main className="flex min-h-screen flex-col">
      <header className="border-b">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-blue-600 text-white p-2 rounded">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-video"
              >
                <path d="m22 8-6 4 6 4V8Z" />
                <rect width="14" height="12" x="2" y="6" rx="2" ry="2" />
              </svg>
            </div>
            <span className="text-xl font-bold">Ella.Marketing</span>
          </div>
          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <div className="flex gap-2">
                <Link href="/video-selection">
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Video className="mr-2 h-4 w-4" />
                    Crear nuevo video
                  </Button>
                </Link>
                <UserNav />
              </div>
            ) : (
              <Link href="/auth">
                <Button variant="outline">Iniciar sesión</Button>
              </Link>
            )}
          </div>
        </div>
      </header>

      <section className="py-12 bg-gradient-to-b from-blue-50 to-white dark:from-blue-950 dark:to-background">
        <div className="container text-center space-y-6">
          <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl">
            Crea <span className="text-blue-600">contenido viral</span> automatizado
          </h1>
          <p className="max-w-2xl mx-auto text-muted-foreground text-lg">Genera contenido viral de manera sencilla</p>

          {isAuthenticated ? (
            <div className="flex flex-col items-center justify-center mt-6 gap-4">
              <div className="flex gap-4">
                <Link href="/dashboard">
                  <Button variant="outline" className="flex items-center">
                    <Library className="mr-2 h-4 w-4" />
                    Mi biblioteca de videos
                  </Button>
                </Link>
                <Link href="/video-selection">
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Video className="mr-2 h-4 w-4" />
                    Crear nuevo video
                  </Button>
                </Link>
              </div>
            </div>
          ) : (
            <div className="flex justify-center mt-4">
              <Link href="/auth">
                <Button className="bg-blue-600 hover:bg-blue-700">Registrarse para comenzar</Button>
              </Link>
            </div>
          )}
        </div>
      </section>

      <section className="py-12 bg-slate-50 dark:bg-slate-900">
        <div className="container">
          <h2 className="text-3xl font-bold text-center mb-12">Metodología del Patrón de Disrupción</h2>
          <VideoProcessingSteps />
        </div>
      </section>

      <section className="py-12">
        <div className="container">
          <h2 className="text-3xl font-bold text-center mb-8">¿Cómo funciona?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="text-center">
              <div className="bg-blue-100 dark:bg-blue-900 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-blue-600 dark:text-blue-400"
                >
                  <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
                  <polyline points="14 2 14 8 20 8" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">1. Completa el formulario</h3>
              <p className="text-muted-foreground">
                Proporciona los detalles de tu video, como título, tema, formato y otros parámetros.
              </p>
            </div>
            <div className="text-center">
              <div className="bg-blue-100 dark:bg-blue-900 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-blue-600 dark:text-blue-400"
                >
                  <path d="M12 3v3" />
                  <path d="M18.5 8.5 16 11" />
                  <path d="M8.5 18.5 11 16" />
                  <path d="M3 12h3" />
                  <path d="M12 21v-3" />
                  <path d="M18.5 15.5 16 13" />
                  <path d="M8.5 5.5 11 8" />
                  <path d="M21 12h-3" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">2. Procesamiento automático</h3>
              <p className="text-muted-foreground">
                Nuestro sistema procesa tu solicitud y aplica la metodología del Patrón de Disrupción.
              </p>
            </div>
            <div className="text-center">
              <div className="bg-blue-100 dark:bg-blue-900 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-blue-600 dark:text-blue-400"
                >
                  <path d="m22 8-6 4 6 4V8Z" />
                  <rect width="14" height="12" x="2" y="6" rx="2" ry="2" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">3. Recibe tu video viral</h3>
              <p className="text-muted-foreground">
                Descarga tu video optimizado para maximizar su alcance y potencial viral.
              </p>
            </div>
          </div>
        </div>
      </section>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-3xl p-0">
          <div className="p-6">
            <h2 className="text-2xl font-bold mb-4">Información</h2>
            <p className="mb-4">
              Para utilizar todas las funcionalidades de la plataforma, es necesario registrarse o iniciar sesión.
            </p>
            <div className="flex justify-end">
              <Button onClick={() => setIsDialogOpen(false)}>Cerrar</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </main>
  )
}
