"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { useUserStore } from "@/lib/store/user-store"
import { useRouter } from "next/navigation"
import { useEffect } from "react"
import Link from "next/link"
import { Library, Settings, Video } from "lucide-react"

export default function ProfilePage() {
  const { user, isAuthenticated } = useUserStore()
  const router = useRouter()

  // Redirigir si no está autenticado
  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/auth")
    }
  }, [isAuthenticated, router])

  // Mock data para videos y estadísticas
  const mockStats = {
    totalVideos: 0,
    generatedVideos: 0,
    storageUsed: "0 GB",
    storageLimit: "5 GB",
  }

  // Obtener la primera letra del nombre de usuario o un valor predeterminado
  const userInitial = user?.username ? user.username.charAt(0).toUpperCase() : "U"

  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-8">Perfil de usuario</h1>

      <div className="grid gap-6 lg:grid-cols-12">
        <div className="lg:col-span-4 space-y-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col items-center space-y-4">
                <div className="relative">
                  <Avatar className="h-24 w-24">
                    <AvatarFallback className="text-2xl bg-blue-600 text-white">{userInitial}</AvatarFallback>
                  </Avatar>
                </div>

                <div className="space-y-1 text-center">
                  <h2 className="text-xl font-bold">{user?.username}</h2>
                  <p className="text-sm text-muted-foreground">{user?.email || "usuario@ejemplo.com"}</p>
                </div>
                <div className="flex gap-2 w-full">
                  <Link href="/settings" className="flex-1">
                    <Button variant="outline" className="w-full">
                      <Settings className="mr-2 h-4 w-4" />
                      Editar perfil
                    </Button>
                  </Link>
                  <Link href="/dashboard" className="flex-1">
                    <Button className="w-full bg-blue-600 hover:bg-blue-700">
                      <Library className="mr-2 h-4 w-4" />
                      Mi biblioteca
                    </Button>
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Estadísticas</CardTitle>
              <CardDescription>Resumen de tu actividad</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-sm">Videos totales</span>
                  <span className="font-medium">{mockStats.totalVideos}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Videos generados</span>
                  <span className="font-medium">{mockStats.generatedVideos}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Espacio utilizado</span>
                  <span className="font-medium">{mockStats.storageUsed}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Espacio disponible</span>
                  <span className="font-medium">{mockStats.storageLimit}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-8 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Actividad reciente</CardTitle>
              <CardDescription>Los últimos videos que has generado</CardDescription>
            </CardHeader>
            <CardContent>
              {mockStats.generatedVideos > 0 ? (
                <div className="space-y-4">
                  {Array.from({ length: 3 }).map((_, index) => (
                    <div key={index} className="flex items-center space-x-4">
                      <div className="w-16 h-10 rounded bg-gray-200 dark:bg-gray-800"></div>
                      <div className="flex-1 space-y-1">
                        <p className="font-medium">Video viral #{index + 1}</p>
                        <p className="text-sm text-muted-foreground">Generado hace {index + 1} días</p>
                      </div>
                      <div className="text-sm text-muted-foreground">{Math.floor(Math.random() * 1000)} vistas</div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-muted-foreground mb-4">Aún no has generado ningún video.</p>
                  <Link href="/video-selection">
                    <Button className="bg-blue-600 hover:bg-blue-700">
                      <Video className="mr-2 h-4 w-4" />
                      Generar mi primer video
                    </Button>
                  </Link>
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Link href="/dashboard">
                <Button variant="outline" className="flex items-center">
                  <Library className="mr-2 h-4 w-4" />
                  Ver todos los videos
                </Button>
              </Link>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Cuestionario de preferencias</CardTitle>
              <CardDescription>Tu configuración para la generación de videos</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium">Estado del cuestionario</h3>
                  <p className="text-sm text-muted-foreground">No has completado el cuestionario de preferencias.</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium">¿Por qué completar el cuestionario?</h3>
                  <p className="text-sm text-muted-foreground">
                    Completar el cuestionario nos ayuda a personalizar la generación de videos según tus preferencias.
                  </p>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Link href="/quiz">
                <Button className="bg-blue-600 hover:bg-blue-700">Completar cuestionario</Button>
              </Link>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}
