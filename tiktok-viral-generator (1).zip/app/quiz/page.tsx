"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { ArrowLeft, ArrowRight, Upload, X, FileText, Image, Video, Download, Play, Check } from "lucide-react"
import { useUserStore } from "@/lib/store/user-store"
import { useRouter } from "next/navigation"
import { Checkbox } from "@/components/ui/checkbox"
import { Progress } from "@/components/ui/progress"
import { createGeneralVideo } from "@/lib/services/video-service"
import {
  getTypographyOptions,
  getMusicOptions,
  getBRollOptions,
  getSoundEffectOptions,
} from "@/lib/services/options-service"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"

export default function QuizPage() {
  const { isAuthenticated, user } = useUserStore()
  const router = useRouter()
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showSuccessDialog, setShowSuccessDialog] = useState(false)
  const [generatedVideo, setGeneratedVideo] = useState<any>(null)
  const [step, setStep] = useState<"form" | "processing" | "complete">("form")
  const [progress, setProgress] = useState(0)
  const [processingSteps, setProcessingSteps] = useState([
    { name: "Analizando datos", status: "pending" },
    { name: "Generando guión", status: "pending" },
    { name: "Creando elementos visuales", status: "pending" },
    { name: "Generando audio", status: "pending" },
    { name: "Finalizando video", status: "pending" },
  ])

  // Estados para las opciones de la API
  const [typographyOptions, setTypographyOptions] = useState<any[]>([])
  const [musicOptions, setMusicOptions] = useState<any[]>([])
  const [bRollOptions, setBRollOptions] = useState<any[]>([])
  const [soundEffectOptions, setSoundEffectOptions] = useState<any[]>([])

  // Redirigir si no está autenticado
  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/auth")
    }
  }, [isAuthenticated, router])

  // Cargar opciones de la API
  useEffect(() => {
    async function loadOptions() {
      try {
        const typography = await getTypographyOptions()
        setTypographyOptions(typography)

        const music = await getMusicOptions()
        setMusicOptions(music)

        const bRoll = await getBRollOptions()
        setBRollOptions(bRoll)

        const soundEffects = await getSoundEffectOptions()
        setSoundEffectOptions(soundEffects)
      } catch (error) {
        console.error("Error loading options:", error)
      }
    }

    loadOptions()
  }, [])

  const [currentStep, setCurrentStep] = useState(0)
  const [formData, setFormData] = useState({
    title: "",
    topic: "",
    hook: "",
    format: "",
    sources: "",
    sourceFiles: [] as File[],
    restrictedWords: "",
    duration: "",
    bannedTopics: "",
    keywords: "",
    aiVoiceOver: "",
    subtitles: "",
    bRoll: "",
    // Opciones de la API
    typography: "",
    musicSource: "",
    bRollSource: [] as string[],
    soundEffectsSource: "",
  })

  const steps = [
    {
      title: "Información básica del video",
      description: "Proporciona la información principal para tu video",
      fields: [
        {
          name: "title",
          type: "text",
          label: "Título del video",
          placeholder: "Escribe el título de tu video...",
        },
        {
          name: "topic",
          type: "text",
          label: "Tema principal",
          placeholder: "¿De qué trata tu video?",
        },
      ],
    },
    {
      title: "Hook y formato",
      description: "Define cómo captar la atención y el formato del video",
      fields: [
        {
          name: "hook",
          type: "select",
          label: "Tipo de hook (gancho inicial)",
          options: [
            { value: "question", label: "Pregunta intrigante" },
            { value: "statistic", label: "Estadística sorprendente" },
            { value: "statement", label: "Afirmación impactante" },
            { value: "story", label: "Historia personal" },
            { value: "challenge", label: "Reto o desafío" },
            { value: "demonstration", label: "Demostración rápida" },
            { value: "Shock", label: "Shock" },
          ],
        },
        {
          name: "format",
          type: "select",
          label: "Formato del video",
          options: [
            { value: "tutorial", label: "Tutorial paso a paso" },
            { value: "vlog", label: "Vlog personal" },
            { value: "interview", label: "Entrevista" },
            { value: "reaction", label: "Reacción" },
            { value: "storytelling", label: "Narración de historia" },
            { value: "review", label: "Reseña de producto/servicio" },
            { value: "educational", label: "Educativo/informativo" },
            { value: "comedy", label: "Comedia/entretenimiento" },
          ],
        },
      ],
    },
    {
      title: "Fuentes y recursos",
      description: "Indica las fuentes y recursos para tu video",
      fields: [
        {
          name: "sources",
          type: "textarea",
          label: "Fuentes y recursos",
          placeholder: "Describe o lista las fuentes que utilizarás (videos, imágenes, artículos, etc.)",
        },
        {
          name: "sourceFiles",
          type: "file-upload",
          label: "Subir archivos",
          description: "Sube videos, imágenes o documentos PDF como recursos para tu video",
        },
      ],
    },
    {
      title: "Restricciones",
      description: "Define las restricciones para tu video",
      fields: [
        {
          name: "restrictedWords",
          type: "textarea",
          label: "Palabras a evitar",
          placeholder: "Lista palabras que NO deben aparecer en el video (separadas por comas)",
        },
        {
          name: "duration",
          type: "select",
          label: "Duración del video",
          options: [
            { value: "15s", label: "15 segundos (ideal para TikTok/Reels cortos)" },
            { value: "30s", label: "30 segundos" },
            { value: "60s", label: "1 minuto" },
            { value: "3min", label: "3 minutos" },
            { value: "5min", label: "5 minutos" },
            { value: "10min", label: "10 minutos o más" },
          ],
        },
        {
          name: "bannedTopics",
          type: "textarea",
          label: "Temas prohibidos",
          placeholder: "Lista temas que deben evitarse completamente (separados por comas)",
        },
      ],
    },
    {
      title: "Keywords y elementos adicionales",
      description: "Define palabras clave y elementos adicionales para tu video",
      fields: [
        {
          name: "keywords",
          type: "textarea",
          label: "Keywords / Hashtags",
          placeholder: "Lista palabras clave o hashtags para tu video (separados por comas)",
        },
        {
          name: "aiVoiceOver",
          type: "radio",
          label: "¿Deseas utilizar voz generada por IA?",
          options: [
            { value: "yes", label: "Sí" },
            { value: "no", label: "No" },
          ],
        },
        {
          name: "subtitles",
          type: "radio",
          label: "¿Incluir subtítulos?",
          options: [
            { value: "yes", label: "Sí" },
            { value: "no", label: "No" },
          ],
        },
        {
          name: "bRoll",
          type: "radio",
          label: "Tipo de B-roll (metraje secundario)",
          options: [
            { value: "stock", label: "Stock (metraje de archivo)" },
            { value: "ai", label: "Generado por IA" },
            { value: "both", label: "Ambos" },
            { value: "none", label: "Ninguno" },
          ],
        },
      ],
    },
    // Paso para herramientas con opciones de la API
    {
      title: "Herramientas para realizar contenidos",
      description: "Selecciona las herramientas que utilizarás para crear tu video",
      fields: [
        {
          name: "typography",
          type: "select-api",
          label: "Tipografía principal",
          options: typographyOptions,
          optionLabel: "name",
          optionValue: "value",
        },
        {
          name: "musicSource",
          type: "select-api",
          label: "Fuente de música",
          options: musicOptions,
          optionLabel: "name",
          optionValue: "value",
        },
        {
          name: "bRollSource",
          type: "checkbox-group-api",
          label: "Fuentes de B-Roll (videos y fotos)",
          options: bRollOptions,
          optionLabel: "name",
          optionValue: "value",
        },
        {
          name: "soundEffectsSource",
          type: "select-api",
          label: "Fuente de efectos de sonido",
          options: soundEffectOptions,
          optionLabel: "name",
          optionValue: "value",
        },
      ],
    },
  ]

  const currentStepData = steps[currentStep]

  const handleInputChange = (name: string, value: string) => {
    console.log(`Cambiando ${name} a:`, value)
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleNext = () => {
    // Validar que los campos del paso actual estén completos
    const currentFields = currentStepData.fields
    const isValid = currentFields.every((field) => {
      if (
        field.name === "restrictedWords" ||
        field.name === "bannedTopics" ||
        field.name === "sources" ||
        field.name === "bRollSource" ||
        field.name === "sourceFiles"
      )
        return true // Estos campos son opcionales
      return formData[field.name as keyof typeof formData]
    })

    if (!isValid) {
      toast({
        variant: "destructive",
        title: "Campos incompletos",
        description: "Por favor completa todos los campos requeridos antes de continuar.",
      })
      return
    }

    if (currentStep < steps.length - 1) {
      setCurrentStep((prev) => prev + 1)
    } else {
      // Si estamos en el último paso, procesamos el video
      processVideo()
    }
  }

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep((prev) => prev - 1)
    }
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files)
      setFormData((prev) => ({
        ...prev,
        sourceFiles: [...prev.sourceFiles, ...newFiles],
      }))
    }
  }

  // Añadir una función para eliminar archivos
  const removeFile = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      sourceFiles: prev.sourceFiles.filter((_, i) => i !== index),
    }))
  }

  // Función para procesar el video usando el servicio
  const processVideo = async () => {
    if (!user?.id) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Debes iniciar sesión para crear un video.",
      })
      return
    }

    // Cambiar a la pantalla de procesamiento
    setStep("processing")
    setIsSubmitting(true)
    setProgress(0)

    // Reiniciar el estado de los pasos de procesamiento
    setProcessingSteps((prev) => prev.map((step) => ({ ...step, status: "pending" })))

    // Simulamos el progreso con un intervalo
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 90) {
          clearInterval(interval)
          return 90
        }

        // Actualizar el estado de los pasos según el progreso
        if (prev >= 20 && processingSteps[0].status === "pending") {
          setProcessingSteps((prev) => {
            const updated = [...prev]
            updated[0].status = "completed"
            return updated
          })
        }
        if (prev >= 40 && processingSteps[1].status === "pending") {
          setProcessingSteps((prev) => {
            const updated = [...prev]
            updated[1].status = "completed"
            return updated
          })
        }
        if (prev >= 60 && processingSteps[2].status === "pending") {
          setProcessingSteps((prev) => {
            const updated = [...prev]
            updated[2].status = "completed"
            return updated
          })
        }
        if (prev >= 80 && processingSteps[3].status === "pending") {
          setProcessingSteps((prev) => {
            const updated = [...prev]
            updated[3].status = "completed"
            return updated
          })
        }

        return prev + 2
      })
    }, 200)

    try {
      // Establecer valores predeterminados para campos opcionales que podrían estar vacíos
      const aiVoiceOver = formData.aiVoiceOver || "no"
      const subtitles = formData.subtitles || "no"
      const bRoll = formData.bRoll || "none"
      const duration = formData.duration || "60s"

      // Asegurarse de que los arrays estén definidos
      const bRollSource = formData.bRollSource.length > 0 ? formData.bRollSource : []

      console.log("Procesando video con opciones:", {
        userId: user.id,
        title: formData.title,
        options: {
          title: formData.title,
          topic: formData.topic,
          hook: formData.hook,
          format: formData.format,
          sources: formData.sources,
          restricted_words: formData.restrictedWords,
          duration: duration,
          banned_topics: formData.bannedTopics,
          keywords: formData.keywords,
          ai_voice_over: aiVoiceOver,
          subtitles: subtitles,
          b_roll: bRoll,
          typography: formData.typography,
          music_source: formData.musicSource,
          b_roll_source: bRollSource,
          sound_effects_source: formData.soundEffectsSource,
        },
      })

      // Usar el servicio para crear el video
      const result = await createGeneralVideo(user.id, formData.title, {
        title: formData.title,
        topic: formData.topic,
        hook: formData.hook,
        format: formData.format,
        sources: formData.sources,
        restricted_words: formData.restrictedWords,
        duration: duration,
        banned_topics: formData.bannedTopics,
        keywords: formData.keywords,
        ai_voice_over: aiVoiceOver,
        subtitles: subtitles,
        b_roll: bRoll,
        typography: formData.typography,
        music_source: formData.musicSource,
        b_roll_source: bRollSource,
        sound_effects_source: formData.soundEffectsSource,
      })

      if (!result.success) {
        throw new Error(result.error || "Error al crear el video")
      }

      console.log("Video creado exitosamente:", result)

      // Completamos el progreso
      clearInterval(interval)
      setProgress(100)

      // Marcamos el último paso como completado
      setProcessingSteps((prev) => {
        const updated = [...prev]
        updated[4].status = "completed"
        return updated
      })

      // Guardamos el video generado para mostrarlo en el diálogo
      setGeneratedVideo(result.generatedVideo)

      // Esperamos un momento para mostrar el 100%
      setTimeout(() => {
        setShowSuccessDialog(true)
        setStep("complete")
      }, 1000)

      toast({
        title: "¡Video creado con éxito!",
        description: "Tu video ha sido añadido a tu biblioteca.",
      })
    } catch (error: any) {
      console.error("Error al crear el video:", error)
      clearInterval(interval)

      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Ocurrió un error al crear el video. Por favor, intenta de nuevo.",
      })

      setStep("form")
    } finally {
      setIsSubmitting(false)
    }
  }

  // Función para simular la descarga del video
  const handleDownload = () => {
    if (!generatedVideo) return

    console.log("Iniciando descarga del video:", generatedVideo)

    // Crear un elemento <a> temporal
    const link = document.createElement("a")
    link.href = generatedVideo.fileUrl || `/api/videos/${generatedVideo.id}/download`
    link.target = "_blank"
    link.download = generatedVideo.fileName || `${formData.title.replace(/\s+/g, "_")}.mp4`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    toast({
      title: "Descarga iniciada",
      description: "Tu video se está descargando.",
    })
  }

  const handleFinish = () => {
    toast({
      title: "¡Video procesado con éxito!",
      description: "Tu video ha sido añadido a tu biblioteca.",
    })
    router.push("/dashboard")
  }

  // Renderizado de campos de formulario
  const renderField = (field: any) => {
    switch (field.type) {
      case "checkbox-group-api":
        return (
          <div className="space-y-4" key={field.name}>
            <Label>{field.label}</Label>
            <div className="grid grid-cols-2 gap-2">
              {field.options.map((option: any) => (
                <div key={option[field.optionValue]} className="flex items-center space-x-2">
                  <Checkbox
                    id={`${field.name}-${option[field.optionValue]}`}
                    checked={(formData[field.name as keyof typeof formData] as string[])?.includes(
                      option[field.optionValue],
                    )}
                    onCheckedChange={(checked) => {
                      if (checked) {
                        setFormData((prev) => ({
                          ...prev,
                          [field.name]: [
                            ...((prev[field.name as keyof typeof formData] as string[]) || []),
                            option[field.optionValue],
                          ],
                        }))
                      } else {
                        setFormData((prev) => ({
                          ...prev,
                          [field.name]: ((prev[field.name as keyof typeof formData] as string[]) || []).filter(
                            (value) => value !== option[field.optionValue],
                          ),
                        }))
                      }
                    }}
                  />
                  <Label htmlFor={`${field.name}-${option[field.optionValue]}`}>{option[field.optionLabel]}</Label>
                </div>
              ))}
            </div>
          </div>
        )
      case "select-api":
        return (
          <div className="space-y-4" key={field.name}>
            <Label>{field.label}</Label>
            <Select
              value={formData[field.name as keyof typeof formData]}
              onValueChange={(value) => handleInputChange(field.name, value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Seleccionar" />
              </SelectTrigger>
              <SelectContent>
                {field.options.map((option: any) => (
                  <SelectItem key={option[field.optionValue]} value={option[field.optionValue]}>
                    {option[field.optionLabel]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )
      case "radio":
        return (
          <div className="space-y-4" key={field.name}>
            <Label>{field.label}</Label>
            <RadioGroup
              value={formData[field.name as keyof typeof formData]}
              onValueChange={(value) => handleInputChange(field.name, value)}
            >
              {field.options.map((option: any) => (
                <div className="flex items-center space-x-2" key={option.value}>
                  <RadioGroupItem value={option.value} id={`${field.name}-${option.value}`} />
                  <Label htmlFor={`${field.name}-${option.value}`}>{option.label}</Label>
                </div>
              ))}
            </RadioGroup>
          </div>
        )
      case "select":
        return (
          <div className="space-y-4" key={field.name}>
            <Label>{field.label}</Label>
            <Select
              value={formData[field.name as keyof typeof formData]}
              onValueChange={(value) => handleInputChange(field.name, value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Seleccionar" />
              </SelectTrigger>
              <SelectContent>
                {field.options.map((option: any) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )
      case "textarea":
        return (
          <div className="space-y-4" key={field.name}>
            <Label>{field.label}</Label>
            <Textarea
              value={formData[field.name as keyof typeof formData] || ""}
              onChange={(e) => handleInputChange(field.name, e.target.value)}
              placeholder={field.placeholder}
              rows={3}
            />
          </div>
        )
      case "file-upload":
        return (
          <div className="space-y-4" key={field.name}>
            <Label>{field.label}</Label>
            <p className="text-sm text-muted-foreground">{field.description}</p>

            <div className="grid gap-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 hover:border-blue-500 transition-colors">
                <label className="flex flex-col items-center justify-center cursor-pointer">
                  <Upload className="h-8 w-8 text-blue-500 mb-2" />
                  <span className="text-sm font-medium">Haz clic para seleccionar archivos</span>
                  <span className="text-xs text-muted-foreground mt-1">Videos, imágenes o PDFs (máx. 50MB)</span>
                  <Input
                    type="file"
                    className="hidden"
                    onChange={handleFileUpload}
                    multiple
                    accept="video/*,image/*,.pdf"
                  />
                </label>
              </div>

              {formData.sourceFiles.length > 0 && (
                <div className="space-y-2">
                  <Label>Archivos seleccionados</Label>
                  <div className="border rounded-lg divide-y">
                    {formData.sourceFiles.map((file, index) => (
                      <div key={index} className="flex items-center justify-between p-3">
                        <div className="flex items-center space-x-3">
                          {file.type.startsWith("image/") ? (
                            <Image className="h-5 w-5 text-blue-500" />
                          ) : file.type.startsWith("video/") ? (
                            <Video className="h-5 w-5 text-blue-500" />
                          ) : (
                            <FileText className="h-5 w-5 text-blue-500" />
                          )}
                          <div className="text-sm">
                            <p className="font-medium truncate max-w-[200px]">{file.name}</p>
                            <p className="text-xs text-muted-foreground">{(file.size / (1024 * 1024)).toFixed(2)} MB</p>
                          </div>
                        </div>
                        <Button type="button" variant="ghost" size="sm" onClick={() => removeFile(index)}>
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )
      default:
        return (
          <div className="space-y-4" key={field.name}>
            <Label>{field.label}</Label>
            <Input
              type="text"
              value={formData[field.name as keyof typeof formData] || ""}
              onChange={(e) => handleInputChange(field.name, e.target.value)}
              placeholder={field.placeholder}
            />
          </div>
        )
    }
  }

  return (
    <div className="container py-10">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold mb-2">Video General</h1>
        <p className="text-muted-foreground mb-8">
          Completa este formulario para configurar los parámetros de tu video viral.
        </p>

        {step === "form" && (
          <>
            <div className="mb-8">
              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium">
                  Paso {currentStep + 1} de {steps.length}
                </span>
                <span className="text-sm font-medium">{Math.round(((currentStep + 1) / steps.length) * 100)}%</span>
              </div>
              <div className="w-full h-2 bg-gray-200 rounded-full">
                <div
                  className="h-2 bg-blue-600 rounded-full"
                  style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
                />
              </div>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>{currentStepData.title}</CardTitle>
                <CardDescription>{currentStepData.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">{currentStepData.fields.map(renderField)}</CardContent>
              <CardFooter className="flex justify-between">
                <Button type="button" variant="outline" onClick={handlePrevious} disabled={currentStep === 0}>
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Anterior
                </Button>

                {currentStep < steps.length - 1 ? (
                  <Button type="button" onClick={handleNext}>
                    Siguiente
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                ) : (
                  <Button type="button" onClick={processVideo} disabled={isSubmitting}>
                    {isSubmitting ? (
                      <>
                        <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-solid border-current border-r-transparent"></div>
                        Procesando...
                      </>
                    ) : (
                      <>
                        Procesar video
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </>
                    )}
                  </Button>
                )}
              </CardFooter>
            </Card>
          </>
        )}

        {step === "processing" && (
          <Card>
            <CardHeader>
              <CardTitle>Procesando video</CardTitle>
              <CardDescription>Estamos procesando tu video, por favor espera...</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="py-8 space-y-8">
                <div className="text-center space-y-4">
                  <div className="inline-block h-12 w-12 animate-spin rounded-full border-4 border-solid border-blue-600 border-r-transparent"></div>
                  <h3 className="text-xl font-medium">Procesando video</h3>
                  <p className="text-muted-foreground">Estamos aplicando las mejoras seleccionadas a tu video...</p>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Progreso total</span>
                    <span>{progress}%</span>
                  </div>
                  <Progress value={progress} className="h-2" />
                </div>

                <div className="space-y-3">
                  {processingSteps.map((step, index) => (
                    <div key={index} className="flex justify-between items-center">
                      <span className="text-sm">{step.name}</span>
                      {step.status === "completed" ? (
                        <Check className="h-4 w-4 text-green-500" />
                      ) : (
                        <div className="h-4 w-4 animate-pulse bg-blue-600 rounded-full"></div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-center">
              <p className="text-sm text-muted-foreground">Por favor espera mientras procesamos tu video...</p>
            </CardFooter>
          </Card>
        )}

        {/* Diálogo de éxito */}
        <Dialog open={showSuccessDialog} onOpenChange={setShowSuccessDialog}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>¡Video generado con éxito!</DialogTitle>
              <DialogDescription>Tu video ha sido creado y guardado en tu biblioteca.</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="aspect-video bg-slate-200 dark:bg-slate-800 rounded-md overflow-hidden flex items-center justify-center">
                {generatedVideo?.thumbnailUrl ? (
                  <img
                    src={generatedVideo.thumbnailUrl || "/placeholder.svg"}
                    alt={generatedVideo.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <Play className="h-12 w-12 text-slate-500" />
                )}
              </div>
              <div className="space-y-2">
                <h3 className="font-medium">{formData.title}</h3>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Duración:</span>
                  <span>{generatedVideo?.duration || "00:00"}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Tamaño:</span>
                  <span>
                    {generatedVideo?.fileSize ? `${(generatedVideo.fileSize / (1024 * 1024)).toFixed(2)} MB` : "0 MB"}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Formato:</span>
                  <span>{generatedVideo?.format || "MP4"}</span>
                </div>
              </div>
            </div>
            <DialogFooter className="sm:justify-between">
              <Button variant="outline" onClick={() => router.push("/dashboard")}>
                Ver en biblioteca
              </Button>
              <Button onClick={handleDownload} className="bg-blue-600 hover:bg-blue-700">
                <Download className="mr-2 h-4 w-4" />
                Descargar video
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}
