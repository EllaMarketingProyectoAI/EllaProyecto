"use client"

import { SocialAuth } from "@/components/social-auth"
import { AuthForm } from "@/components/auth-form"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useUserStore } from "@/lib/store/user-store"
import { useRouter } from "next/navigation"
import { useEffect } from "react"

export default function SettingsPage() {
  const { isAuthenticated } = useUserStore()
  const router = useRouter()

  // Redirigir si no está autenticado
  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/auth")
    }
  }, [isAuthenticated, router])

  const handleAuthSuccess = (platform: string, token: string) => {
    // En una implementación real, guardaríamos el token en la base de datos
    console.log(`Autenticado con ${platform}, token: ${token}`)
  }

  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-8">Configuración</h1>

      <Tabs defaultValue="account" className="max-w-4xl">
        <TabsList className="mb-8">
          <TabsTrigger value="account">Cuenta</TabsTrigger>
          <TabsTrigger value="connections">Conexiones</TabsTrigger>
        </TabsList>

        <TabsContent value="account">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Información de cuenta</CardTitle>
                <CardDescription>Actualiza la información de tu cuenta y cambia tu contraseña.</CardDescription>
              </CardHeader>
              <CardContent>
                <AuthForm />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Preferencias</CardTitle>
                <CardDescription>Configura las preferencias de tu cuenta y notificaciones.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h3 className="font-medium mb-2">Temas</h3>
                    <p className="text-sm text-muted-foreground">Configura el tema de la interfaz.</p>
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Notificaciones</h3>
                    <p className="text-sm text-muted-foreground">Configura las notificaciones que deseas recibir.</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="connections">
          <div className="grid gap-6 md:grid-cols-2">
            <SocialAuth onSuccess={handleAuthSuccess} />

            <Card>
              <CardHeader>
                <CardTitle>API Keys</CardTitle>
                <CardDescription>Gestiona tus claves de API para integración con servicios externos.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h3 className="font-medium mb-2">API Key para TikTok</h3>
                    <p className="text-sm text-muted-foreground">
                      Conecta tu cuenta de desarrollador de TikTok para acceder a la API.
                    </p>
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">API Key para Instagram</h3>
                    <p className="text-sm text-muted-foreground">
                      Conecta tu cuenta de desarrollador de Meta para acceder a la API de Instagram.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
