"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { ArrowLeft, ArrowRight, Upload, X, Video, Play, Download, Check } from "lucide-react"
import { useUserStore } from "@/lib/store/user-store"
import { useRouter } from "next/navigation"
import { Progress } from "@/components/ui/progress"
import { createClientVideo } from "@/lib/services/video-service"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"

export default function VideoClientPage() {
  const { isAuthenticated, user } = useUserStore()
  const router = useRouter()
  const { toast } = useToast()
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showSuccessDialog, setShowSuccessDialog] = useState(false)
  const [generatedVideo, setGeneratedVideo] = useState<any>(null)
  const [processingSteps, setProcessingSteps] = useState([
    { name: "Analizando video", status: "pending" },
    { name: "Aplicando hook", status: "pending" },
    { name: "Integrando B-roll", status: "pending" },
    { name: "Generando subtítulos", status: "pending" },
    { name: "Finalizando video", status: "pending" },
  ])

  // Redirigir si no está autenticado
  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/auth")
    }
  }, [isAuthenticated, router])

  const [step, setStep] = useState<"upload" | "options" | "processing" | "complete">("upload")
  const [progress, setProgress] = useState(0)
  const [uploadedVideos, setUploadedVideos] = useState<File[]>([])
  const [videoTitle, setVideoTitle] = useState("")
  const [videoOptions, setVideoOptions] = useState({
    hook: "",
    bRoll: "",
    subtitles: "",
    language: "",
  })

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newFiles = Array.from(e.target.files).filter((file) => file.type.startsWith("video/"))
      setUploadedVideos((prev) => [...prev, ...newFiles])

      // Sugerir un título basado en el nombre del archivo, pero sin la extensión
      if (newFiles.length > 0 && !videoTitle) {
        const fileName = newFiles[0].name
        const titleSuggestion = fileName.substring(0, fileName.lastIndexOf(".")) || fileName
        setVideoTitle(titleSuggestion)
      }
    }
  }

  const removeVideo = (index: number) => {
    setUploadedVideos((prev) => prev.filter((_, i) => i !== index))
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const newFiles = Array.from(e.dataTransfer.files).filter((file) => file.type.startsWith("video/"))
      setUploadedVideos((prev) => [...prev, ...newFiles])

      // Sugerir un título basado en el nombre del archivo, pero sin la extensión
      if (newFiles.length > 0 && !videoTitle) {
        const fileName = newFiles[0].name
        const titleSuggestion = fileName.substring(0, fileName.lastIndexOf(".")) || fileName
        setVideoTitle(titleSuggestion)
      }
    }
  }

  const handleOptionChange = (name: keyof typeof videoOptions, value: string) => {
    console.log(`Cambiando ${name} a:`, value)
    setVideoOptions((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleNext = () => {
    if (step === "upload") {
      if (uploadedVideos.length === 0) {
        toast({
          variant: "destructive",
          title: "No hay videos",
          description: "Por favor, sube al menos un video para continuar.",
        })
        return
      }

      if (!videoTitle.trim()) {
        toast({
          variant: "destructive",
          title: "Título requerido",
          description: "Por favor, ingresa un título para tu video.",
        })
        return
      }

      setStep("options")
    } else if (step === "options") {
      // Validar que todas las opciones estén seleccionadas
      const allOptionsSelected = Object.values(videoOptions).every((value) => value !== "")
      if (!allOptionsSelected) {
        toast({
          variant: "destructive",
          title: "Opciones incompletas",
          description: "Por favor, selecciona todas las opciones para continuar.",
        })
        return
      }
      setStep("processing")
      processVideo()
    }
  }

  // Modificar la función processVideo para usar el servicio de video
  const processVideo = async () => {
    if (!user?.id) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Debes iniciar sesión para procesar un video.",
      })
      return
    }

    setIsSubmitting(true)
    setProgress(0)

    // Reiniciar el estado de los pasos de procesamiento
    setProcessingSteps((prev) => prev.map((step) => ({ ...step, status: "pending" })))

    // Simulamos el progreso con un intervalo
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 90) {
          clearInterval(interval)
          return 90
        }

        // Actualizar el estado de los pasos según el progreso
        if (prev >= 20 && processingSteps[0].status === "pending") {
          setProcessingSteps((prev) => {
            const updated = [...prev]
            updated[0].status = "completed"
            return updated
          })
        }
        if (prev >= 40 && processingSteps[1].status === "pending") {
          setProcessingSteps((prev) => {
            const updated = [...prev]
            updated[1].status = "completed"
            return updated
          })
        }
        if (prev >= 60 && processingSteps[2].status === "pending") {
          setProcessingSteps((prev) => {
            const updated = [...prev]
            updated[2].status = "completed"
            return updated
          })
        }
        if (prev >= 80 && processingSteps[3].status === "pending") {
          setProcessingSteps((prev) => {
            const updated = [...prev]
            updated[3].status = "completed"
            return updated
          })
        }

        return prev + 2
      })
    }, 200)

    try {
      console.log("Procesando video con opciones:", videoOptions)
      console.log("Usuario actual:", user.id)
      console.log("Título del video:", videoTitle)

      // Crear el video usando el servicio con el título personalizado
      const result = await createClientVideo(user.id, videoTitle, {
        hook: videoOptions.hook,
        b_roll: videoOptions.bRoll,
        subtitles: videoOptions.subtitles,
        language: videoOptions.language,
      })

      if (!result.success) {
        throw new Error(result.error || "Error al crear el video")
      }

      console.log("Video creado exitosamente:", result)

      // Completamos el progreso
      clearInterval(interval)
      setProgress(100)

      // Marcamos el último paso como completado
      setProcessingSteps((prev) => {
        const updated = [...prev]
        updated[4].status = "completed"
        return updated
      })

      // Guardamos el video generado para mostrarlo en el diálogo
      setGeneratedVideo(result.generatedVideo)

      // Esperamos un momento para mostrar el 100%
      setTimeout(() => {
        setShowSuccessDialog(true)
        setStep("complete")
      }, 1000)

      toast({
        title: "¡Video procesado con éxito!",
        description: "Tu video ha sido añadido a tu biblioteca.",
      })
    } catch (error: any) {
      console.error("Error al procesar el video:", error)
      clearInterval(interval)

      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Ocurrió un error al procesar el video. Por favor, intenta de nuevo.",
      })

      setStep("options")
    } finally {
      setIsSubmitting(false)
    }
  }

  // Modificar la función handleDownload para usar el generatedVideo
  const handleDownload = () => {
    if (!generatedVideo) return

    console.log("Iniciando descarga del video:", generatedVideo)

    // Crear un elemento <a> temporal
    const link = document.createElement("a")
    link.href = generatedVideo.fileUrl || `/api/videos/${generatedVideo.id}/download`
    link.target = "_blank"
    link.download = generatedVideo.fileName || `${videoTitle.replace(/\s+/g, "_")}.mp4`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    toast({
      title: "Descarga iniciada",
      description: "Tu video se está descargando.",
    })
  }

  const handleBack = () => {
    if (step === "options") {
      setStep("upload")
    }
  }

  const handleFinish = () => {
    toast({
      title: "¡Video procesado con éxito!",
      description: "Tu video ha sido añadido a tu biblioteca.",
    })
    router.push("/dashboard")
  }

  return (
    <div className="container py-10">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold mb-2 text-center">Video Cliente</h1>
        <p className="text-muted-foreground mb-8 text-center">
          Sube tus videos y personalízalos para maximizar su alcance
        </p>

        <Card>
          <CardHeader>
            <CardTitle>
              {step === "upload" && "Subir videos"}
              {step === "options" && "Personalizar video"}
              {step === "processing" && "Procesando video"}
              {step === "complete" && "¡Video listo!"}
            </CardTitle>
            <CardDescription>
              {step === "upload" && "Sube uno o más videos para comenzar"}
              {step === "options" && "Configura las opciones para tu video"}
              {step === "processing" && "Estamos procesando tu video, por favor espera..."}
              {step === "complete" && "Tu video ha sido procesado con éxito"}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {step === "upload" && (
              <div className="space-y-6">
                <div
                  className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-500 transition-colors"
                  onDragOver={handleDragOver}
                  onDrop={handleDrop}
                >
                  <div className="flex flex-col items-center justify-center space-y-4">
                    <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-full">
                      <Upload className="h-8 w-8 text-blue-600 dark:text-blue-400" />
                    </div>
                    <div className="space-y-2">
                      <h3 className="text-lg font-medium">Arrastra y suelta tus videos</h3>
                      <p className="text-sm text-muted-foreground">
                        O haz clic para seleccionar archivos (MP4, MOV, WEBM)
                      </p>
                    </div>
                    <Button variant="outline" onClick={() => fileInputRef.current?.click()}>
                      Seleccionar archivos
                    </Button>
                    <input
                      type="file"
                      ref={fileInputRef}
                      className="hidden"
                      accept="video/*"
                      multiple
                      onChange={handleFileUpload}
                    />
                  </div>
                </div>

                {uploadedVideos.length > 0 && (
                  <div className="space-y-4">
                    <h3 className="font-medium">Videos subidos ({uploadedVideos.length})</h3>
                    <div className="space-y-3">
                      {uploadedVideos.map((video, index) => (
                        <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                          <div className="flex items-center space-x-3">
                            <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded">
                              <Video className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                            </div>
                            <div>
                              <p className="font-medium truncate max-w-[200px] md:max-w-[400px]">{video.name}</p>
                              <p className="text-sm text-muted-foreground">
                                {(video.size / (1024 * 1024)).toFixed(2)} MB
                              </p>
                            </div>
                          </div>
                          <Button variant="ghost" size="sm" onClick={() => removeVideo(index)}>
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="space-y-4">
                  <Label htmlFor="video-title">Título del video</Label>
                  <Input
                    id="video-title"
                    placeholder="Ingresa un título para tu video"
                    value={videoTitle}
                    onChange={(e) => setVideoTitle(e.target.value)}
                    className="w-full"
                  />
                  <p className="text-sm text-muted-foreground">
                    Este título se mostrará en tu biblioteca de videos y en las descargas.
                  </p>
                </div>
              </div>
            )}

            {step === "options" && (
              <div className="space-y-6">
                <div className="space-y-4">
                  <Label>Tipo de hook (gancho inicial)</Label>
                  <Select value={videoOptions.hook} onValueChange={(value) => handleOptionChange("hook", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona un tipo de hook" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="question">Pregunta intrigante</SelectItem>
                      <SelectItem value="statistic">Estadística sorprendente</SelectItem>
                      <SelectItem value="statement">Afirmación impactante</SelectItem>
                      <SelectItem value="story">Historia personal</SelectItem>
                      <SelectItem value="challenge">Reto o desafío</SelectItem>
                      <SelectItem value="demonstration">Demostración rápida</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-4">
                  <Label>Tipo de B-roll (metraje secundario)</Label>
                  <RadioGroup value={videoOptions.bRoll} onValueChange={(value) => handleOptionChange("bRoll", value)}>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="stock" id="broll-stock" />
                      <Label htmlFor="broll-stock">Stock (metraje de archivo)</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="ai" id="broll-ai" />
                      <Label htmlFor="broll-ai">Generado por IA</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="both" id="broll-both" />
                      <Label htmlFor="broll-both">Ambos</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="none" id="broll-none" />
                      <Label htmlFor="broll-none">Ninguno</Label>
                    </div>
                  </RadioGroup>
                </div>

                <div className="space-y-4">
                  <Label>¿Incluir subtítulos?</Label>
                  <RadioGroup
                    value={videoOptions.subtitles}
                    onValueChange={(value) => handleOptionChange("subtitles", value)}
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="yes" id="subtitles-yes" />
                      <Label htmlFor="subtitles-yes">Sí</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="no" id="subtitles-no" />
                      <Label htmlFor="subtitles-no">No</Label>
                    </div>
                  </RadioGroup>
                </div>

                <div className="space-y-4">
                  <Label>Idioma</Label>
                  <Select
                    value={videoOptions.language}
                    onValueChange={(value) => handleOptionChange("language", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona un idioma" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="es">Español</SelectItem>
                      <SelectItem value="en">Inglés</SelectItem>
                      <SelectItem value="fr">Francés</SelectItem>
                      <SelectItem value="de">Alemán</SelectItem>
                      <SelectItem value="it">Italiano</SelectItem>
                      <SelectItem value="pt">Portugués</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            {step === "processing" && (
              <div className="py-8 space-y-8">
                <div className="text-center space-y-4">
                  <div className="inline-block h-12 w-12 animate-spin rounded-full border-4 border-solid border-blue-600 border-r-transparent"></div>
                  <h3 className="text-xl font-medium">Procesando video</h3>
                  <p className="text-muted-foreground">Estamos aplicando las mejoras seleccionadas a tu video...</p>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Progreso total</span>
                    <span>{progress}%</span>
                  </div>
                  <Progress value={progress} className="h-2" />
                </div>

                <div className="space-y-3">
                  {processingSteps.map((step, index) => (
                    <div key={index} className="flex justify-between items-center">
                      <span className="text-sm">{step.name}</span>
                      {step.status === "completed" ? (
                        <Check className="h-4 w-4 text-green-500" />
                      ) : (
                        <div className="h-4 w-4 animate-pulse bg-blue-600 rounded-full"></div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {step === "complete" && (
              <div className="py-8 space-y-6">
                <div className="text-center space-y-4">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 text-green-600">
                    <Check className="h-8 w-8" />
                  </div>
                  <h3 className="text-xl font-medium">¡Video procesado con éxito!</h3>
                  <p className="text-muted-foreground max-w-md mx-auto">
                    Tu video ha sido procesado y está listo para ser utilizado. Puedes encontrarlo en tu biblioteca de
                    videos.
                  </p>
                </div>

                <div className="aspect-video rounded-lg overflow-hidden max-w-md mx-auto bg-slate-200 dark:bg-slate-800 flex items-center justify-center">
                  {generatedVideo?.thumbnailUrl ? (
                    <img
                      src={generatedVideo.thumbnailUrl || "/placeholder.svg"}
                      alt="Video generado"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <Play className="h-12 w-12 text-slate-500" />
                  )}
                </div>

                <div className="space-y-4 max-w-md mx-auto">
                  <h4 className="font-medium">Detalles del video</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Título:</span>
                      <span className="text-sm font-medium">{videoTitle}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Tipo de hook:</span>
                      <span className="text-sm font-medium">
                        {videoOptions.hook === "question" && "Pregunta intrigante"}
                        {videoOptions.hook === "statistic" && "Estadística sorprendente"}
                        {videoOptions.hook === "statement" && "Afirmación impactante"}
                        {videoOptions.hook === "story" && "Historia personal"}
                        {videoOptions.hook === "challenge" && "Reto o desafío"}
                        {videoOptions.hook === "demonstration" && "Demostración rápida"}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">B-roll:</span>
                      <span className="text-sm font-medium">
                        {videoOptions.bRoll === "stock" && "Stock"}
                        {videoOptions.bRoll === "ai" && "Generado por IA"}
                        {videoOptions.bRoll === "both" && "Stock y generado por IA"}
                        {videoOptions.bRoll === "none" && "Ninguno"}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Subtítulos:</span>
                      <span className="text-sm font-medium">{videoOptions.subtitles === "yes" ? "Sí" : "No"}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Idioma:</span>
                      <span className="text-sm font-medium">
                        {videoOptions.language === "es" && "Español"}
                        {videoOptions.language === "en" && "Inglés"}
                        {videoOptions.language === "fr" && "Francés"}
                        {videoOptions.language === "de" && "Alemán"}
                        {videoOptions.language === "it" && "Italiano"}
                        {videoOptions.language === "pt" && "Portugués"}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
          <CardFooter className="flex justify-between">
            {step === "upload" && (
              <>
                <Button variant="outline" onClick={() => router.push("/video-selection")}>
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Volver
                </Button>
                <Button onClick={handleNext} disabled={uploadedVideos.length === 0 || !videoTitle.trim()}>
                  Siguiente
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </>
            )}

            {step === "options" && (
              <>
                <Button variant="outline" onClick={handleBack}>
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Volver
                </Button>
                <Button onClick={handleNext} disabled={isSubmitting}>
                  {isSubmitting ? (
                    <>
                      <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-solid border-current border-r-transparent"></div>
                      Procesando...
                    </>
                  ) : (
                    <>
                      Procesar video
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </>
                  )}
                </Button>
              </>
            )}

            {step === "processing" && (
              <div className="w-full flex justify-center">
                <p className="text-sm text-muted-foreground">Por favor espera mientras procesamos tu video...</p>
              </div>
            )}

            {step === "complete" && (
              <div className="w-full flex justify-center gap-4">
                <Button variant="outline" onClick={() => router.push("/dashboard")}>
                  Ver en biblioteca
                </Button>
                <Button onClick={handleDownload} className="bg-blue-600 hover:bg-blue-700">
                  <Download className="mr-2 h-4 w-4" />
                  Descargar video
                </Button>
              </div>
            )}
          </CardFooter>
        </Card>

        {/* Diálogo de éxito */}
        <Dialog open={showSuccessDialog} onOpenChange={setShowSuccessDialog}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>¡Video generado con éxito!</DialogTitle>
              <DialogDescription>Tu video ha sido creado y guardado en tu biblioteca.</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="aspect-video bg-slate-200 dark:bg-slate-800 rounded-md overflow-hidden flex items-center justify-center">
                {generatedVideo?.thumbnailUrl ? (
                  <img
                    src={generatedVideo.thumbnailUrl || "/placeholder.svg"}
                    alt="Video generado"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <Play className="h-12 w-12 text-slate-500" />
                )}
              </div>
              <div className="space-y-2">
                <h3 className="font-medium">{videoTitle}</h3>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Duración:</span>
                  <span>{generatedVideo?.duration || "00:45"}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Tamaño:</span>
                  <span>
                    {generatedVideo?.fileSize
                      ? `${(generatedVideo.fileSize / (1024 * 1024)).toFixed(2)} MB`
                      : "45.2 MB"}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Formato:</span>
                  <span>{generatedVideo?.format || "MP4"}</span>
                </div>
              </div>
            </div>
            <DialogFooter className="sm:justify-between">
              <Button variant="outline" onClick={() => router.push("/dashboard")}>
                Ver en biblioteca
              </Button>
              <Button onClick={handleDownload} className="bg-blue-600 hover:bg-blue-700">
                <Download className="mr-2 h-4 w-4" />
                Descargar video
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}
