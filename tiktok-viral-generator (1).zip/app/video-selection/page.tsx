"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useRouter } from "next/navigation"
import { ArrowRight, Upload, ListChecks, Wand2 } from "lucide-react"
import { useUserStore } from "@/lib/store/user-store"
import { useEffect } from "react"

export default function VideoSelectionPage() {
  const { isAuthenticated } = useUserStore()
  const router = useRouter()
  const [selectedOption, setSelectedOption] = useState<"client" | "general" | "ai" | null>(null)

  // Redirigir si no está autenticado
  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/auth")
    }
  }, [isAuthenticated, router])

  const handleContinue = () => {
    if (selectedOption === "client") {
      router.push("/video-client")
    } else if (selectedOption === "general") {
      router.push("/quiz")
    } else if (selectedOption === "ai") {
      router.push("/ai-video")
    }
  }

  return (
    <div className="container py-10">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-2 text-center">Selecciona el tipo de video</h1>
        <p className="text-muted-foreground mb-8 text-center">
          Elige el tipo de video que deseas crear según tus necesidades
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card
            className={`cursor-pointer transition-all ${
              selectedOption === "client" ? "border-2 border-blue-500 shadow-lg" : "hover:border-blue-200"
            }`}
            onClick={() => setSelectedOption("client")}
          >
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center">
                <Upload className="mr-2 h-5 w-5 text-blue-500" />
                Video Cliente
              </CardTitle>
              <CardDescription>Sube tus propios videos y personalízalos</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                <li className="flex items-center">
                  <div className="w-2 h-2 rounded-full bg-blue-500 mr-2"></div>
                  Sube uno o varios videos
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 rounded-full bg-blue-500 mr-2"></div>
                  Selecciona el tipo de hook
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 rounded-full bg-blue-500 mr-2"></div>
                  Elige B-roll (stock, IA o ambos)
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 rounded-full bg-blue-500 mr-2"></div>
                  Configura subtítulos
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card
            className={`cursor-pointer transition-all ${
              selectedOption === "general" ? "border-2 border-blue-500 shadow-lg" : "hover:border-blue-200"
            }`}
            onClick={() => setSelectedOption("general")}
          >
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center">
                <ListChecks className="mr-2 h-5 w-5 text-blue-500" />
                Video General
              </CardTitle>
              <CardDescription>Crea videos con parámetros detallados</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                <li className="flex items-center">
                  <div className="w-2 h-2 rounded-full bg-blue-500 mr-2"></div>
                  Define título y tema
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 rounded-full bg-blue-500 mr-2"></div>
                  Selecciona formato y hook
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 rounded-full bg-blue-500 mr-2"></div>
                  Establece restricciones y palabras clave
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 rounded-full bg-blue-500 mr-2"></div>
                  Configura voz en off y subtítulos
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card
            className={`cursor-pointer transition-all ${
              selectedOption === "ai" ? "border-2 border-blue-500 shadow-lg" : "hover:border-blue-200"
            }`}
            onClick={() => setSelectedOption("ai")}
          >
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center">
                <Wand2 className="mr-2 h-5 w-5 text-blue-500" />
                Video con IA
              </CardTitle>
              <CardDescription>Genera videos con inteligencia artificial</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                <li className="flex items-center">
                  <div className="w-2 h-2 rounded-full bg-blue-500 mr-2"></div>
                  Describe el video que deseas
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 rounded-full bg-blue-500 mr-2"></div>
                  La IA genera el contenido completo
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 rounded-full bg-blue-500 mr-2"></div>
                  Sin necesidad de grabar o editar
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 rounded-full bg-blue-500 mr-2"></div>
                  Resultados de alta calidad
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>

        <div className="bg-slate-50 dark:bg-slate-900 p-6 rounded-lg mb-8">
          <h3 className="text-lg font-medium mb-4">¿Cuál es la diferencia?</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h4 className="font-medium text-blue-600 mb-2">Video Cliente</h4>
              <p className="text-sm text-muted-foreground">
                Ideal cuando ya tienes tus propios videos y quieres mejorarlos con elementos virales como hooks
                atractivos, B-roll complementario y subtítulos.
              </p>
            </div>
            <div>
              <h4 className="font-medium text-blue-600 mb-2">Video General</h4>
              <p className="text-sm text-muted-foreground">
                Perfecto cuando quieres crear videos desde cero con parámetros detallados. Define todos los aspectos del
                video, desde el título y tema hasta restricciones específicas.
              </p>
            </div>
            <div>
              <h4 className="font-medium text-blue-600 mb-2">Video con IA</h4>
              <p className="text-sm text-muted-foreground">
                Genera videos completos utilizando inteligencia artificial. Solo describe lo que deseas y la IA creará
                el contenido visual sin necesidad de grabar o editar.
              </p>
            </div>
          </div>
        </div>

        <div className="flex justify-center">
          <Button
            onClick={handleContinue}
            disabled={!selectedOption}
            className="bg-blue-600 hover:bg-blue-700"
            size="lg"
          >
            Continuar
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}
