"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { ArrowLeft, Download, FileText, ImageIcon, Video, Play } from "lucide-react"
import { getVideoWithOptions } from "@/lib/services/video-service"
import { VideoPrompts } from "@/components/video-prompts"

export default function VideoDetailsPage() {
  const params = useParams()
  const router = useRouter()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(true)
  const [video, setVideo] = useState<any>(null)
  const [options, setOptions] = useState<any>(null)
  const [files, setFiles] = useState<any[]>([])
  const [prompts, setPrompts] = useState<any[]>([])

  useEffect(() => {
    async function loadVideoDetails() {
      try {
        setIsLoading(true)
        const videoId = params.id as string
        const result = await getVideoWithOptions(videoId)

        if (!result.success) {
          toast({
            variant: "destructive",
            title: "Error",
            description: result.error || "No se pudo cargar el video",
          })
          router.push("/dashboard")
          return
        }

        setVideo(result.video)
        setOptions(result.options)
        setFiles(result.files || [])
        setPrompts(result.prompts || [])
      } catch (error) {
        console.error("Error al cargar detalles del video:", error)
        toast({
          variant: "destructive",
          title: "Error",
          description: "No se pudieron cargar los detalles del video",
        })
      } finally {
        setIsLoading(false)
      }
    }

    loadVideoDetails()
  }, [params.id, router, toast])

  const handleDownload = () => {
    if (!video) return

    // Crear un elemento <a> temporal
    const link = document.createElement("a")
    link.href = video.url || `/api/videos/${video.id}/download`
    link.target = "_blank"
    link.download = `${video.title.replace(/\s+/g, "_")}.mp4`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    toast({
      title: "Descarga iniciada",
      description: "Tu video se está descargando.",
    })
  }

  const handleBack = () => {
    router.push("/dashboard")
  }

  // Función para renderizar las opciones del video
  const renderOptions = () => {
    if (!options) return <p>No hay opciones disponibles para este video.</p>

    // Determinar qué tipo de opciones mostrar según el tipo de video
    if (video.type === "general") {
      return (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Información básica</CardTitle>
              </CardHeader>
              <CardContent>
                <dl className="space-y-2">
                  <div>
                    <dt className="text-sm font-medium text-muted-foreground">Título</dt>
                    <dd>{options.title || "No especificado"}</dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-muted-foreground">Tema</dt>
                    <dd>{options.topic || "No especificado"}</dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-muted-foreground">Hook</dt>
                    <dd>{options.hook || "No especificado"}</dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-muted-foreground">Formato</dt>
                    <dd>{options.format || "No especificado"}</dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-muted-foreground">Duración</dt>
                    <dd>{options.duration || "No especificado"}</dd>
                  </div>
                </dl>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Elementos adicionales</CardTitle>
              </CardHeader>
              <CardContent>
                <dl className="space-y-2">
                  <div>
                    <dt className="text-sm font-medium text-muted-foreground">Voz en off IA</dt>
                    <dd>{options.ai_voice_over === "yes" ? "Sí" : "No"}</dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-muted-foreground">Subtítulos</dt>
                    <dd>{options.subtitles === "yes" ? "Sí" : "No"}</dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-muted-foreground">B-Roll</dt>
                    <dd>{options.b_roll || "No especificado"}</dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-muted-foreground">Tipografía</dt>
                    <dd>{options.typography || "No especificado"}</dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-muted-foreground">Música</dt>
                    <dd>{options.music_source || "No especificado"}</dd>
                  </div>
                </dl>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Contenido</CardTitle>
            </CardHeader>
            <CardContent>
              <dl className="space-y-4">
                <div>
                  <dt className="text-sm font-medium text-muted-foreground">Fuentes</dt>
                  <dd className="whitespace-pre-wrap">{options.sources || "No especificado"}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-muted-foreground">Keywords / Hashtags</dt>
                  <dd className="whitespace-pre-wrap">{options.keywords || "No especificado"}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-muted-foreground">Palabras restringidas</dt>
                  <dd className="whitespace-pre-wrap">{options.restricted_words || "No especificado"}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-muted-foreground">Temas prohibidos</dt>
                  <dd className="whitespace-pre-wrap">{options.banned_topics || "No especificado"}</dd>
                </div>
              </dl>
            </CardContent>
          </Card>
        </div>
      )
    } else if (video.type === "client") {
      return (
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Opciones de mejora</CardTitle>
            </CardHeader>
            <CardContent>
              <dl className="space-y-2">
                <div>
                  <dt className="text-sm font-medium text-muted-foreground">Hook</dt>
                  <dd>{options.hook || "No especificado"}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-muted-foreground">B-Roll</dt>
                  <dd>{options.b_roll || "No especificado"}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-muted-foreground">Subtítulos</dt>
                  <dd>{options.subtitles === "yes" ? "Sí" : "No"}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-muted-foreground">Idioma</dt>
                  <dd>{options.language || "No especificado"}</dd>
                </div>
              </dl>
            </CardContent>
          </Card>
        </div>
      )
    }

    return <p>No hay opciones disponibles para este tipo de video.</p>
  }

  // Función para renderizar los archivos del video
  const renderFiles = () => {
    if (files.length === 0) {
      return <p>No hay archivos asociados a este video.</p>
    }

    return (
      <div className="space-y-4">
        {files.map((file) => (
          <div key={file.id} className="flex items-center p-3 border rounded-lg">
            <div className="mr-3">
              {file.type?.startsWith("image/") ? (
                <ImageIcon className="h-8 w-8 text-blue-500" />
              ) : file.type?.startsWith("video/") ? (
                <Video className="h-8 w-8 text-blue-500" />
              ) : (
                <FileText className="h-8 w-8 text-blue-500" />
              )}
            </div>
            <div className="flex-1">
              <p className="font-medium">{file.name}</p>
              <p className="text-sm text-muted-foreground">
                {file.type} • {(file.size / (1024 * 1024)).toFixed(2)} MB
              </p>
            </div>
            <Button variant="outline" size="sm" asChild>
              <a href={file.url} target="_blank" rel="noopener noreferrer">
                Descargar
              </a>
            </Button>
          </div>
        ))}
      </div>
    )
  }

  if (isLoading) {
    return (
      <div className="container py-10">
        <div className="max-w-4xl mx-auto">
          <div className="flex justify-center py-20">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900"></div>
          </div>
        </div>
      </div>
    )
  }

  if (!video) {
    return (
      <div className="container py-10">
        <div className="max-w-4xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle>Video no encontrado</CardTitle>
              <CardDescription>No se pudo encontrar el video solicitado.</CardDescription>
            </CardHeader>
            <CardFooter>
              <Button onClick={handleBack}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Volver al dashboard
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="container py-10">
      <div className="max-w-4xl mx-auto">
        <div className="mb-6">
          <Button variant="outline" onClick={handleBack}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Volver al dashboard
          </Button>
        </div>

        <div className="mb-6">
          <h1 className="text-3xl font-bold">{video.title}</h1>
          <p className="text-muted-foreground">
            {video.type === "general" ? "Video general" : video.type === "client" ? "Video de cliente" : "Video AI"}
          </p>
        </div>

        <div className="mb-8">
          <Card>
            <CardContent className="p-0">
              <div className="aspect-video bg-slate-200 dark:bg-slate-800 flex items-center justify-center">
                {video.thumbnail_url ? (
                  <img
                    src={video.thumbnail_url || "/placeholder.svg"}
                    alt={video.title}
                    className="w-full h-full object-contain"
                  />
                ) : (
                  <Play className="h-16 w-16 text-slate-500" />
                )}
              </div>
            </CardContent>
            <CardFooter className="flex justify-between p-4">
              <div>
                <p className="text-sm font-medium">Estado: {video.status}</p>
                <p className="text-xs text-muted-foreground">ID: {video.id}</p>
              </div>
              <Button onClick={handleDownload}>
                <Download className="mr-2 h-4 w-4" />
                Descargar video
              </Button>
            </CardFooter>
          </Card>
        </div>

        <Tabs defaultValue="options" className="w-full">
          <TabsList className="mb-4">
            <TabsTrigger value="options">Opciones</TabsTrigger>
            <TabsTrigger value="files">Archivos ({files.length})</TabsTrigger>
            <TabsTrigger value="prompts">Prompts ({prompts.length})</TabsTrigger>
          </TabsList>
          <TabsContent value="options">{renderOptions()}</TabsContent>
          <TabsContent value="files">{renderFiles()}</TabsContent>
          <TabsContent value="prompts">
            <VideoPrompts videoId={video.id} prompts={prompts} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
