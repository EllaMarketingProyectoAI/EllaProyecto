"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, XCircle, RefreshCw } from "lucide-react"

export function N8nStatusChecker() {
  const [status, setStatus] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const checkStatus = async () => {
    try {
      setLoading(true)
      setError(null)

      const response = await fetch("/api/n8n/status")
      const data = await response.json()

      setStatus(data)
    } catch (err: any) {
      setError(err.message || "Error checking n8n status")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    checkStatus()
  }, [])

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle>n8n Integration Status</CardTitle>
        <CardDescription>Check if n8n is properly configured</CardDescription>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex justify-center py-4">
            <RefreshCw className="h-6 w-6 animate-spin text-blue-500" />
          </div>
        ) : error ? (
          <div className="text-red-500 py-2">{error}</div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span>n8n Integration:</span>
              {status?.configured ? (
                <span className="flex items-center text-green-500">
                  <CheckCircle className="h-5 w-5 mr-1" /> Configured
                </span>
              ) : (
                <span className="flex items-center text-red-500">
                  <XCircle className="h-5 w-5 mr-1" /> Not Configured
                </span>
              )}
            </div>
            <div className="flex items-center justify-between">
              <span>Workflow URL:</span>
              {status?.url === "Configured" ? (
                <span className="flex items-center text-green-500">
                  <CheckCircle className="h-5 w-5 mr-1" /> Configured
                </span>
              ) : (
                <span className="flex items-center text-red-500">
                  <XCircle className="h-5 w-5 mr-1" /> Missing
                </span>
              )}
            </div>
            <div className="flex items-center justify-between">
              <span>API Key:</span>
              {status?.apiKey === "Configured" ? (
                <span className="flex items-center text-green-500">
                  <CheckCircle className="h-5 w-5 mr-1" /> Configured
                </span>
              ) : (
                <span className="flex items-center text-red-500">
                  <XCircle className="h-5 w-5 mr-1" /> Missing
                </span>
              )}
            </div>
            <div className="text-sm text-gray-500 mt-4">
              Last checked: {status?.timestamp ? new Date(status.timestamp).toLocaleString() : "Never"}
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter>
        <Button onClick={checkStatus} disabled={loading} className="w-full">
          {loading ? (
            <>
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> Checking...
            </>
          ) : (
            <>
              <RefreshCw className="h-4 w-4 mr-2" /> Check Again
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}
