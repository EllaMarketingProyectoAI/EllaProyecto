"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { RefreshCw, CheckCircle, XCircle } from "lucide-react"

export function N8nWebhookTester() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)
  const [webhookUrl, setWebhookUrl] = useState<string>("")

  // Obtener la URL del webhook de las variables de entorno
  const getWebhookUrl = async () => {
    try {
      const response = await fetch("/api/n8n/status")
      const data = await response.json()
      if (data.n8nUrl) {
        setWebhookUrl(data.n8nUrl)
      } else {
        setWebhookUrl("No configurada")
      }
    } catch (err) {
      setWebhookUrl("Error al obtener la URL")
    }
  }

  // Cargar la URL al montar el componente
  useState(() => {
    getWebhookUrl()
  })

  // Probar el webhook
  const testWebhook = async () => {
    try {
      setLoading(true)
      setError(null)
      setResult(null)

      // Datos de prueba para el webhook
      const testData = {
        userId: "test-user-id",
        videoId: "test-video-id",
        title: "Video de prueba",
        topic: "Tecnología",
        hook: "Pregunta intrigante",
        format: "Tutorial",
        duration: "60s",
        operation: "generate_prompt",
        requestId: `test-${Date.now()}`,
        timestamp: new Date().toISOString(),
      }

      // Llamar a nuestra API interna que se comunicará con n8n
      const response = await fetch("/api/n8n/webhook", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(testData),
      })

      const data = await response.json()
      setResult(data)
    } catch (err: any) {
      setError(err.message || "Error al probar el webhook")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Probar Webhook de n8n</CardTitle>
        <CardDescription>Verifica que la nueva URL del webhook esté funcionando correctamente</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <h3 className="text-sm font-medium mb-1">URL del Webhook:</h3>
          <div className="p-2 bg-gray-100 rounded text-sm font-mono break-all">{webhookUrl || "Cargando..."}</div>
        </div>

        {result && (
          <div>
            <h3 className="text-sm font-medium mb-1">Resultado:</h3>
            <Textarea value={JSON.stringify(result, null, 2)} readOnly className="font-mono h-40" />
            <div className="mt-2">
              {result.success ? (
                <div className="flex items-center text-green-500">
                  <CheckCircle className="h-5 w-5 mr-1" /> Webhook funcionando correctamente
                </div>
              ) : (
                <div className="flex items-center text-red-500">
                  <XCircle className="h-5 w-5 mr-1" /> Error en el webhook
                </div>
              )}
            </div>
          </div>
        )}

        {error && (
          <div className="p-2 bg-red-50 text-red-500 rounded">
            <p className="font-medium">Error:</p>
            <p>{error}</p>
          </div>
        )}
      </CardContent>
      <CardFooter>
        <Button onClick={testWebhook} disabled={loading} className="w-full">
          {loading ? (
            <>
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> Probando...
            </>
          ) : (
            "Probar Webhook"
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}
