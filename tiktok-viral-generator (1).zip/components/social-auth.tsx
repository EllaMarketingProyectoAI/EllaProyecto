"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, Check } from "lucide-react"
import { useUserStore } from "@/lib/store/user-store"

interface SocialAuthProps {
  onSuccess?: (platform: string, token: string) => void
}

export function SocialAuth({ onSuccess }: SocialAuthProps) {
  const { user } = useUserStore()
  const [connections, setConnections] = useState<Record<string, boolean>>({
    tiktok: false,
    instagram: false,
    facebook: false,
  })
  const [authStatus, setAuthStatus] = useState<{
    tiktok: "idle" | "loading" | "success" | "error"
    instagram: "idle" | "loading" | "success" | "error"
    facebook: "idle" | "loading" | "success" | "error"
  }>({
    tiktok: "idle",
    instagram: "idle",
    facebook: "idle",
  })
  const [error, setError] = useState<string | null>(null)

  // Simulamos la autenticación sin necesidad de variables de entorno
  const handleAuth = async (platform: "tiktok" | "instagram" | "facebook") => {
    if (!user) {
      setError("Debes iniciar sesión para conectar tus cuentas")
      return
    }

    setAuthStatus((prev) => ({ ...prev, [platform]: "loading" }))
    setError(null)

    // Simulamos un proceso de autenticación exitoso después de un breve retraso
    setTimeout(() => {
      setAuthStatus((prev) => ({ ...prev, [platform]: "success" }))
      setConnections((prev) => ({ ...prev, [platform]: true }))

      if (onSuccess) {
        onSuccess(platform, `mock-${platform}-token-${Date.now()}`)
      }
    }, 1000)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Conecta tus cuentas</CardTitle>
        <CardDescription>
          Conecta tus cuentas de redes sociales para acceder a videos virales y automatizar la creación de contenido.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="space-y-3">
          <Button
            onClick={() => handleAuth("tiktok")}
            variant="outline"
            className="w-full justify-start"
            disabled={authStatus.tiktok === "loading" || authStatus.tiktok === "success"}
          >
            {authStatus.tiktok === "loading" ? (
              <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-solid border-current border-r-transparent"></div>
            ) : authStatus.tiktok === "success" ? (
              <Check className="mr-2 h-4 w-4 text-green-500" />
            ) : (
              <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24">
                <path
                  fill="currentColor"
                  d="M19.321 5.562a5.124 5.124 0 0 1-3.414-1.267 5.124 5.124 0 0 1-1.267-3.414h-4.134v15.61c0 .648-.525 1.173-1.173 1.173a1.173 1.173 0 0 1-1.173-1.173c0-.648.525-1.173 1.173-1.173.141 0 .276.024.401.069V10.96a5.124 5.124 0 0 0-3.414 1.267 5.124 5.124 0 0 0-1.267 3.414c0 1.267.483 2.483 1.267 3.414a5.124 5.124 0 0 0 3.414 1.267 5.124 5.124 0 0 0 3.414-1.267 5.124 5.124 0 0 0 1.267-3.414V9.779a8.814 8.814 0 0 0 5.173 1.66V7.305a5.124 5.124 0 0 1-1.267.173Z"
                />
              </svg>
            )}
            Conectar con TikTok
          </Button>

          <Button
            onClick={() => handleAuth("instagram")}
            variant="outline"
            className="w-full justify-start"
            disabled={authStatus.instagram === "loading" || authStatus.instagram === "success"}
          >
            {authStatus.instagram === "loading" ? (
              <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-solid border-current border-r-transparent"></div>
            ) : authStatus.instagram === "success" ? (
              <Check className="mr-2 h-4 w-4 text-green-500" />
            ) : (
              <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24">
                <path
                  fill="currentColor"
                  d="M12 2.982c2.937 0 3.285.011 4.445.064 1.072.049 1.655.228 2.042.379.513.2.88.437 1.265.822.385.385.622.752.822 1.265.151.387.33.97.379 2.042.053 1.16.064 1.508.064 4.445 0 2.937-.011 3.285-.064 4.445-.049 1.072-.228 1.655-.379 2.042-.2.513-.437.88-.822 1.265-.385.385-.752.622-1.265.822-.387.151-.97.33-2.042.379-1.16.053-1.508.064-4.445.064-2.937 0-3.285-.011-4.445-.064-1.072-.049-1.655-.228-2.042-.379-.513-.2-.88-.437-1.265-.822-.385-.385-.622-.752-.822-1.265-.151-.387-.33-.97-.379-2.042-.053-1.16-.064-1.508-.064-4.445 0-2.937.011-3.285.064-4.445.049-1.072.228-1.655.379-2.042.2-.513.437-.88.822-1.265.385-.385.752-.622 1.265-.822.387-.151.97-.33 2.042-.379 1.16-.053 1.508-.064 4.445-.064M12 0c-2.987 0-3.362.013-4.535.066-1.171.054-1.971.24-2.67.511a5.39 5.39 0 0 0-1.949 1.27 5.39 5.39 0 0 0-1.27 1.949c-.271.699-.457 1.499-.511 2.67C.013 8.638 0 9.013 0 12s.013 3.362.066 4.535c.054 1.171.24 1.971.511 2.67a5.39 5.39 0 0 0 1.27 1.949 5.39 5.39 0 0 0 1.949 1.27c.699.271 1.499.457 2.67.511C8.638 23.987 9.013 24 12 24s3.362-.013 4.535-.066c1.171-.054 1.971-.24 2.67-.511a5.39 5.39 0 0 0 1.949-1.27 5.39 5.39 0 0 0 1.27-1.949c.271-.699.457-1.499.511-2.67.053-1.173.066-1.548.066-4.535s-.013-3.362-.066-4.535c-.054-1.171-.24-1.971-.511-2.67a5.39 5.39 0 0 0-1.27-1.949 5.39 5.39 0 0 0-1.949-1.27c-.699-.271-1.499-.457-2.67-.511C15.362.013 14.987 0 12 0zm0 5.838a6.162 6.162 0 1 0 0 12.324 6.162 6.162 0 0 0 0-12.324zM12 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm7.846-10.406a1.44 1.44 0 1 1-2.88 0 1.44 1.44 0 0 1 2.88 0z"
                />
              </svg>
            )}
            Conectar con Instagram
          </Button>

          <Button
            onClick={() => handleAuth("facebook")}
            variant="outline"
            className="w-full justify-start"
            disabled={authStatus.facebook === "loading" || authStatus.facebook === "success"}
          >
            {authStatus.facebook === "loading" ? (
              <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-solid border-current border-r-transparent"></div>
            ) : authStatus.facebook === "success" ? (
              <Check className="mr-2 h-4 w-4 text-green-500" />
            ) : (
              <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24">
                <path
                  fill="currentColor"
                  d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"
                />
              </svg>
            )}
            Conectar con Facebook
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
