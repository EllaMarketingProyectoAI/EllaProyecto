"use client"

import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useUserStore } from "@/lib/store/user-store"
import Link from "next/link"
import { useToast } from "./ui/use-toast"
import { Film, Library, User, Home } from "lucide-react"

export function UserNav() {
  const { user, isAuthenticated, logout } = useUserStore()
  const { toast } = useToast()

  // Función simplificada para manejar el cierre de sesión
  const handleLogout = () => {
    logout()
    toast({
      title: "Sesión cerrada",
      description: "Has cerrado sesión correctamente.",
    })
  }

  // Si no está autenticado, mostrar botón de inicio de sesión
  if (!isAuthenticated) {
    return (
      <Link href="/auth">
        <Button variant="outline">Iniciar sesión</Button>
      </Link>
    )
  }

  // Obtener la primera letra del nombre de usuario o un valor predeterminado
  const userInitial = user?.username ? user.username.charAt(0).toUpperCase() : "U"

  return (
    <div className="flex items-center gap-2">
      {/* Botón para ir a la biblioteca de videos */}
      <Link href="/dashboard">
        <Button variant="outline" size="icon" className="rounded-full" title="Mi biblioteca de videos">
          <Library className="h-5 w-5" />
          <span className="sr-only">Mi biblioteca de videos</span>
        </Button>
      </Link>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" className="relative h-10 w-10 rounded-full">
            <Avatar className="h-10 w-10">
              <AvatarFallback className="bg-blue-600 text-white">{userInitial}</AvatarFallback>
            </Avatar>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-56" align="end" forceMount>
          <DropdownMenuLabel>
            <div className="flex flex-col space-y-1">
              <p className="text-sm font-medium leading-none">{user?.username || "Usuario"}</p>
              <p className="text-xs leading-none text-muted-foreground">{user?.email || "usuario@ejemplo.com"}</p>
            </div>
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem asChild>
            <Link href="/" className="flex items-center">
              <Home className="mr-2 h-4 w-4" />
              <span>Inicio</span>
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem asChild>
            <Link href="/profile" className="flex items-center">
              <User className="mr-2 h-4 w-4" />
              <span>Mi perfil</span>
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem asChild>
            <Link href="/dashboard" className="flex items-center">
              <Library className="mr-2 h-4 w-4" />
              <span>Mi biblioteca</span>
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem asChild>
            <Link href="/video-selection" className="flex items-center">
              <Film className="mr-2 h-4 w-4" />
              <span>Crear video</span>
            </Link>
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={handleLogout}>Cerrar sesión</DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  )
}
