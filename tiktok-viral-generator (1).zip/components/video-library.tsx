"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Download, Play, Info } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { getUserVideos } from "@/lib/services/video-service"
import { useRouter } from "next/navigation"

interface VideoLibraryProps {
  userId: string
}

export function VideoLibrary({ userId }: VideoLibraryProps) {
  const [videos, setVideos] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const { toast } = useToast()
  const router = useRouter()

  useEffect(() => {
    async function fetchVideos() {
      try {
        setLoading(true)
        console.log("Obteniendo videos para el usuario:", userId)

        // Esperar un poco para dar tiempo a la hidratación
        await new Promise((resolve) => setTimeout(resolve, 1000))

        const result = await getUserVideos(userId)

        if (!result.success) {
          console.error("Error al obtener videos:", result.error)
          setError(result.error || "Error al cargar los videos")
          toast({
            variant: "destructive",
            title: "Error",
            description: "No se pudieron cargar tus videos. Por favor, intenta de nuevo más tarde.",
          })
          return
        }

        console.log("Videos obtenidos:", result.videos)
        setVideos(result.videos || [])
      } catch (err: any) {
        console.error("Error inesperado:", err)
        setError(err.message || "Error desconocido")
        toast({
          variant: "destructive",
          title: "Error",
          description: "Ocurrió un error al cargar tus videos.",
        })
      } finally {
        setLoading(false)
      }
    }

    if (userId) {
      fetchVideos()
    } else {
      setLoading(false)
      setError("Usuario no identificado")
    }
  }, [userId, toast])

  const handleDownload = (video: any) => {
    // Crear un elemento <a> temporal
    const link = document.createElement("a")
    link.href = video.file_url || `/api/videos/${video.id}/download`
    link.target = "_blank"
    link.download = video.file_name || `video_${video.id}.mp4`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    toast({
      title: "Descarga iniciada",
      description: "Tu video se está descargando.",
    })
  }

  const handleViewDetails = (videoId: string) => {
    router.push(`/video/${videoId}`)
  }

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold">Tu biblioteca de videos</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="overflow-hidden">
              <div className="aspect-video bg-slate-200 animate-pulse" />
              <CardHeader className="animate-pulse">
                <div className="h-5 bg-slate-200 rounded w-3/4 mb-2"></div>
                <div className="h-4 bg-slate-200 rounded w-1/2"></div>
              </CardHeader>
              <CardFooter className="animate-pulse">
                <div className="h-9 bg-slate-200 rounded w-full"></div>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold">Tu biblioteca de videos</h2>
        </div>
        <Card>
          <CardHeader>
            <CardTitle>Error</CardTitle>
            <CardDescription>No se pudieron cargar tus videos</CardDescription>
          </CardHeader>
          <CardContent>
            <p>{error}</p>
          </CardContent>
          <CardFooter>
            <Button onClick={() => window.location.reload()}>Intentar de nuevo</Button>
          </CardFooter>
        </Card>
      </div>
    )
  }

  if (videos.length === 0) {
    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold">Tu biblioteca de videos</h2>
        </div>
        <Card>
          <CardHeader>
            <CardTitle>No hay videos</CardTitle>
            <CardDescription>Aún no has creado ningún video</CardDescription>
          </CardHeader>
          <CardContent>
            <p>Crea tu primer video utilizando nuestras herramientas de generación.</p>
          </CardContent>
          <CardFooter>
            <Button onClick={() => router.push("/video-selection")}>Crear video</Button>
          </CardFooter>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Tu biblioteca de videos</h2>
        <Button onClick={() => router.push("/video-selection")}>Crear nuevo video</Button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {videos.map((video) => (
          <Card key={video.id} className="overflow-hidden">
            <div className="aspect-video bg-slate-200 dark:bg-slate-800 relative group">
              <img
                src={video.thumbnail_url || "/placeholder.svg"}
                alt={video.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100">
                <Button variant="outline" size="icon" className="rounded-full bg-white text-black mr-2">
                  <Play className="h-5 w-5" />
                </Button>
              </div>
            </div>
            <CardHeader>
              <CardTitle className="line-clamp-1">{video.title}</CardTitle>
              <CardDescription>
                {video.duration || "00:00"} • {video.format || "MP4"} •{" "}
                {video.file_size ? `${(video.file_size / (1024 * 1024)).toFixed(2)} MB` : "0 MB"}
              </CardDescription>
            </CardHeader>
            <CardFooter className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => handleViewDetails(video.id)}>
                <Info className="h-4 w-4 mr-2" />
                Ver detalles
              </Button>
              <Button size="sm" onClick={() => handleDownload(video)}>
                <Download className="h-4 w-4 mr-2" />
                Descargar
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}
