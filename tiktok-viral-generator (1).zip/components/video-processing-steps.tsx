import { Card, CardContent } from "@/components/ui/card"

export function VideoProcessingSteps() {
  const steps = [
    {
      id: 1,
      title: "Análisis del video",
      description: "Identificamos la narrativa, temática y formato del video original.",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="lucide lucide-search"
        >
          <circle cx="11" cy="11" r="8" />
          <path d="m21 21-4.3-4.3" />
        </svg>
      ),
    },
    {
      id: 2,
      title: "Selección de formato",
      description: "Definimos el formato adecuado para comunicar el mensaje de manera efectiva.",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="lucide lucide-layout-template"
        >
          <rect width="18" height="7" x="3" y="3" rx="1" />
          <rect width="9" height="7" x="3" y="14" rx="1" />
          <rect width="5" height="7" x="16" y="14" rx="1" />
        </svg>
      ),
    },
    {
      id: 3,
      title: "Música estratégica",
      description: "Agregamos música que complementa el contenido y mantiene el interés.",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="lucide lucide-music"
        >
          <path d="M9 18V5l12-2v13" />
          <circle cx="6" cy="18" r="3" />
          <circle cx="18" cy="16" r="3" />
        </svg>
      ),
    },
    {
      id: 4,
      title: "Subtítulos y cortes",
      description: "Añadimos subtítulos para facilitar el corte del video y eliminar espacios muertos.",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="lucide lucide-subtitles"
        >
          <path d="M7 13h4" />
          <path d="M15 13h2" />
          <path d="M7 9h2" />
          <path d="M13 9h4" />
          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10Z" />
        </svg>
      ),
    },
    {
      id: 5,
      title: "Zooms y transiciones",
      description: "Aplicamos zooms y transiciones en momentos clave para mantener el dinamismo.",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="lucide lucide-move-horizontal"
        >
          <path d="M18 8L22 12L18 16" />
          <path d="M6 8L2 12L6 16" />
          <path d="M2 12H22" />
        </svg>
      ),
    },
    {
      id: 6,
      title: "Efectos de sonido",
      description: "Añadimos sonidos en momentos clave para enfatizar acciones o reacciones.",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="lucide lucide-volume-2"
        >
          <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
          <path d="M15.54 8.46a5 5 0 0 1 0 7.07" />
          <path d="M19.07 4.93a10 10 0 0 1 0 14.14" />
        </svg>
      ),
    },
    {
      id: 7,
      title: "B-Roll estratégico",
      description: "Incorporamos B-Roll como factor importante para captar la atención.",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="lucide lucide-film"
        >
          <rect width="20" height="20" x="2" y="2" rx="2.18" ry="2.18" />
          <line x1="7" x2="7" y1="2" y2="22" />
          <line x1="17" x2="17" y1="2" y2="22" />
          <line x1="2" x2="22" y1="12" y2="12" />
          <line x1="2" x2="7" y1="7" y2="7" />
          <line x1="2" x2="7" y1="17" y2="17" />
          <line x1="17" x2="22" y1="17" y2="17" />
          <line x1="17" x2="22" y1="7" y2="7" />
        </svg>
      ),
    },
    {
      id: 8,
      title: "Música final",
      description: "Cerramos con música que completa la narrativa y refuerza el mensaje.",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="lucide lucide-music-4"
        >
          <path d="M9 18V5l12-2v13" />
          <path d="m9 9 12-2" />
          <circle cx="6" cy="18" r="3" />
          <circle cx="18" cy="16" r="3" />
        </svg>
      ),
    },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {steps.map((step) => (
        <Card key={step.id} className="border-blue-100 dark:border-blue-900">
          <CardContent className="pt-6">
            <div className="flex flex-col items-center text-center space-y-3">
              <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-full">
                <div className="text-blue-600 dark:text-blue-400">{step.icon}</div>
              </div>
              <h3 className="font-medium">{step.title}</h3>
              <p className="text-sm text-muted-foreground">{step.description}</p>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
