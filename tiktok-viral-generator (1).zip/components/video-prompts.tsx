"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Copy, Check, RefreshCw } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

interface VideoPrompt {
  id: string
  videoId: string
  userId: string
  promptText: string
  inputContext: Record<string, any>
  workflowId?: string
  executionId?: string
  createdAt: string
}

interface VideoPromptsProps {
  videoId: string
  prompts?: VideoPrompt[]
}

export function VideoPrompts({ videoId, prompts = [] }: VideoPromptsProps) {
  const [localPrompts, setLocalPrompts] = useState<VideoPrompt[]>(prompts)
  const [isLoading, setIsLoading] = useState(false)
  const [copied, setCopied] = useState<Record<string, boolean>>({})
  const { toast } = useToast()

  // Función para formatear la fecha
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return new Intl.DateTimeFormat("es", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date)
  }

  // Función para copiar el prompt al portapapeles
  const copyToClipboard = (text: string, promptId: string) => {
    navigator.clipboard.writeText(text).then(
      () => {
        setCopied({ ...copied, [promptId]: true })
        toast({
          title: "Copiado al portapapeles",
          description: "El prompt ha sido copiado al portapapeles.",
        })
        setTimeout(() => {
          setCopied({ ...copied, [promptId]: false })
        }, 2000)
      },
      (err) => {
        console.error("No se pudo copiar el texto: ", err)
        toast({
          variant: "destructive",
          title: "Error",
          description: "No se pudo copiar el texto al portapapeles.",
        })
      },
    )
  }

  // Función para cargar los prompts
  const loadPrompts = async () => {
    try {
      setIsLoading(true)
      // Aquí iría la lógica para cargar los prompts desde la API
      // Por ahora, simplemente usamos los prompts pasados como props
      setIsLoading(false)
    } catch (error) {
      console.error("Error al cargar los prompts:", error)
      setIsLoading(false)
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudieron cargar los prompts.",
      })
    }
  }

  // Cargar los prompts al montar el componente
  useEffect(() => {
    if (prompts.length === 0) {
      loadPrompts()
    } else {
      setLocalPrompts(prompts)
    }
  }, [prompts])

  // Si no hay prompts, mostrar un mensaje
  if (localPrompts.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Prompts generados</CardTitle>
          <CardDescription>No hay prompts generados para este video.</CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center py-6">
          <p className="text-muted-foreground text-center">
            Los prompts se generan automáticamente al crear un video.
            <br />
            Si no ves ningún prompt, es posible que aún no se hayan generado.
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Prompts generados</CardTitle>
            <CardDescription>Prompts generados para este video</CardDescription>
          </div>
          <Button variant="outline" size="sm" onClick={loadPrompts} disabled={isLoading}>
            {isLoading ? (
              <>
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                Cargando...
              </>
            ) : (
              <>
                <RefreshCw className="mr-2 h-4 w-4" />
                Actualizar
              </>
            )}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="latest" className="w-full">
          <TabsList className="mb-4">
            <TabsTrigger value="latest">Último prompt</TabsTrigger>
            <TabsTrigger value="all">Todos los prompts ({localPrompts.length})</TabsTrigger>
          </TabsList>
          <TabsContent value="latest">
            {localPrompts.length > 0 && (
              <div className="space-y-4">
                <div className="bg-slate-50 dark:bg-slate-900 p-4 rounded-md">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <p className="text-sm font-medium">Generado el {formatDate(localPrompts[0].createdAt)}</p>
                      <p className="text-xs text-muted-foreground">ID: {localPrompts[0].id.substring(0, 8)}...</p>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => copyToClipboard(localPrompts[0].promptText, localPrompts[0].id)}
                    >
                      {copied[localPrompts[0].id] ? (
                        <Check className="h-4 w-4 text-green-500" />
                      ) : (
                        <Copy className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                  <div className="whitespace-pre-wrap text-sm">{localPrompts[0].promptText}</div>
                </div>
              </div>
            )}
          </TabsContent>
          <TabsContent value="all">
            <div className="space-y-4">
              {localPrompts.map((prompt) => (
                <div key={prompt.id} className="bg-slate-50 dark:bg-slate-900 p-4 rounded-md">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <p className="text-sm font-medium">Generado el {formatDate(prompt.createdAt)}</p>
                      <p className="text-xs text-muted-foreground">ID: {prompt.id.substring(0, 8)}...</p>
                    </div>
                    <Button variant="ghost" size="sm" onClick={() => copyToClipboard(prompt.promptText, prompt.id)}>
                      {copied[prompt.id] ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
                    </Button>
                  </div>
                  <div className="whitespace-pre-wrap text-sm">{prompt.promptText}</div>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-between">
        <p className="text-xs text-muted-foreground">Los prompts se generan automáticamente al crear un video.</p>
      </CardFooter>
    </Card>
  )
}
