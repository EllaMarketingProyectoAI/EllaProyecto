"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

export function VideoUrlInput() {
  const [url, setUrl] = useState("")
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!url.trim()) {
      setError("Por favor ingresa una URL válida")
      return
    }

    if (!url.includes("tiktok.com")) {
      setError("Por favor ingresa una URL válida de TikTok")
      return
    }

    setError(null)
    // Aquí iría la lógica para procesar la URL
    console.log("Procesando URL:", url)
  }

  return (
    <Card className="border-2 border-blue-100 dark:border-blue-900">
      <CardContent className="pt-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Input
              type="url"
              placeholder="Pega la URL del video de TikTok aquí"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              className="h-14 text-lg"
            />
            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
          </div>
          <div className="flex justify-end">
            <Button type="submit" size="lg" className="bg-blue-600 hover:bg-blue-700">
              Analizar URL
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
