"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import type { SocialVideo } from "@/lib/api/social-api"
import { Play, Download, ArrowRight, Check, X } from "lucide-react"

interface ViralVideoGeneratorProps {
  video: SocialVideo
  onClose: () => void
  onComplete: (generatedVideo: any) => void
}

export function ViralVideoGenerator({ video, onClose, onComplete }: ViralVideoGeneratorProps) {
  const [step, setStep] = useState<"options" | "processing" | "complete">("options")
  const [progress, setProgress] = useState(0)
  const [selectedOptions, setSelectedOptions] = useState({
    music: true,
    subtitles: true,
    zooms: true,
    transitions: true,
    soundEffects: true,
    bRoll: true,
  })
  const [generatedVideo, setGeneratedVideo] = useState<any>(null)

  const handleOptionChange = (option: keyof typeof selectedOptions) => {
    setSelectedOptions((prev) => ({
      ...prev,
      [option]: !prev[option],
    }))
  }

  const handleGenerate = () => {
    setStep("processing")
    setProgress(0)

    console.log("Iniciando generación de video viral con opciones:", selectedOptions)

    // Simulamos el proceso de generación con un progreso
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)

          // Creamos un video generado basado en el original
          const newVideo = {
            id: `generated-${video.id}`,
            platform: video.platform,
            url: `https://${video.platform}.com/generated/${video.id}`,
            thumbnail: "/placeholder.svg?height=720&width=1280",
            title: `${video.title} (Versión viral)`,
            views: 0,
            likes: 0,
            date: new Date().toISOString().split("T")[0],
            author: video.author,
            options: selectedOptions,
            originalVideo: video,
            downloadUrl: `/api/videos/${video.id}/download`,
          }

          console.log("Video generado:", newVideo)
          setGeneratedVideo(newVideo)
          setStep("complete")
          return 100
        }
        return prev + 5
      })
    }, 200)
  }

  const handleComplete = () => {
    onComplete(generatedVideo)
    onClose()
  }

  // Actualizar los pasos de procesamiento
  const [processingSteps, setProcessingSteps] = useState([
    { name: "Analizando video original", status: "pending" },
    { name: "Aplicando música estratégica", status: "pending" },
    { name: "Generando subtítulos", status: "pending" },
    { name: "Aplicando efectos visuales", status: "pending" },
    { name: "Finalizando video", status: "pending" },
  ])

  useEffect(() => {
    if (step === "processing") {
      // Actualizamos los estados de los pasos según el progreso
      if (progress >= 20) {
        setProcessingSteps((prev) => {
          const updated = [...prev]
          updated[0].status = "completed"
          return updated
        })
      }
      if (progress >= 40) {
        setProcessingSteps((prev) => {
          const updated = [...prev]
          updated[1].status = "completed"
          return updated
        })
      }
      if (progress >= 60) {
        setProcessingSteps((prev) => {
          const updated = [...prev]
          updated[2].status = "completed"
          return updated
        })
      }
      if (progress >= 80) {
        setProcessingSteps((prev) => {
          const updated = [...prev]
          updated[3].status = "completed"
          return updated
        })
      }
      if (progress >= 100) {
        setProcessingSteps((prev) => {
          const updated = [...prev]
          updated[4].status = "completed"
          return updated
        })
      }
    }
  }, [progress, step])

  return (
    <Card className="w-full max-w-3xl mx-auto">
      <CardHeader>
        <CardTitle className="flex justify-between items-center">
          <span>Generar video viral</span>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {step === "options" && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="aspect-video rounded-lg overflow-hidden">
                <img
                  src={video.thumbnail || "/placeholder.svg"}
                  alt={video.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="space-y-4">
                <h3 className="text-lg font-medium">{video.title}</h3>
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-full overflow-hidden">
                    <img
                      src={video.author.avatar || "/placeholder.svg"}
                      alt={video.author.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <span className="text-sm">{video.author.name}</span>
                </div>
                <div className="text-sm text-muted-foreground">
                  <p>{new Intl.NumberFormat("es-ES").format(video.views)} vistas</p>
                  <p>{new Intl.NumberFormat("es-ES").format(video.likes)} likes</p>
                  <p>Fecha: {video.date}</p>
                </div>
                <Button variant="outline" size="sm" className="w-full">
                  <Play className="h-4 w-4 mr-1" />
                  Ver video original
                </Button>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-medium mb-4">Opciones de generación</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-start space-x-2">
                  <Checkbox
                    id="music"
                    checked={selectedOptions.music}
                    onCheckedChange={() => handleOptionChange("music")}
                  />
                  <div className="grid gap-1.5 leading-none">
                    <Label htmlFor="music">Música estratégica</Label>
                    <p className="text-sm text-muted-foreground">Añadir música que complementa el contenido</p>
                  </div>
                </div>
                <div className="flex items-start space-x-2">
                  <Checkbox
                    id="subtitles"
                    checked={selectedOptions.subtitles}
                    onCheckedChange={() => handleOptionChange("subtitles")}
                  />
                  <div className="grid gap-1.5 leading-none">
                    <Label htmlFor="subtitles">Subtítulos</Label>
                    <p className="text-sm text-muted-foreground">Añadir subtítulos para mejorar la retención</p>
                  </div>
                </div>
                <div className="flex items-start space-x-2">
                  <Checkbox
                    id="zooms"
                    checked={selectedOptions.zooms}
                    onCheckedChange={() => handleOptionChange("zooms")}
                  />
                  <div className="grid gap-1.5 leading-none">
                    <Label htmlFor="zooms">Zooms</Label>
                    <p className="text-sm text-muted-foreground">Aplicar zooms en momentos clave</p>
                  </div>
                </div>
                <div className="flex items-start space-x-2">
                  <Checkbox
                    id="transitions"
                    checked={selectedOptions.transitions}
                    onCheckedChange={() => handleOptionChange("transitions")}
                  />
                  <div className="grid gap-1.5 leading-none">
                    <Label htmlFor="transitions">Transiciones</Label>
                    <p className="text-sm text-muted-foreground">Añadir transiciones dinámicas</p>
                  </div>
                </div>
                <div className="flex items-start space-x-2">
                  <Checkbox
                    id="soundEffects"
                    checked={selectedOptions.soundEffects}
                    onCheckedChange={() => handleOptionChange("soundEffects")}
                  />
                  <div className="grid gap-1.5 leading-none">
                    <Label htmlFor="soundEffects">Efectos de sonido</Label>
                    <p className="text-sm text-muted-foreground">Añadir efectos de sonido para enfatizar</p>
                  </div>
                </div>
                <div className="flex items-start space-x-2">
                  <Checkbox
                    id="bRoll"
                    checked={selectedOptions.bRoll}
                    onCheckedChange={() => handleOptionChange("bRoll")}
                  />
                  <div className="grid gap-1.5 leading-none">
                    <Label htmlFor="bRoll">B-Roll estratégico</Label>
                    <p className="text-sm text-muted-foreground">Incorporar B-Roll para captar atención</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end">
              <Button onClick={handleGenerate} className="bg-blue-600 hover:bg-blue-700">
                Generar video
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        )}

        {step === "processing" && (
          <div className="py-8 space-y-6">
            <div className="text-center space-y-4">
              <div className="inline-block h-12 w-12 animate-spin rounded-full border-4 border-solid border-blue-600 border-r-transparent"></div>
              <h3 className="text-xl font-medium">Procesando video</h3>
              <p className="text-muted-foreground">
                Estamos aplicando la metodología del Patrón de Disrupción a tu video...
              </p>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Progreso total</span>
                <span>{progress}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>

            <div className="space-y-3 mt-6">
              {processingSteps.map((step, index) => (
                <div key={index} className="flex justify-between items-center">
                  <span className="text-sm">{step.name}</span>
                  {step.status === "completed" ? (
                    <Check className="h-4 w-4 text-green-500" />
                  ) : (
                    <div className="h-4 w-4 animate-pulse bg-blue-600 rounded-full"></div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {step === "complete" && (
          <div className="py-8 space-y-6">
            <div className="text-center space-y-4">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 text-green-600">
                <Check className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-medium">¡Video generado con éxito!</h3>
              <p className="text-muted-foreground max-w-md mx-auto">
                Tu video viral ha sido procesado aplicando la metodología del Patrón de Disrupción.
              </p>
            </div>

            <div className="aspect-video rounded-lg overflow-hidden max-w-md mx-auto">
              <img
                src="/placeholder.svg?height=360&width=640"
                alt="Video generado"
                className="w-full h-full object-cover"
              />
            </div>

            <div className="space-y-4 max-w-md mx-auto">
              <h4 className="font-medium">{generatedVideo?.title}</h4>

              <div className="space-y-2">
                <h5 className="text-sm font-medium">Elementos aplicados:</h5>
                <ul className="grid grid-cols-2 gap-2">
                  {selectedOptions.music && (
                    <li className="flex items-center text-sm">
                      <Check className="h-4 w-4 text-green-500 mr-2" />
                      Música estratégica
                    </li>
                  )}
                  {selectedOptions.subtitles && (
                    <li className="flex items-center text-sm">
                      <Check className="h-4 w-4 text-green-500 mr-2" />
                      Subtítulos
                    </li>
                  )}
                  {selectedOptions.zooms && (
                    <li className="flex items-center text-sm">
                      <Check className="h-4 w-4 text-green-500 mr-2" />
                      Zooms
                    </li>
                  )}
                  {selectedOptions.transitions && (
                    <li className="flex items-center text-sm">
                      <Check className="h-4 w-4 text-green-500 mr-2" />
                      Transiciones
                    </li>
                  )}
                  {selectedOptions.soundEffects && (
                    <li className="flex items-center text-sm">
                      <Check className="h-4 w-4 text-green-500 mr-2" />
                      Efectos de sonido
                    </li>
                  )}
                  {selectedOptions.bRoll && (
                    <li className="flex items-center text-sm">
                      <Check className="h-4 w-4 text-green-500 mr-2" />
                      B-Roll estratégico
                    </li>
                  )}
                </ul>
              </div>
            </div>

            <div className="flex justify-center gap-4">
              <Button variant="outline">
                <Play className="mr-2 h-4 w-4" />
                Reproducir
              </Button>
              <Button onClick={onComplete} className="bg-green-600 hover:bg-green-700 mr-2">
                Guardar en biblioteca
              </Button>
              <Button
                className="bg-blue-600 hover:bg-blue-700"
                onClick={() => {
                  // Creamos un enlace de descarga simulado
                  const link = document.createElement("a")
                  link.href = generatedVideo?.downloadUrl || `/api/videos/${video.id}/download`
                  link.target = "_blank"
                  link.download = `${video.title}-viral.mp4`
                  document.body.appendChild(link)
                  link.click()
                  document.body.removeChild(link)
                }}
              >
                <Download className="mr-2 h-4 w-4" />
                Descargar
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
