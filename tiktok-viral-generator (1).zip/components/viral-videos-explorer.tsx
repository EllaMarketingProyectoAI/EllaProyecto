"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Play, Edit, Search } from "lucide-react"
import type { SocialVideo } from "@/lib/api/social-api"

// Datos de ejemplo garantizados para mostrar
const MOCK_VIDEOS: Record<string, SocialVideo[]> = {
  tiktok: [
    {
      id: "1",
      platform: "tiktok",
      url: "https://tiktok.com/video/1",
      thumbnail: "/placeholder.svg?height=180&width=320",
      title: "Baile viral de TikTok #1",
      views: 2500000,
      likes: 150000,
      date: "2023-03-15",
      author: {
        name: "DancerPro",
        avatar: "/placeholder.svg?height=50&width=50",
        id: "dancer1",
      },
    },
    {
      id: "2",
      platform: "tiktok",
      url: "https://tiktok.com/video/2",
      thumbnail: "/placeholder.svg?height=180&width=320",
      title: "Challenge de comida picante",
      views: 1800000,
      likes: 120000,
      date: "2023-03-10",
      author: {
        name: "FoodieChallenge",
        avatar: "/placeholder.svg?height=50&width=50",
        id: "foodie2",
      },
    },
    {
      id: "3",
      platform: "tiktok",
      url: "https://tiktok.com/video/3",
      thumbnail: "/placeholder.svg?height=180&width=320",
      title: "Truco de magia impresionante",
      views: 3200000,
      likes: 210000,
      date: "2023-03-05",
      author: {
        name: "MagicMaster",
        avatar: "/placeholder.svg?height=50&width=50",
        id: "magic3",
      },
    },
  ],
  instagram: [
    {
      id: "1",
      platform: "instagram",
      url: "https://instagram.com/p/1",
      thumbnail: "/placeholder.svg?height=180&width=320",
      title: "Receta de pasta viral",
      views: 4500000,
      likes: 350000,
      date: "2023-03-18",
      author: {
        name: "ChefGourmet",
        avatar: "/placeholder.svg?height=50&width=50",
        id: "chef1",
      },
    },
    {
      id: "2",
      platform: "instagram",
      url: "https://instagram.com/p/2",
      thumbnail: "/placeholder.svg?height=180&width=320",
      title: "Tutorial de maquillaje tendencia",
      views: 2800000,
      likes: 190000,
      date: "2023-03-12",
      author: {
        name: "BeautyQueen",
        avatar: "/placeholder.svg?height=50&width=50",
        id: "beauty2",
      },
    },
    {
      id: "3",
      platform: "instagram",
      url: "https://instagram.com/p/3",
      thumbnail: "/placeholder.svg?height=180&width=320",
      title: "Transformación de casa increíble",
      views: 5200000,
      likes: 410000,
      date: "2023-03-08",
      author: {
        name: "HomeDesigner",
        avatar: "/placeholder.svg?height=50&width=50",
        id: "home3",
      },
    },
  ],
  facebook: [
    {
      id: "1",
      platform: "facebook",
      url: "https://facebook.com/watch/1",
      thumbnail: "/placeholder.svg?height=180&width=320",
      title: "Experimento científico asombroso",
      views: 7500000,
      likes: 550000,
      date: "2023-03-20",
      author: {
        name: "ScienceGeek",
        avatar: "/placeholder.svg?height=50&width=50",
        id: "science1",
      },
    },
    {
      id: "2",
      platform: "facebook",
      url: "https://facebook.com/watch/2",
      thumbnail: "/placeholder.svg?height=180&width=320",
      title: "Rescate de animales conmovedor",
      views: 9800000,
      likes: 820000,
      date: "2023-03-14",
      author: {
        name: "AnimalRescue",
        avatar: "/placeholder.svg?height=50&width=50",
        id: "animal2",
      },
    },
    {
      id: "3",
      platform: "facebook",
      url: "https://facebook.com/watch/3",
      thumbnail: "/placeholder.svg?height=180&width=320",
      title: "Truco de parkour extremo",
      views: 6200000,
      likes: 410000,
      date: "2023-03-09",
      author: {
        name: "ExtremeSports",
        avatar: "/placeholder.svg?height=50&width=50",
        id: "extreme3",
      },
    },
  ],
}

export function ViralVideosExplorer({ onSelectVideo }: { onSelectVideo: (video: SocialVideo) => void }) {
  const [platform, setPlatform] = useState<"tiktok" | "instagram" | "facebook">("tiktok")
  const [minViews, setMinViews] = useState(1000000)
  const [videos, setVideos] = useState<SocialVideo[]>(MOCK_VIDEOS.tiktok)
  const [loading, setLoading] = useState(false)

  // Función para cargar videos (siempre usará los datos mock para garantizar que funcione)
  const fetchViralVideos = () => {
    setLoading(true)

    // Simulamos una carga para dar sensación de que está haciendo algo
    setTimeout(() => {
      // Filtramos los videos mock según el criterio de vistas mínimas
      const filteredVideos = MOCK_VIDEOS[platform].filter((video) => video.views >= minViews)
      setVideos(filteredVideos)
      setLoading(false)
    }, 800)
  }

  // Cargar videos cuando cambia la plataforma
  useEffect(() => {
    fetchViralVideos()
  }, [platform])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    fetchViralVideos()
  }

  return (
    <div className="space-y-6">
      <Card className="border-blue-100 dark:border-blue-900">
        <CardContent className="pt-6">
          <form onSubmit={handleSearch} className="space-y-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <Select
                  value={platform}
                  onValueChange={(value: "tiktok" | "instagram" | "facebook") => setPlatform(value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona plataforma" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="tiktok">TikTok</SelectItem>
                    <SelectItem value="instagram">Instagram</SelectItem>
                    <SelectItem value="facebook">Facebook</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex-1">
                <Select value={minViews.toString()} onValueChange={(value) => setMinViews(Number.parseInt(value))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Mínimo de vistas" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1000000">1 millón+</SelectItem>
                    <SelectItem value="5000000">5 millones+</SelectItem>
                    <SelectItem value="10000000">10 millones+</SelectItem>
                    <SelectItem value="50000000">50 millones+</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                <Search className="mr-2 h-4 w-4" />
                Buscar
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {loading ? (
        <div className="text-center py-8">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-blue-600 border-r-transparent"></div>
          <p className="mt-2">Cargando videos virales...</p>
        </div>
      ) : videos.length === 0 ? (
        <div className="text-center py-8">
          <p className="text-muted-foreground">No se encontraron videos virales con los criterios seleccionados.</p>
          <Button onClick={fetchViralVideos} variant="outline" className="mt-2">
            Reintentar
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {videos.map((video) => (
            <VideoCard key={video.id} video={video} onGenerate={() => onSelectVideo(video)} />
          ))}
        </div>
      )}
    </div>
  )
}

interface VideoCardProps {
  video: SocialVideo
  onGenerate: () => void
}

function VideoCard({ video, onGenerate }: VideoCardProps) {
  return (
    <Card className="overflow-hidden">
      <div className="relative aspect-video">
        <img src={video.thumbnail || "/placeholder.svg"} alt={video.title} className="object-cover w-full h-full" />
        <div className="absolute inset-0 bg-black/30 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
          <Button variant="secondary" size="icon" className="rounded-full">
            <Play className="h-5 w-5" />
          </Button>
        </div>
        <div className="absolute top-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded-full">
          {new Intl.NumberFormat("es-ES", { notation: "compact", compactDisplay: "short" }).format(video.views)} vistas
        </div>
        <div className="absolute top-2 left-2 bg-black/70 text-white text-xs px-2 py-1 rounded-full">
          {video.platform}
        </div>
      </div>
      <CardContent className="p-4">
        <div className="flex items-center gap-2 mb-2">
          <div className="w-6 h-6 rounded-full overflow-hidden">
            <img
              src={video.author.avatar || "/placeholder.svg"}
              alt={video.author.name}
              className="w-full h-full object-cover"
            />
          </div>
          <span className="text-sm font-medium">{video.author.name}</span>
        </div>
        <h3 className="font-medium truncate">{video.title}</h3>
        <p className="text-sm text-muted-foreground mb-3">{video.date}</p>
        <div className="flex space-x-2">
          <Button variant="outline" size="sm" className="flex-1">
            <Play className="h-4 w-4 mr-1" />
            Ver
          </Button>
          <Button onClick={onGenerate} size="sm" className="flex-1 bg-blue-600 hover:bg-blue-700">
            <Edit className="h-4 w-4 mr-1" />
            Generar
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
