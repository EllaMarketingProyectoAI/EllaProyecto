// Interfaces para los datos de videos
export interface SocialVideo {
  id: string
  platform: "tiktok" | "instagram" | "facebook"
  url: string
  thumbnail: string
  title: string
  views: number
  likes: number
  date: string
  author: {
    name: string
    avatar: string
    id: string
  }
}

// Clase base para APIs sociales
export abstract class SocialApiService {
  abstract authenticate(): Promise<boolean>
  abstract getViralVideos(minViews?: number): Promise<SocialVideo[]>
  abstract getVideoDetails(videoId: string): Promise<SocialVideo>
}

// Implementación para TikTok
export class TikTokApiService implements SocialApiService {
  private apiKey: string
  private isAuthenticated = false

  constructor(apiKey: string) {
    this.apiKey = apiKey
  }

  async authenticate(): Promise<boolean> {
    try {
      // Simulación de autenticación con TikTok API
      // En una implementación real, usaríamos OAuth
      this.isAuthenticated = true
      return true
    } catch (error) {
      console.error("Error authenticating with TikTok:", error)
      return false
    }
  }

  async getViralVideos(minViews = 1000000): Promise<SocialVideo[]> {
    if (!this.isAuthenticated) {
      await this.authenticate()
    }

    try {
      // En una implementación real, haríamos una llamada a la API de TikTok
      // Aquí simulamos la respuesta
      const response = await fetch("/api/mock/tiktok/viral-videos")
      const data = await response.json()
      return data.videos.filter((video: any) => video.views >= minViews)
    } catch (error) {
      console.error("Error fetching viral videos from TikTok:", error)
      return []
    }
  }

  async getVideoDetails(videoId: string): Promise<SocialVideo> {
    if (!this.isAuthenticated) {
      await this.authenticate()
    }

    try {
      // En una implementación real, haríamos una llamada a la API de TikTok
      const response = await fetch(`/api/mock/tiktok/video/${videoId}`)
      return await response.json()
    } catch (error) {
      console.error("Error fetching video details from TikTok:", error)
      throw new Error("Failed to fetch video details")
    }
  }
}

// Implementaciones similares para Instagram y Facebook
export class InstagramApiService implements SocialApiService {
  // Implementación similar a TikTok
  private apiKey: string
  private isAuthenticated = false

  constructor(apiKey: string) {
    this.apiKey = apiKey
  }

  async authenticate(): Promise<boolean> {
    // Simulación de autenticación con Instagram API
    this.isAuthenticated = true
    return true
  }

  async getViralVideos(minViews = 1000000): Promise<SocialVideo[]> {
    if (!this.isAuthenticated) {
      await this.authenticate()
    }

    // Simulación de obtención de videos virales
    const response = await fetch("/api/mock/instagram/viral-videos")
    const data = await response.json()
    return data.videos.filter((video: any) => video.views >= minViews)
  }

  async getVideoDetails(videoId: string): Promise<SocialVideo> {
    if (!this.isAuthenticated) {
      await this.authenticate()
    }

    const response = await fetch(`/api/mock/instagram/video/${videoId}`)
    return await response.json()
  }
}

export class FacebookApiService implements SocialApiService {
  // Implementación similar a TikTok
  private apiKey: string
  private isAuthenticated = false

  constructor(apiKey: string) {
    this.apiKey = apiKey
  }

  async authenticate(): Promise<boolean> {
    // Simulación de autenticación con Facebook API
    this.isAuthenticated = true
    return true
  }

  async getViralVideos(minViews = 1000000): Promise<SocialVideo[]> {
    if (!this.isAuthenticated) {
      await this.authenticate()
    }

    // Simulación de obtención de videos virales
    const response = await fetch("/api/mock/facebook/viral-videos")
    const data = await response.json()
    return data.videos.filter((video: any) => video.views >= minViews)
  }

  async getVideoDetails(videoId: string): Promise<SocialVideo> {
    if (!this.isAuthenticated) {
      await this.authenticate()
    }

    const response = await fetch(`/api/mock/facebook/video/${videoId}`)
    return await response.json()
  }
}

// Factory para crear instancias de servicios de API
export class SocialApiFactory {
  static createService(platform: "tiktok" | "instagram" | "facebook", apiKey = "mock-api-key"): SocialApiService {
    switch (platform) {
      case "tiktok":
        return new TikTokApiService(apiKey)
      case "instagram":
        return new InstagramApiService(apiKey)
      case "facebook":
        return new FacebookApiService(apiKey)
      default:
        throw new Error(`Unsupported platform: ${platform}`)
    }
  }
}
