import { getSupabaseClient } from "@/lib/supabase/client"
import { v4 as uuidv4 } from "uuid"

// Tipo para el usuario
export type User = {
  id: string
  username: string
  email: string | null
  avatarUrl: string | null
  isVerified: boolean
}

// Tipo para las credenciales de usuario
export type UserCredentials = {
  username: string
  password: string
  email?: string
}

// Clase para el servicio de autenticación
export class AuthService {
  // Método para iniciar sesión
  static async login(credentials: UserCredentials): Promise<User> {
    try {
      console.log(`Intentando iniciar sesión con usuario: ${credentials.username}`)
      const supabase = getSupabaseClient()

      // Buscar el usuario por nombre de usuario
      const { data, error } = await supabase
        .from("users")
        .select("*")
        .eq("username", credentials.username)
        .maybeSingle()

      if (error) {
        console.error("Error al buscar usuario:", error)
        throw new Error(`Error al buscar usuario: ${error.message}`)
      }

      // Verificar si se encontró el usuario
      if (!data) {
        console.error("Usuario no encontrado:", credentials.username)
        throw new Error("Usuario no encontrado o contraseña incorrecta")
      }

      // Verificar la contraseña
      if (data.password !== credentials.password) {
        console.error("Contraseña incorrecta para el usuario:", credentials.username)
        throw new Error("Usuario no encontrado o contraseña incorrecta")
      }

      console.log("Inicio de sesión exitoso para el usuario:", credentials.username)

      // Devolver el usuario
      return {
        id: data.id,
        username: data.username,
        email: data.email,
        avatarUrl: data.avatar_url,
        isVerified: true, // Asumimos que todos los usuarios están verificados
      }
    } catch (error: any) {
      console.error("Error en login:", error)
      throw new Error(`Error en login: ${error.message}`)
    }
  }

  // Método para registrar un nuevo usuario
  static async register(credentials: UserCredentials): Promise<User> {
    try {
      console.log(`Intentando registrar usuario: ${credentials.username}`)
      const supabase = getSupabaseClient()

      // Verificar si el usuario ya existe
      const { data: existingUser } = await supabase
        .from("users")
        .select("*")
        .eq("username", credentials.username)
        .maybeSingle()

      if (existingUser) {
        console.error("El usuario ya existe:", credentials.username)
        throw new Error("El nombre de usuario ya está en uso")
      }

      // Crear el nuevo usuario
      const userId = uuidv4()
      const { error } = await supabase.from("users").insert({
        id: userId,
        username: credentials.username,
        password: credentials.password,
        email: credentials.email,
        created_at: new Date().toISOString(),
      })

      if (error) {
        console.error("Error al registrar usuario:", error)
        throw new Error(`Error al registrar usuario: ${error.message}`)
      }

      console.log("Usuario registrado exitosamente:", credentials.username)

      // Devolver el usuario recién creado
      return {
        id: userId,
        username: credentials.username,
        email: credentials.email || null,
        avatarUrl: null,
        isVerified: true, // Asumimos que todos los usuarios están verificados
      }
    } catch (error: any) {
      console.error("Error en registro:", error)
      throw new Error(`Error al registrar usuario: ${error.message}`)
    }
  }

  // Método para obtener un usuario por ID
  static async getUserById(userId: string): Promise<User | null> {
    try {
      console.log(`Buscando usuario con ID: ${userId}`)
      const supabase = getSupabaseClient()

      const { data, error } = await supabase.from("users").select("*").eq("id", userId).maybeSingle()

      if (error) {
        console.error("Error al buscar usuario por ID:", error)
        throw new Error(`Error al buscar usuario: ${error.message}`)
      }

      if (!data) {
        console.log("No se encontró usuario con ID:", userId)
        return null
      }

      console.log("Usuario encontrado:", data.username)

      // Devolver el usuario
      return {
        id: data.id,
        username: data.username,
        email: data.email,
        avatarUrl: data.avatar_url,
        isVerified: true, // Asumimos que todos los usuarios están verificados
      }
    } catch (error: any) {
      console.error("Error al obtener usuario por ID:", error)
      throw new Error(`Error al obtener usuario: ${error.message}`)
    }
  }
}
