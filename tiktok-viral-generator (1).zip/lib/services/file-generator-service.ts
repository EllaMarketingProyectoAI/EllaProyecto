import { v4 as uuidv4 } from "uuid"

// Interfaz para el archivo generado
export interface GeneratedFile {
  id: string
  fileName: string
  fileSize: number
  fileType: string
  fileUrl: string
  content: Uint8Array
}

// Función para generar un archivo de texto simulado como si fuera un video
export const generateTextAsVideoFile = async (
  title: string,
  metadata: Record<string, any>,
  type: "general" | "client",
): Promise<GeneratedFile> => {
  // Generar un ID único para el archivo
  const fileId = uuidv4()

  // Crear un nombre de archivo basado en el título
  const fileName = `${title.replace(/\s+/g, "_")}_${fileId.substring(0, 8)}.mp4`

  // Crear contenido de texto que simula metadatos de video
  const textContent = `
=== VIDEO SIMULADO ===
ID: ${fileId}
Título: ${title}
Tipo: ${type}
Fecha de creación: ${new Date().toISOString()}

=== METADATOS ===
${Object.entries(metadata)
  .map(([key, value]) => {
    // Formatear arrays y objetos para mejor legibilidad
    if (Array.isArray(value)) {
      return `${key}: ${value.join(", ")}`
    } else if (typeof value === "object" && value !== null) {
      return `${key}: ${JSON.stringify(value, null, 2)}`
    } else {
      return `${key}: ${value}`
    }
  })
  .join("\n")}

=== INFORMACIÓN TÉCNICA ===
Resolución: 1920x1080
Formato: MP4
Codec: H.264
Bitrate: 8 Mbps
FPS: 30

Este es un archivo de video simulado generado para propósitos de demostración.
En una implementación real, aquí estaría el contenido binario del video.
`.trim()

  // Convertir el texto a un Uint8Array (simulando datos binarios)
  const encoder = new TextEncoder()
  const content = encoder.encode(textContent)

  // Calcular el tamaño del archivo en bytes
  const fileSize = content.byteLength

  // URL simulada para el archivo
  const fileUrl = `/api/videos/${fileId}/download`

  return {
    id: fileId,
    fileName,
    fileSize,
    fileType: "video/mp4",
    fileUrl,
    content,
  }
}

// Función para generar un video general
export const generateGeneralVideoFile = async (options: Record<string, any>): Promise<GeneratedFile> => {
  return generateTextAsVideoFile(
    options.title || "Video general",
    {
      ...options,
      generatedAt: new Date().toISOString(),
    },
    "general",
  )
}

// Función para generar un video de cliente
export const generateClientVideoFile = async (title: string, options: Record<string, any>): Promise<GeneratedFile> => {
  return generateTextAsVideoFile(
    title,
    {
      ...options,
      generatedAt: new Date().toISOString(),
    },
    "client",
  )
}
