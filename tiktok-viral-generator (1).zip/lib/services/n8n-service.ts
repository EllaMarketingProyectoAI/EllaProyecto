import { v4 as uuidv4 } from "uuid"

export interface N8nWebhookPayload {
  userId: string
  videoType: "general" | "ai" | "client"
  options: Record<string, any>
  callbackUrl?: string
}

export class N8nService {
  // Store webhook requests for tracking
  private static webhookRequests: Record<
    string,
    {
      id: string
      status: "pending" | "processing" | "completed" | "failed"
      payload: N8nWebhookPayload
      result?: any
      error?: string
      createdAt: Date
    }
  > = {}

  // Register a new webhook request
  static registerWebhookRequest(payload: N8nWebhookPayload): string {
    const requestId = uuidv4()

    this.webhookRequests[requestId] = {
      id: requestId,
      status: "pending",
      payload,
      createdAt: new Date(),
    }

    return requestId
  }

  // Update webhook request status
  static updateWebhookStatus(
    requestId: string,
    status: "pending" | "processing" | "completed" | "failed",
    result?: any,
    error?: string,
  ): boolean {
    if (!this.webhookRequests[requestId]) {
      return false
    }

    this.webhookRequests[requestId] = {
      ...this.webhookRequests[requestId],
      status,
      result,
      error,
    }

    // If there's a callback URL, send the result back to n8n
    const callbackUrl = this.webhookRequests[requestId].payload.callbackUrl
    if (callbackUrl && (status === "completed" || status === "failed")) {
      this.sendCallback(callbackUrl, {
        requestId,
        status,
        result,
        error,
      }).catch((err) => console.error("Failed to send callback:", err))
    }

    return true
  }

  // Get webhook request status
  static getWebhookStatus(requestId: string) {
    return this.webhookRequests[requestId] || null
  }

  // Send callback to n8n
  private static async sendCallback(url: string, data: any): Promise<void> {
    try {
      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })

      if (!response.ok) {
        throw new Error(`Failed to send callback: ${response.status} ${response.statusText}`)
      }
    } catch (error) {
      console.error("Error sending callback:", error)
      throw error
    }
  }

  // Clean up old webhook requests (older than 24 hours)
  static cleanupOldRequests(): void {
    const now = new Date()
    const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000)

    Object.keys(this.webhookRequests).forEach((requestId) => {
      if (this.webhookRequests[requestId].createdAt < oneDayAgo) {
        delete this.webhookRequests[requestId]
      }
    })
  }
}
