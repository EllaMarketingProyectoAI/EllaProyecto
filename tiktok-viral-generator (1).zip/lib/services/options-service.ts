// Servicio para obtener opciones de APIs externas
import { getSupabaseClient } from "@/lib/supabase/client"

// Interfaces para las opciones
export interface TypographyOption {
  id: string
  name: string
  value: string
  preview_url?: string
}

export interface MusicOption {
  id: string
  name: string
  value: string
  genre?: string
  duration?: string
  preview_url?: string
}

export interface BRollOption {
  id: string
  name: string
  value: string
  category?: string
  preview_url?: string
}

export interface SoundEffectOption {
  id: string
  name: string
  value: string
  category?: string
  preview_url?: string
}

// Opciones de tipografía
export const getTypographyOptions = async () => {
  return [
    { id: 1, name: "Sans Serif", value: "sans-serif" },
    { id: 2, name: "Serif", value: "serif" },
    { id: 3, name: "Monospace", value: "monospace" },
    { id: 4, name: "Cursive", value: "cursive" },
    { id: 5, name: "Fantasy", value: "fantasy" },
    { id: 6, name: "Moderna", value: "moderna" },
    { id: 7, name: "Clásica", value: "clasica" },
    { id: 8, name: "Futurista", value: "futurista" },
    { id: 9, name: "Retro", value: "retro" },
    { id: 10, name: "Minimalista", value: "minimalista" },
  ]
}

// Opciones de música
export const getMusicOptions = async () => {
  return [
    { id: 1, name: "Electrónica", value: "electronica" },
    { id: 2, name: "Pop", value: "pop" },
    { id: 3, name: "Rock", value: "rock" },
    { id: 4, name: "Hip Hop", value: "hip-hop" },
    { id: 5, name: "Jazz", value: "jazz" },
    { id: 6, name: "Clásica", value: "clasica" },
    { id: 7, name: "Ambiental", value: "ambiental" },
    { id: 8, name: "Épica", value: "epica" },
    { id: 9, name: "Acústica", value: "acustica" },
    { id: 10, name: "Sin música", value: "ninguna" },
  ]
}

// Opciones de B-Roll
export const getBRollOptions = async () => {
  return [
    { id: 1, name: "Stock Videos", value: "stock-videos" },
    { id: 2, name: "Stock Photos", value: "stock-photos" },
    { id: 3, name: "AI Generated", value: "ai-generated" },
    { id: 4, name: "Custom Footage", value: "custom-footage" },
    { id: 5, name: "Screen Recordings", value: "screen-recordings" },
    { id: 6, name: "Animations", value: "animations" },
    { id: 7, name: "Infographics", value: "infographics" },
    { id: 8, name: "Product Demos", value: "product-demos" },
    { id: 9, name: "User Testimonials", value: "user-testimonials" },
    { id: 10, name: "Behind the Scenes", value: "behind-the-scenes" },
  ]
}

// Opciones de efectos de sonido
export const getSoundEffectOptions = async () => {
  return [
    { id: 1, name: "Transiciones", value: "transiciones" },
    { id: 2, name: "Notificaciones", value: "notificaciones" },
    { id: 3, name: "Ambiente", value: "ambiente" },
    { id: 4, name: "Naturaleza", value: "naturaleza" },
    { id: 5, name: "Tecnología", value: "tecnologia" },
    { id: 6, name: "Humor", value: "humor" },
    { id: 7, name: "Deportes", value: "deportes" },
    { id: 8, name: "Música", value: "musica" },
    { id: 9, name: "Voces", value: "voces" },
    { id: 10, name: "Sin efectos", value: "ninguno" },
  ]
}

// Función para guardar las opciones seleccionadas en Supabase
export async function saveVideoOptions(videoId: string, options: Record<string, any>, type: "general" | "client") {
  try {
    const supabase = getSupabaseClient()

    if (type === "general") {
      const { error } = await supabase.from("video_general_options").update(options).eq("video_id", videoId)

      if (error) throw error
    } else {
      const { error } = await supabase.from("video_client_options").update(options).eq("video_id", videoId)

      if (error) throw error
    }

    return { success: true }
  } catch (error) {
    console.error("Error saving video options:", error)
    return { success: false, error }
  }
}
