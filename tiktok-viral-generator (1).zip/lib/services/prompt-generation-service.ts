export class PromptGenerationService {
  /**
   * Genera un prompt basado en el tipo de video y las opciones proporcionadas
   */
  static generatePrompt(
    videoType: "general" | "client" | "ai",
    options: any,
    additionalContext?: { videoTitle?: string },
  ): { prompt: string; metadata: any } {
    console.log(`Generando prompt para video tipo: ${videoType}`)

    const prompt = ""
    const metadata = {}

    switch (videoType) {
      case "general":
        return this.generateGeneralVideoPrompt(options, additionalContext)
      case "client":
        return this.generateClientVideoPrompt(options, additionalContext)
      case "ai":
        return this.generateAIVideoPrompt(options, additionalContext)
      default:
        throw new Error(`Tipo de video no soportado: ${videoType}`)
    }
  }

  /**
   * Genera un prompt para un video general
   */
  private static generateGeneralVideoPrompt(
    options: any,
    additionalContext?: { videoTitle?: string },
  ): { prompt: string; metadata: any } {
    console.log("Generando prompt para video general con opciones:", JSON.stringify(options))

    const {
      title,
      topic,
      hook,
      format,
      sources,
      restricted_words,
      duration,
      banned_topics,
      keywords,
      ai_voice_over,
      subtitles,
      b_roll,
      typography,
      music_source,
      b_roll_source,
      sound_effects_source,
    } = options

    // Construir el prompt
    let prompt = `Crea un guión para un video viral sobre "${title}" con las siguientes características:\n\n`

    // Información básica
    prompt += `TEMA: ${topic}\n`
    prompt += `FORMATO: ${format}\n`
    prompt += `HOOK: ${hook}\n`
    prompt += `DURACIÓN: ${duration}\n\n`

    // Elementos adicionales
    if (sources) prompt += `FUENTES: ${sources}\n`
    if (keywords) prompt += `KEYWORDS/HASHTAGS: ${keywords}\n`
    if (ai_voice_over === "yes") prompt += `VOZ EN OFF: Generada por IA\n`
    if (subtitles === "yes") prompt += `SUBTÍTULOS: Sí\n`
    if (b_roll) prompt += `B-ROLL: ${b_roll}\n`
    if (typography) prompt += `TIPOGRAFÍA: ${typography}\n`
    if (music_source) prompt += `MÚSICA: ${music_source}\n`
    if (sound_effects_source) prompt += `EFECTOS DE SONIDO: ${sound_effects_source}\n\n`

    // Restricciones
    if (restricted_words) prompt += `PALABRAS A EVITAR: ${restricted_words}\n`
    if (banned_topics) prompt += `TEMAS PROHIBIDOS: ${banned_topics}\n\n`

    // Estructura del guión
    prompt += `ESTRUCTURA DEL GUIÓN:\n`
    prompt += `1. Introducción con hook para captar la atención\n`
    prompt += `2. Presentación del tema principal\n`
    prompt += `3. Desarrollo de puntos clave\n`
    prompt += `4. Conclusión con llamado a la acción\n\n`

    // Instrucciones adicionales
    prompt += `INSTRUCCIONES ADICIONALES:\n`
    prompt += `- Mantén un ritmo dinámico y energético\n`
    prompt += `- Utiliza frases cortas y directas\n`
    prompt += `- Incluye momentos de impacto visual\n`
    prompt += `- Asegúrate de que el mensaje principal sea claro\n`
    prompt += `- Optimiza para retención de audiencia\n`

    // Metadata para seguimiento
    const metadata = {
      videoType: "general",
      title,
      topic,
      format,
      hook,
      duration,
      generatedAt: new Date().toISOString(),
    }

    return { prompt, metadata }
  }

  /**
   * Genera un prompt para un video de cliente
   */
  private static generateClientVideoPrompt(
    options: any,
    additionalContext?: { videoTitle?: string },
  ): { prompt: string; metadata: any } {
    console.log("Generando prompt para video de cliente con opciones:", JSON.stringify(options))

    const { hook, b_roll, subtitles, language } = options
    const title = additionalContext?.videoTitle || "Video de cliente"

    // Construir el prompt
    let prompt = `Mejora este video de cliente "${title}" con las siguientes características:\n\n`

    // Elementos principales
    prompt += `HOOK: ${hook}\n`
    if (b_roll) prompt += `B-ROLL: ${b_roll}\n`
    if (subtitles === "yes") prompt += `SUBTÍTULOS: Sí\n`
    if (language) prompt += `IDIOMA: ${language}\n\n`

    // Instrucciones para la mejora
    prompt += `INSTRUCCIONES PARA LA MEJORA:\n`
    prompt += `1. Añade un hook atractivo al inicio para captar la atención\n`
    prompt += `2. Mejora la narrativa visual con b-roll complementario\n`
    prompt += `3. Optimiza el ritmo y las transiciones\n`
    prompt += `4. Añade elementos gráficos que refuercen el mensaje\n\n`

    // Recomendaciones adicionales
    prompt += `RECOMENDACIONES ADICIONALES:\n`
    prompt += `- Mantén la autenticidad del contenido original\n`
    prompt += `- Asegúrate de que las mejoras complementen el mensaje principal\n`
    prompt += `- Optimiza para plataformas sociales\n`
    prompt += `- Considera añadir llamados a la acción sutiles\n`

    // Metadata para seguimiento
    const metadata = {
      videoType: "client",
      title,
      hook,
      b_roll,
      subtitles,
      language,
      generatedAt: new Date().toISOString(),
    }

    return { prompt, metadata }
  }

  /**
   * Genera un prompt para un video de IA
   */
  private static generateAIVideoPrompt(
    options: any,
    additionalContext?: { videoTitle?: string },
  ): { prompt: string; metadata: any } {
    console.log("Generando prompt para video de IA con opciones:", JSON.stringify(options))

    const { title, description, duration, style, aspectRatio } = options

    // Construir el prompt
    let prompt = `Genera un video utilizando IA con las siguientes especificaciones:\n\n`

    // Información básica
    prompt += `TÍTULO: ${title}\n`
    prompt += `DESCRIPCIÓN: ${description}\n`
    prompt += `DURACIÓN: ${duration}\n`
    prompt += `ESTILO: ${style}\n`
    prompt += `RELACIÓN DE ASPECTO: ${aspectRatio}\n\n`

    // Instrucciones para la generación
    prompt += `INSTRUCCIONES PARA LA GENERACIÓN:\n`
    prompt += `1. Crea una secuencia visual coherente basada en la descripción\n`
    prompt += `2. Utiliza el estilo especificado para toda la estética\n`
    prompt += `3. Mantén la relación de aspecto consistente\n`
    prompt += `4. Asegúrate de que la duración sea la especificada\n\n`

    // Recomendaciones adicionales
    prompt += `RECOMENDACIONES ADICIONALES:\n`
    prompt += `- Prioriza la calidad visual y la coherencia\n`
    prompt += `- Asegúrate de que las transiciones sean suaves\n`
    prompt += `- Considera añadir elementos de marca si es apropiado\n`
    prompt += `- Optimiza para captar la atención en los primeros segundos\n`

    // Metadata para seguimiento
    const metadata = {
      videoType: "ai",
      title,
      description,
      duration,
      style,
      aspectRatio,
      generatedAt: new Date().toISOString(),
    }

    return { prompt, metadata }
  }
}
