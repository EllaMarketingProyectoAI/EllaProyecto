import { getSupabaseClient } from "@/lib/supabase/client"
import { v4 as uuidv4 } from "uuid"

export interface PromptGenerationRequest {
  videoId: string
  userId: string
  inputContext: Record<string, any>
}

export interface PromptGenerationResult {
  id: string
  videoId: string
  userId: string
  promptText: string
  inputContext: Record<string, any>
  workflowId?: string
  executionId?: string
  createdAt: string
}

export class PromptService {
  /**
   * Genera un prompt utilizando n8n y lo almacena en la base de datos
   */
  static async generateAndStorePrompt(
    request: PromptGenerationRequest,
  ): Promise<{ success: boolean; promptId?: string; error?: string }> {
    try {
      console.log("Generando prompt para el video:", request.videoId)

      // Obtener el cliente de Supabase
      const supabase = getSupabaseClient()

      // Generar el prompt utilizando n8n
      const promptResult = await this.generatePromptWithN8n(request)

      if (!promptResult.success) {
        console.error("Error al generar prompt con n8n:", promptResult.error)
        // Intentar con el generador de prompts local como fallback
        console.log("Intentando generar prompt localmente como fallback...")
        const mockPrompt = this.generateMockPrompt(request)

        // Crear un ID único para el prompt
        const promptId = uuidv4()

        // Almacenar el prompt simulado en la base de datos
        const { error } = await supabase.from("video_prompts").insert({
          id: promptId,
          video_id: request.videoId,
          user_id: request.userId,
          prompt_text: mockPrompt.promptText,
          input_context: request.inputContext,
          workflow_id: mockPrompt.workflowId,
          execution_id: mockPrompt.executionId,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        })

        if (error) {
          console.error("Error al almacenar el prompt fallback:", error)
          return { success: false, error: error.message }
        }

        console.log("Prompt fallback generado y almacenado con éxito. ID:", promptId)
        return { success: true, promptId }
      }

      // Crear un ID único para el prompt
      const promptId = uuidv4()

      // Almacenar el prompt en la base de datos
      const { error } = await supabase.from("video_prompts").insert({
        id: promptId,
        video_id: request.videoId,
        user_id: request.userId,
        prompt_text: promptResult.promptText,
        input_context: request.inputContext,
        workflow_id: promptResult.workflowId,
        execution_id: promptResult.executionId,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })

      if (error) {
        console.error("Error al almacenar el prompt:", error)
        return { success: false, error: error.message }
      }

      console.log("Prompt generado y almacenado con éxito. ID:", promptId)

      return { success: true, promptId }
    } catch (error: any) {
      console.error("Error inesperado al generar y almacenar el prompt:", error)

      // Generar un prompt fallback en caso de error
      try {
        console.log("Generando prompt fallback debido a error inesperado...")
        const mockPrompt = this.generateMockPrompt(request)
        const promptId = uuidv4()

        const supabase = getSupabaseClient()
        const { error: dbError } = await supabase.from("video_prompts").insert({
          id: promptId,
          video_id: request.videoId,
          user_id: request.userId,
          prompt_text: mockPrompt.promptText,
          input_context: request.inputContext,
          workflow_id: mockPrompt.workflowId,
          execution_id: mockPrompt.executionId,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        })

        if (!dbError) {
          console.log("Prompt fallback generado con éxito tras error inesperado")
          return { success: true, promptId }
        }
      } catch (fallbackError) {
        console.error("Error al generar prompt fallback:", fallbackError)
      }

      return { success: false, error: error.message || "Error inesperado" }
    }
  }

  /**
   * Genera un prompt utilizando el flujo de trabajo de n8n
   */
  private static async generatePromptWithN8n(
    request: PromptGenerationRequest,
  ): Promise<{ success: boolean; promptText?: string; workflowId?: string; executionId?: string; error?: string }> {
    try {
      // Usar la API interna para evitar problemas de CORS
      const apiUrl = "/api/n8n/webhook"
      const apiKey = process.env.NEXT_PUBLIC_N8N_API_KEY || process.env.N8N_API_KEY

      if (!apiKey) {
        console.warn("Clave API de n8n no configurada, generando prompt simulado")
        return this.generateMockPrompt(request)
      }

      console.log("Usando API interna para n8n:", apiUrl)

      // Preparar los datos para enviar a n8n - Simplificado para reducir complejidad
      const { inputContext } = request
      const simplifiedPayload = {
        title: inputContext.title || "",
        topic: inputContext.topic || "",
        hook: inputContext.hook || "",
        format: inputContext.format || "",
        duration: inputContext.duration || "60s",
        keywords: inputContext.keywords || "",
        // Metadatos adicionales
        videoId: request.videoId || "",
        userId: request.userId || "",
        requestId: uuidv4(),
        timestamp: new Date().toISOString(),
      }

      console.log("Enviando solicitud a n8n con payload simplificado:", JSON.stringify(simplifiedPayload))

      try {
        // Llamar a nuestra API interna que se comunicará con n8n
        const response = await fetch(apiUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-api-key": apiKey,
          },
          body: JSON.stringify(simplifiedPayload),
        })

        if (!response.ok) {
          const errorText = await response.text()
          console.error(`Error en respuesta de n8n (${response.status}):`, errorText)
          return {
            success: false,
            error: `Error al llamar a n8n: ${response.status} - ${errorText}`,
          }
        }

        const result = await response.json()

        if (!result.success) {
          return {
            success: false,
            error: result.error || "Error desconocido en n8n",
          }
        }

        return {
          success: true,
          promptText: result.promptText || result.prompt || "Prompt no disponible",
          workflowId: result.workflowId || "n8n-workflow",
          executionId: result.executionId || result.id || simplifiedPayload.requestId,
        }
      } catch (fetchError: any) {
        console.error("Error de fetch al llamar a n8n:", fetchError)
        return {
          success: false,
          error: `Error de conexión con n8n: ${fetchError.message}`,
        }
      }
    } catch (error: any) {
      console.error("Error al generar prompt con n8n:", error)
      return { success: false, error: error.message || "Error inesperado" }
    }
  }

  /**
   * Genera un prompt simulado para desarrollo o cuando hay errores de conexión
   */
  private static generateMockPrompt(request: PromptGenerationRequest): {
    success: boolean
    promptText: string
    workflowId: string
    executionId: string
  } {
    const { inputContext } = request
    const mockExecutionId = uuidv4()

    // Extraer información relevante del contexto
    const title = inputContext.title || "Video sin título"
    const topic = inputContext.topic || "Tema no especificado"
    const format = inputContext.format || "Formato no especificado"
    const hook = inputContext.hook || "Hook no especificado"
    const duration = inputContext.duration || "60s"
    const keywords = inputContext.keywords || ""

    // Generar un prompt simulado basado en el contexto
    const promptText = `Crea un video viral sobre "${title}" que trate sobre ${topic}. 
Utiliza un formato de ${format} y comienza con un ${hook} para captar la atención del espectador.
Incluye elementos visuales atractivos, música de fondo energética y transiciones suaves.
Asegúrate de que el mensaje principal sea claro y que el video tenga un llamado a la acción al final.
Mantén un ritmo dinámico y asegúrate de que la duración sea óptima (${duration}) para mantener la atención del espectador.
${keywords ? `Incluye las siguientes palabras clave: ${keywords}` : ""}

Este prompt fue generado localmente como fallback debido a que no se pudo conectar con el servicio de n8n.`

    return {
      success: true,
      promptText,
      workflowId: "mock-workflow",
      executionId: mockExecutionId,
    }
  }

  /**
   * Obtiene un prompt específico por su ID
   */
  static async getPromptById(
    promptId: string,
  ): Promise<{ success: boolean; prompt?: PromptGenerationResult; error?: string }> {
    try {
      const supabase = getSupabaseClient()

      const { data, error } = await supabase.from("video_prompts").select("*").eq("id", promptId).single()

      if (error) {
        console.error("Error al obtener el prompt:", error)
        return { success: false, error: error.message }
      }

      if (!data) {
        return { success: false, error: "Prompt no encontrado" }
      }

      const prompt: PromptGenerationResult = {
        id: data.id,
        videoId: data.video_id,
        userId: data.user_id,
        promptText: data.prompt_text,
        inputContext: data.input_context,
        workflowId: data.workflow_id,
        executionId: data.execution_id,
        createdAt: data.created_at,
      }

      return { success: true, prompt }
    } catch (error: any) {
      console.error("Error inesperado al obtener el prompt:", error)
      return { success: false, error: error.message || "Error inesperado" }
    }
  }

  /**
   * Obtiene todos los prompts asociados a un video
   */
  static async getPromptsByVideoId(
    videoId: string,
  ): Promise<{ success: boolean; prompts?: PromptGenerationResult[]; error?: string }> {
    try {
      const supabase = getSupabaseClient()

      const { data, error } = await supabase
        .from("video_prompts")
        .select("*")
        .eq("video_id", videoId)
        .order("created_at", { ascending: false })

      if (error) {
        console.error("Error al obtener los prompts del video:", error)
        return { success: false, error: error.message }
      }

      const prompts: PromptGenerationResult[] = data.map((item) => ({
        id: item.id,
        videoId: item.video_id,
        userId: item.user_id,
        promptText: item.prompt_text,
        inputContext: item.input_context,
        workflowId: item.workflow_id,
        executionId: item.execution_id,
        createdAt: item.created_at,
      }))

      return { success: true, prompts }
    } catch (error: any) {
      console.error("Error inesperado al obtener los prompts del video:", error)
      return { success: false, error: error.message || "Error inesperado" }
    }
  }

  /**
   * Obtiene todos los prompts asociados a un usuario
   */
  static async getPromptsByUserId(
    userId: string,
  ): Promise<{ success: boolean; prompts?: PromptGenerationResult[]; error?: string }> {
    try {
      const supabase = getSupabaseClient()

      const { data, error } = await supabase
        .from("video_prompts")
        .select("*")
        .eq("user_id", userId)
        .order("created_at", { ascending: false })

      if (error) {
        console.error("Error al obtener los prompts del usuario:", error)
        return { success: false, error: error.message }
      }

      const prompts: PromptGenerationResult[] = data.map((item) => ({
        id: item.id,
        videoId: item.video_id,
        userId: item.user_id,
        promptText: item.prompt_text,
        inputContext: item.input_context,
        workflowId: item.workflow_id,
        executionId: item.execution_id,
        createdAt: item.created_at,
      }))

      return { success: true, prompts }
    } catch (error: any) {
      console.error("Error inesperado al obtener los prompts del usuario:", error)
      return { success: false, error: error.message || "Error inesperado" }
    }
  }
}
