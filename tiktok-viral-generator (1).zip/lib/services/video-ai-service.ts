// Este servicio actuará como un wrapper para futuras integraciones con APIs de generación de video como Sora
import { v4 as uuidv4 } from "uuid"

export interface VideoGenerationPrompt {
  prompt: string
  duration?: string
  style?: string
  aspectRatio?: "16:9" | "9:16" | "1:1"
  additionalContext?: string
}

export interface GeneratedVideoResult {
  id: string
  status: "processing" | "completed" | "failed"
  url?: string
  thumbnailUrl?: string
  prompt: string
  createdAt: string
}

export class VideoAIService {
  // Método para generar un video basado en un prompt
  static async generateVideo(prompt: VideoGenerationPrompt): Promise<GeneratedVideoResult> {
    console.log("Generando video con IA usando prompt:", prompt)

    // Actualmente simulamos la generación
    // Cuando Sora API esté disponible, aquí iría la llamada real a la API

    // Simulamos un tiempo de procesamiento
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Creamos un resultado simulado
    const videoId = uuidv4()

    return {
      id: videoId,
      status: "completed",
      url: `/api/ai-videos/${videoId}/download`,
      thumbnailUrl: `/placeholder.svg?height=720&width=1280&text=${encodeURIComponent("AI Generated Video")}`,
      prompt: prompt.prompt,
      createdAt: new Date().toISOString(),
    }
  }

  // Método para verificar el estado de un video en generación
  static async checkVideoStatus(videoId: string): Promise<GeneratedVideoResult> {
    console.log("Verificando estado del video:", videoId)

    // Simulamos una respuesta
    return {
      id: videoId,
      status: "processing",
      prompt: "Video prompt...",
      createdAt: new Date().toISOString(),
    }
  }

  // Método para convertir las opciones de nuestro formulario a un prompt para Sora
  static createPromptFromOptions(options: any): VideoGenerationPrompt {
    // Construimos un prompt detallado basado en las opciones del usuario
    let promptText = ""

    if (options.title) {
      promptText += `Create a video titled "${options.title}". `
    }

    if (options.topic) {
      promptText += `The main topic is about ${options.topic}. `
    }

    if (options.hook) {
      promptText += `Start with a ${options.hook} style hook to capture attention. `
    }

    if (options.format) {
      promptText += `The video should follow a ${options.format} format. `
    }

    if (options.b_roll) {
      promptText += `Include ${options.b_roll} style b-roll footage. `
    }

    if (options.subtitles === "yes") {
      promptText += "Include clear subtitles throughout the video. "
    }

    // Añadimos contexto adicional
    let additionalContext = ""

    if (options.restricted_words) {
      additionalContext += `Avoid using these words: ${options.restricted_words}. `
    }

    if (options.banned_topics) {
      additionalContext += `Do not include content about: ${options.banned_topics}. `
    }

    if (options.keywords) {
      additionalContext += `Try to include these keywords: ${options.keywords}. `
    }

    // Determinamos la duración
    let duration = "30 seconds"
    if (options.duration) {
      switch (options.duration) {
        case "15s":
          duration = "15 seconds"
          break
        case "30s":
          duration = "30 seconds"
          break
        case "60s":
          duration = "60 seconds"
          break
        case "3min":
          duration = "3 minutes"
          break
        case "5min":
          duration = "5 minutes"
          break
        case "10min":
          duration = "10 minutes"
          break
      }
    }

    return {
      prompt: promptText,
      duration: duration,
      style: options.format || "modern",
      aspectRatio: "9:16", // Vertical para redes sociales
      additionalContext: additionalContext,
    }
  }
}
