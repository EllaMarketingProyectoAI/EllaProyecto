import { v4 as uuidv4 } from "uuid"

// Interfaces para los diferentes tipos de opciones
export interface GeneralVideoOptions {
  title: string
  topic: string
  hook: string
  format: string
  sources: string
  restricted_words?: string
  duration: string
  banned_topics?: string
  keywords?: string
  ai_voice_over: string
  subtitles: string
  b_roll: string
  typography?: string
  music_source?: string
  b_roll_source?: string[] | string
  sound_effects_source?: string
}

export interface ClientVideoOptions {
  hook: string
  b_roll: string
  subtitles: string
  language: string
}

// Interfaz para el video generado
export interface GeneratedVideo {
  id: string
  title: string
  url: string
  fileUrl: string
  thumbnailUrl: string
  fileName: string
  fileSize: number
  fileType: string
  duration: string
  resolution: string
  format: string
  createdAt: string
}

// Función para generar un video general
export async function generateGeneralVideo(options: GeneralVideoOptions): Promise<GeneratedVideo> {
  console.log("Generando video general con opciones:", options)

  // Simulamos un tiempo de procesamiento
  await new Promise((resolve) => setTimeout(resolve, 2000))

  // Generamos un ID único para el video
  const videoId = uuidv4()

  // Generamos una duración basada en la opción seleccionada
  let durationInSeconds = 60 // Valor predeterminado: 1 minuto

  switch (options.duration) {
    case "15s":
      durationInSeconds = 15
      break
    case "30s":
      durationInSeconds = 30
      break
    case "60s":
      durationInSeconds = 60
      break
    case "3min":
      durationInSeconds = 180
      break
    case "5min":
      durationInSeconds = 300
      break
    case "10min":
      durationInSeconds = 600
      break
  }

  // Formateamos la duración como MM:SS
  const minutes = Math.floor(durationInSeconds / 60)
  const seconds = durationInSeconds % 60
  const formattedDuration = `${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`

  // Calculamos un tamaño de archivo basado en la duración (aproximadamente 1MB por 10 segundos)
  const fileSize = Math.round(durationInSeconds * 100000) // ~1MB por 10 segundos

  // Generamos una URL para la miniatura basada en el título
  const thumbnailUrl = `/placeholder.svg?height=720&width=1280&text=${encodeURIComponent(options.title)}`

  // Creamos un nombre de archivo basado en el título
  const fileName = `${options.title.replace(/\s+/g, "_").toLowerCase()}_${videoId.substring(0, 8)}.mp4`

  // Creamos el objeto de video generado
  const generatedVideo: GeneratedVideo = {
    id: videoId,
    title: options.title,
    url: `/api/videos/${videoId}`,
    fileUrl: `/api/videos/${videoId}/download`,
    thumbnailUrl,
    fileName,
    fileSize,
    fileType: "video/mp4",
    duration: formattedDuration,
    resolution: "1080p",
    format: "MP4",
    createdAt: new Date().toISOString(),
  }

  console.log("Video general generado:", generatedVideo)

  return generatedVideo
}

// Función para generar un video de cliente
export async function generateClientVideo(title: string, options: ClientVideoOptions): Promise<GeneratedVideo> {
  console.log("Generando video de cliente con opciones:", options)

  // Simulamos un tiempo de procesamiento
  await new Promise((resolve) => setTimeout(resolve, 2000))

  // Generamos un ID único para el video
  const videoId = uuidv4()

  // Para videos de cliente, generamos una duración aleatoria entre 30 segundos y 3 minutos
  const durationInSeconds = Math.floor(Math.random() * (180 - 30 + 1)) + 30

  // Formateamos la duración como MM:SS
  const minutes = Math.floor(durationInSeconds / 60)
  const seconds = durationInSeconds % 60
  const formattedDuration = `${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`

  // Calculamos un tamaño de archivo basado en la duración (aproximadamente 1MB por 10 segundos)
  const fileSize = Math.round(durationInSeconds * 100000) // ~1MB por 10 segundos

  // Generamos una URL para la miniatura basada en el título
  const thumbnailUrl = `/placeholder.svg?height=720&width=1280&text=${encodeURIComponent(title)}`

  // Creamos un nombre de archivo basado en el título
  const fileName = `${title.replace(/\s+/g, "_").toLowerCase()}_${videoId.substring(0, 8)}.mp4`

  // Creamos el objeto de video generado
  const generatedVideo: GeneratedVideo = {
    id: videoId,
    title,
    url: `/api/videos/${videoId}`,
    fileUrl: `/api/videos/${videoId}/download`,
    thumbnailUrl,
    fileName,
    fileSize,
    fileType: "video/mp4",
    duration: formattedDuration,
    resolution: "1080p",
    format: "MP4",
    createdAt: new Date().toISOString(),
  }

  console.log("Video de cliente generado:", generatedVideo)

  return generatedVideo
}
