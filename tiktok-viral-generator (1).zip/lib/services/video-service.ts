import { getSupabaseClient } from "@/lib/supabase/client"
import { v4 as uuidv4 } from "uuid"
import { PromptService } from "./prompt-service"

// Función para generar una URL de miniatura basada en el título del video
export function generateThumbnailUrl(title: string) {
  return `/placeholder.svg?height=200&width=320&text=${encodeURIComponent(title || "Video")}`
}

// Función para obtener todos los videos de un usuario
export async function getUserVideos(userId: string) {
  try {
    console.log("Obteniendo videos para el usuario:", userId)

    const supabase = getSupabaseClient()

    // Obtener videos de la base de datos
    const { data: videos, error } = await supabase
      .from("videos")
      .select("*")
      .eq("user_id", userId)
      .order("id", { ascending: false })

    if (error) {
      console.error("Error al obtener videos:", error)
      return { success: false, error: error.message, videos: [] }
    }

    // Generar URLs de miniaturas para los videos
    const videosWithThumbnails = videos.map((video) => ({
      ...video,
      thumbnail_url: generateThumbnailUrl(video.title),
    }))

    console.log(`Se encontraron ${videosWithThumbnails.length} videos`)

    return { success: true, videos: videosWithThumbnails }
  } catch (error) {
    console.error("Error inesperado al obtener videos:", error)
    return { success: false, error: "Error inesperado al obtener videos", videos: [] }
  }
}

// Función para obtener un video específico con sus opciones
export async function getVideoWithOptions(videoId: string) {
  try {
    console.log("Obteniendo video con opciones. ID:", videoId)

    const supabase = getSupabaseClient()

    // Obtener el video
    const { data: video, error: videoError } = await supabase.from("videos").select("*").eq("id", videoId).single()

    if (videoError) {
      console.error("Error al obtener el video:", videoError)
      return { success: false, error: videoError.message }
    }

    if (!video) {
      console.error("Video no encontrado")
      return { success: false, error: "Video no encontrado" }
    }

    console.log("Video encontrado:", video)

    // Obtener las opciones según el tipo de video
    let options = null

    if (video.type === "general") {
      const { data: generalOptions, error: generalError } = await supabase
        .from("video_general_options")
        .select("*")
        .eq("video_id", videoId)
        .single()

      if (generalError) {
        console.error("Error al obtener opciones generales:", generalError)
        if (generalError.code !== "PGRST116") {
          // No es un error de "no se encontraron resultados"
          return { success: false, error: generalError.message }
        }
      }

      options = generalOptions
      console.log("Opciones generales encontradas:", options)
    } else if (video.type === "client") {
      const { data: clientOptions, error: clientError } = await supabase
        .from("video_client_options")
        .select("*")
        .eq("video_id", videoId)
        .single()

      if (clientError) {
        console.error("Error al obtener opciones de cliente:", clientError)
        if (clientError.code !== "PGRST116") {
          // No es un error de "no se encontraron resultados"
          return { success: false, error: clientError.message }
        }
      }

      options = clientOptions
      console.log("Opciones de cliente encontradas:", options)
    }

    // Obtener archivos asociados al video
    const { data: files, error: filesError } = await supabase
      .from("files")
      .select("*")
      .eq("video_id", videoId)
      .order("id", { ascending: false })

    if (filesError) {
      console.error("Error al obtener archivos:", filesError)
      // No fallamos aquí, continuamos con el proceso
    }

    // Obtener prompts asociados al video
    const promptsResult = await PromptService.getPromptsByVideoId(videoId)
    const prompts = promptsResult.success ? promptsResult.prompts : []

    console.log("Archivos encontrados:", files || [])
    console.log("Prompts encontrados:", prompts || [])

    // Generar URL de miniatura para el video
    const videoWithThumbnail = {
      ...video,
      thumbnail_url: generateThumbnailUrl(video.title),
    }

    return {
      success: true,
      video: videoWithThumbnail,
      options,
      files: files || [],
      prompts: prompts || [],
    }
  } catch (error) {
    console.error("Error inesperado al obtener video con opciones:", error)
    return { success: false, error: "Error inesperado al obtener video con opciones" }
  }
}

// Función para crear un video general
export async function createGeneralVideo(userId: string, title: string, options: any) {
  try {
    console.log("Creando video general para el usuario:", userId)
    console.log("Opciones:", options)

    const supabase = getSupabaseClient()
    const videoId = uuidv4()

    // URL simulada para el video
    const videoUrl = `/api/videos/${videoId}/download`

    // Crear el video con solo los campos que existen en la tabla
    const { error: videoError } = await supabase.from("videos").insert({
      id: videoId,
      user_id: userId,
      title,
      url: videoUrl,
      type: "general",
      status: "completed", // Cambiado de "pending" a "completed" para mostrar inmediatamente
    })

    if (videoError) {
      console.error("Error al insertar video:", videoError)
      return { success: false, error: videoError.message }
    }

    // Preparar opciones para inserción
    // Convertir arrays a strings para almacenamiento
    const bRollSourceValue = Array.isArray(options.b_roll_source)
      ? options.b_roll_source.join(",")
      : options.b_roll_source || null

    // Crear las opciones del video
    const { error: optionsError } = await supabase.from("video_general_options").insert({
      id: uuidv4(),
      video_id: videoId,
      title: options.title,
      topic: options.topic,
      hook: options.hook,
      format: options.format,
      sources: options.sources,
      restricted_words: options.restricted_words,
      duration: options.duration,
      banned_topics: options.banned_topics,
      keywords: options.keywords,
      ai_voice_over: options.ai_voice_over,
      subtitles: options.subtitles,
      b_roll: options.b_roll,
      typography: options.typography,
      music_source: options.music_source,
      b_roll_source: bRollSourceValue,
      sound_effects_source: options.sound_effects_source,
    })

    if (optionsError) {
      console.error("Error al insertar opciones del video:", optionsError)
      // No fallamos aquí, continuamos con el proceso
    }

    // Generar y almacenar el prompt utilizando n8n
    try {
      const promptResult = await PromptService.generateAndStorePrompt({
        videoId,
        userId,
        inputContext: options,
      })

      if (!promptResult.success) {
        console.warn("No se pudo generar el prompt:", promptResult.error)
        // No fallamos aquí, continuamos con el proceso
      } else {
        console.log("Prompt generado con éxito. ID:", promptResult.promptId)
      }
    } catch (promptError) {
      console.error("Error al generar el prompt:", promptError)
      // No fallamos aquí, continuamos con el proceso
    }

    console.log("Video general creado con éxito. ID:", videoId)

    // Generar datos simulados para la respuesta
    const generatedVideo = {
      id: videoId,
      title: title,
      url: videoUrl,
      thumbnailUrl: generateThumbnailUrl(title),
      fileName: `${title.replace(/\s+/g, "_")}.mp4`,
      fileSize: Math.floor(Math.random() * 50000000) + 10000000, // Tamaño aleatorio entre 10MB y 60MB
      fileType: "video/mp4",
      fileUrl: videoUrl,
      duration:
        options.duration === "15s"
          ? "00:15"
          : options.duration === "30s"
            ? "00:30"
            : options.duration === "60s"
              ? "01:00"
              : options.duration === "3min"
                ? "03:00"
                : options.duration === "5min"
                  ? "05:00"
                  : "10:00",
      resolution: "1080p",
      format: "MP4",
      createdAt: new Date().toISOString(),
    }

    return { success: true, videoId, generatedVideo }
  } catch (error) {
    console.error("Error inesperado al crear video general:", error)
    return { success: false, error: "Error inesperado al crear video general" }
  }
}

// Función para crear un video de cliente
export async function createClientVideo(userId: string, title: string, url: string, options: any) {
  try {
    console.log("Creando video de cliente para el usuario:", userId)

    const supabase = getSupabaseClient()
    const videoId = uuidv4()

    // Crear el video con solo los campos que existen en la tabla
    const { error: videoError } = await supabase.from("videos").insert({
      id: videoId,
      user_id: userId,
      title,
      url,
      type: "client",
      status: "completed", // Cambiado de "pending" a "completed" para mostrar inmediatamente
    })

    if (videoError) {
      console.error("Error al insertar video de cliente:", videoError)
      return { success: false, error: videoError.message }
    }

    // Crear las opciones del video
    const { error: optionsError } = await supabase.from("video_client_options").insert({
      id: uuidv4(),
      video_id: videoId,
      hook: options.hook,
      b_roll: options.b_roll,
      subtitles: options.subtitles,
      language: options.language,
    })

    if (optionsError) {
      console.error("Error al insertar opciones del video de cliente:", optionsError)
      // No fallamos aquí, continuamos con el proceso
    }

    console.log("Video de cliente creado con éxito. ID:", videoId)

    // Generar datos simulados para la respuesta
    const generatedVideo = {
      id: videoId,
      title: title,
      url: `/api/videos/${videoId}`,
      thumbnailUrl: generateThumbnailUrl(title),
      fileName: `${title.replace(/\s+/g, "_")}.mp4`,
      fileSize: Math.floor(Math.random() * 50000000) + 10000000, // Tamaño aleatorio entre 10MB y 60MB
      fileType: "video/mp4",
      fileUrl: `/api/videos/${videoId}/download`,
      duration: "02:30", // Duración predeterminada
      resolution: "1080p",
      format: "MP4",
      createdAt: new Date().toISOString(),
    }

    return { success: true, videoId, generatedVideo }
  } catch (error) {
    console.error("Error inesperado al crear video de cliente:", error)
    return { success: false, error: "Error inesperado al crear video de cliente" }
  }
}

// Función para guardar un archivo de video
export async function saveVideoFile(videoId: string, file: any) {
  try {
    console.log("Guardando archivo para el video:", videoId)

    const supabase = getSupabaseClient()

    // Guardar el archivo en la tabla files
    const { error: fileError } = await supabase.from("files").insert({
      id: uuidv4(),
      video_id: videoId,
      name: file.name,
      url: file.url,
      type: file.type,
      size: file.size,
    })

    if (fileError) {
      console.error("Error al guardar archivo:", fileError)
      return { success: false, error: fileError.message }
    }

    console.log("Archivo guardado con éxito para el video:", videoId)

    return { success: true }
  } catch (error) {
    console.error("Error inesperado al guardar archivo:", error)
    return { success: false, error: "Error inesperado al guardar archivo" }
  }
}

// Función para actualizar el estado de un video
export async function updateVideoStatus(videoId: string, status: string) {
  try {
    console.log(`Actualizando estado del video ${videoId} a ${status}`)

    const supabase = getSupabaseClient()

    const { error } = await supabase.from("videos").update({ status }).eq("id", videoId)

    if (error) {
      console.error("Error al actualizar estado del video:", error)
      return { success: false, error: error.message }
    }

    console.log("Estado del video actualizado con éxito")

    return { success: true }
  } catch (error) {
    console.error("Error inesperado al actualizar estado del video:", error)
    return { success: false, error: "Error inesperado al actualizar estado del video" }
  }
}
