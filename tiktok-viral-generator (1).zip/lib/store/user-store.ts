import { create } from "zustand"
import { persist } from "zustand/middleware"
import { AuthService, type User, type UserCredentials } from "../services/auth-service"

interface UserState {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
  error: string | null

  // Acciones
  login: (username: string, password: string) => Promise<void>
  register: (credentials: UserCredentials) => Promise<void>
  logout: () => void
  clearError: () => void
}

export const useUserStore = create<UserState>()(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,
      isLoading: false,
      error: null,

      login: async (username: string, password: string) => {
        set({ isLoading: true, error: null })

        try {
          const user = await AuthService.login({ username, password })
          set({ user, isAuthenticated: true, isLoading: false })
        } catch (error) {
          set({
            error: error instanceof Error ? error.message : "Error al iniciar sesión",
            isLoading: false,
          })
        }
      },

      register: async (credentials: UserCredentials) => {
        set({ isLoading: true, error: null })

        try {
          const user = await AuthService.register(credentials)
          set({ user, isAuthenticated: true, isLoading: false })
        } catch (error) {
          set({
            error: error instanceof Error ? error.message : "Error al registrar usuario",
            isLoading: false,
          })
        }
      },

      logout: () => {
        set({ user: null, isAuthenticated: false })
      },

      clearError: () => {
        set({ error: null })
      },
    }),
    {
      name: "user-storage",
      partialize: (state) => ({ user: state.user, isAuthenticated: state.isAuthenticated }),
      skipHydration: false, // Ensure hydration happens automatically
    },
  ),
)
