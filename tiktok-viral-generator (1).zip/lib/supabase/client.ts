import { createClient } from "@supabase/supabase-js"
import type { Database } from "./database.types"

// Crear un singleton para el cliente de Supabase
let supabaseInstance: ReturnType<typeof createClient<Database>> | null = null

export const getSupabaseClient = () => {
  if (supabaseInstance) return supabaseInstance

  // Usar las variables de entorno proporcionadas por Vercel
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

  if (!supabaseUrl || !supabaseAnonKey) {
    console.error("Error: Variables de entorno de Supabase no definidas")
    throw new Error("Variables de entorno de Supabase no definidas")
  }

  console.log("Creando cliente Supabase con URL:", supabaseUrl)

  try {
    supabaseInstance = createClient<Database>(supabaseUrl, supabaseAnonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
      },
    })
    return supabaseInstance
  } catch (error) {
    console.error("Error al crear cliente Supabase:", error)
    throw error
  }
}
