export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          username: string
          password: string
          email: string | null
          avatar_url: string | null
          is_verified: boolean
        }
        Insert: {
          id?: string
          username: string
          password: string
          email?: string | null
          avatar_url?: string | null
          is_verified?: boolean
        }
        Update: {
          id?: string
          username?: string
          password?: string
          email?: string | null
          avatar_url?: string | null
          is_verified?: boolean
        }
      }
      videos: {
        Row: {
          id: string
          user_id: string
          title: string
          url: string
          type: string
          status: string
        }
        Insert: {
          id?: string
          user_id: string
          title: string
          url: string
          type: string
          status?: string
        }
        Update: {
          id?: string
          user_id?: string
          title?: string
          url?: string
          type?: string
          status?: string
        }
      }
      video_client_options: {
        Row: {
          id: string
          video_id: string
          hook: string
          b_roll: string
          subtitles: string
          language: string
        }
        Insert: {
          id?: string
          video_id: string
          hook: string
          b_roll: string
          subtitles: string
          language: string
        }
        Update: {
          id?: string
          video_id?: string
          hook?: string
          b_roll?: string
          subtitles?: string
          language?: string
        }
      }
      video_general_options: {
        Row: {
          id: string
          video_id: string
          title: string
          topic: string
          hook: string
          format: string
          sources: string
          restricted_words: string | null
          duration: string // Tipo de intervalo representado como string
          banned_topics: string | null
          keywords: string | null
          ai_voice_over: string
          subtitles: string
          b_roll: string
          typography: string | null
          typography_source: string | null
          music_source: string | null
          b_roll_source: string | null
          effects_source: string | null
          transitions_source: string | null
          sound_effects_source: string | null
          stickers_source: string | null
          emojis_source: string | null
          subtitles_source: string | null
          texts_source: string | null
          licenses: string | null
        }
        Insert: {
          id?: string
          video_id: string
          title: string
          topic: string
          hook: string
          format: string
          sources: string
          restricted_words?: string | null
          duration: string // Tipo de intervalo representado como string
          banned_topics?: string | null
          keywords?: string | null
          ai_voice_over: string
          subtitles: string
          b_roll: string
          typography?: string | null
          typography_source?: string | null
          music_source?: string | null
          b_roll_source?: string | null
          effects_source?: string | null
          transitions_source?: string | null
          sound_effects_source?: string | null
          stickers_source?: string | null
          emojis_source?: string | null
          subtitles_source?: string | null
          texts_source?: string | null
          licenses?: string | null
        }
        Update: {
          id?: string
          video_id?: string
          title?: string
          topic?: string
          hook?: string
          format?: string
          sources?: string
          restricted_words?: string | null
          duration?: string // Tipo de intervalo representado como string
          banned_topics?: string | null
          keywords?: string | null
          ai_voice_over?: string
          subtitles?: string
          b_roll?: string
          typography?: string | null
          typography_source?: string | null
          music_source?: string | null
          b_roll_source?: string | null
          effects_source?: string | null
          transitions_source?: string | null
          sound_effects_source?: string | null
          stickers_source?: string | null
          emojis_source?: string | null
          subtitles_source?: string | null
          texts_source?: string | null
          licenses?: string | null
        }
      }
      files: {
        Row: {
          id: string
          video_id: string
          name: string
          url: string
          type: string
          size: number
        }
        Insert: {
          id?: string
          video_id: string
          name: string
          url: string
          type: string
          size: number
        }
        Update: {
          id?: string
          video_id?: string
          name?: string
          url?: string
          type?: string
          size?: number
        }
      }
      social: {
        Row: {
          id: string
          user_id: string
          platform: string
          access_token: string
          refresh_token: string | null
          token_expires_at: string | null
          platform_user_id: string | null
          platform_username: string | null
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          platform: string
          access_token: string
          refresh_token?: string | null
          token_expires_at?: string | null
          platform_user_id?: string | null
          platform_username?: string | null
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          platform?: string
          access_token?: string
          refresh_token?: string | null
          token_expires_at?: string | null
          platform_user_id?: string | null
          platform_username?: string | null
          updated_at?: string
        }
      }
      n8n_workflow_results: {
        Row: {
          id: string
          video_id: string
          workflow_id: string
          execution_id: string
          status: string
          result_data: Json
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          video_id: string
          workflow_id: string
          execution_id: string
          status: string
          result_data: Json
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          video_id?: string
          workflow_id?: string
          execution_id?: string
          status?: string
          result_data?: Json
          created_at?: string
          updated_at?: string
        }
      }
    }
  }
}
