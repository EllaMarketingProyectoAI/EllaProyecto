/**
 * Utility functions for debugging n8n integration
 */

/**
 * Formats an error object for logging
 */
export function formatError(error: any): string {
  if (!error) return "Unknown error"

  if (typeof error === "string") return error

  const message = error.message || "Unknown error"
  const stack = error.stack ? `\nStack: ${error.stack}` : ""
  const details = error.details ? `\nDetails: ${JSON.stringify(error.details)}` : ""

  return `${message}${details}${stack}`
}

/**
 * Validates n8n configuration
 */
export function validateN8nConfig(): { valid: boolean; issues: string[] } {
  const issues: string[] = []

  // Check if N8N_WORKFLOW_URL is configured
  if (!process.env.N8N_WORKFLOW_URL) {
    issues.push("N8N_WORKFLOW_URL environment variable is not configured")
  } else if (!process.env.N8N_WORKFLOW_URL.startsWith("http")) {
    issues.push("N8N_WORKFLOW_URL must start with http:// or https://")
  }

  // Check if N8N_API_KEY is configured
  if (!process.env.N8N_API_KEY) {
    issues.push("N8N_API_KEY environment variable is not configured")
  }

  return {
    valid: issues.length === 0,
    issues,
  }
}

/**
 * Prepares a test payload for n8n
 */
export function prepareTestPayload(): Record<string, any> {
  return {
    title: "Test Video",
    topic: "Testing n8n Integration",
    hook: "question",
    format: "tutorial",
    restricted_words: "bad,words",
    banned_topics: "politics,religion",
    keywords: "test,n8n,integration",
    ai_voice_over: "yes",
    subtitles: "yes",
    typography: "modern",
    music_source: "upbeat",
    b_roll_source: ["stock", "ai"],
    sound_effects_source: "minimal",
    duration: "60s",
    sources: "Test sources",
    userId: "test-user",
    videoId: "test-video",
    timestamp: new Date().toISOString(),
  }
}
